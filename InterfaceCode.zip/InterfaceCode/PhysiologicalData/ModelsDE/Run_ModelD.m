% MCMC with iid errors and exponential stiffness parameter for the linear
% wall maths model

clear; close all;

% Add necessary paths ...

%% Load the real data
trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');

%% Set some parameters
id = 1; % id for data files
hd = 0; % no of GP hyperparameters
nbio = 6; % no of biophysical parameters
nd = nbio + hd; % total no of parameters
T = 0.11; % cycle length (s)
% Type of covariance function used for the residuals
% 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
% 4 - periodic; 5 - neural network
gp_ind = NaN;

em_ind = 0; % do not do emulation

corrErr = 0; % iid errors, not correlated 

extra_p = [id, hd, gp_ind, T];

% Bounds for original parameters
l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
u = [10^7, -50, 6*10^4, 2.5,  2.5,  2.5];
% Parameter scaling
sc = max(abs(l),abs(u));

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded Windkessel parameters
% Be(1,1) = Uniform

alp = [1,1,1,1,1,1];
bet = [1,1,1,1,1,1];

a_noisevar = 0.001; b_noisevar = 0.001; % uninformative IG prior for the observation noise variance

GP_hyperHyper = NaN(6,1);

n = size(truePressure,1);

%% Run AM sampling

par_start =  [3*10^4, -105, 3.6*10^4, 0.9, 0.85, 1];

%load('AMsimulator_Sampling_ExpoStiff_iid.mat')

%par_start = p_sample(12000,:);

nSamples = 150000;
n_burnin = 1000;

adapt_int = 100; % adaptation interval (in AM)
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-6),nd,1));
R = chol(cov_MH);

gp_regr_refitted = NaN; x_regr_refitted= NaN; y_regr_refitted = NaN;
gp_class = NaN; x_class = NaN; y_class = NaN; extraPar_gp = NaN; phase_ind = NaN;

p_sample = NaN(nSamples+n_burnin, nd); % parameter samples
ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
s2_sample = NaN(nSamples+n_burnin,1); % noise variance samples
p_sample(1,:) = par_start;

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
acc = 0; % acceptance rate of the algorithm
rejout = 0; % rejection rate for being outside the range

ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),truePressure,...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, ...
    extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);

s2_sample(1) = ObjFct_sample(1)/(n-nd); % observation noise variance

oldObjFct = ObjFct_sample(1);
oldpar = p_sample(1,:)./sc;
oldprior = Prior_AM(oldpar,l,u,sc,extra_p,gp_ind,alp,bet,GP_hyperHyper,corrErr);

covchain = []; meanchain = []; wsum = []; lasti = 0;

initime = cputime();

for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar.*sc<l) || any(newpar.*sc>u)        
        %disp('proposal outside boundaries')
        newObjFct = 10^10; % ss
        %newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, truePressure, sc, ...
            gp_ind, corrErr);
        
        newprior = Prior_AM(newpar,l,u,sc,extra_p,gp_ind,...
            alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    if newObjFct == 10^10 % outside boundaries
        tst = 0;
    else
        tst = exp(-0.5/s2_sample(i-1)*(newObjFct - oldObjFct) + newprior-oldprior); % for ss
        %tst = exp(newObjFct - oldObjFct + newprior-oldprior); % for loglik
    end
    
    %[newObjFct, oldObjFct]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        
        p_sample(i,:) = newpar.*sc;
                
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
    
    s2_sample(i) = 1/gamrnd(a_noisevar+0.5*n, 1/(b_noisevar+0.5*ObjFct_sample(i)));
    
    if mod(i,100) == 0
        %sprintf('acc rate is %d', acc/i)
        save('AMsimulator_Sampling_ExpoStiff_iid_contd.mat')
    end
    
end

CPUtime = initime - cputime();

exit;