% The choice of hyperpriors places approximately 90% prior probability on
% the range [l,u] for the 21 vessel stiffness parameters

a = 3; b = 0.6e09;%1.16e09;

n = 10^3;
s2 = NaN(n,1);

for i=1:n
s2(i) = 1/gamrnd(a, 1/b);
end

l = 2e04; u = 1e05; 
mu_star = 43075;%(u+l)/2; 
s2_star = 2.5e08;

mu = NaN(n,1);

for i=1:n
mu(i) = normrnd(mu_star,sqrt(s2_star));
end

pd = makedist('Normal','mu',mean(mu),'sigma',sqrt(mean(s2)));
x = [l,u];
y = cdf(pd,x);
y(2)-y(1)

% figure(1);clf(1)
% plot(1:n,s2)
% 
% x = linspace(0,10^4,n);
% pdf = b^a/gamma(a).*(1./x).^(a+1).*exp(-b./x);
% 
% figure(2);clf(2);
% plot(x,pdf)
% 
% l = 2e04; u = 1e05; 
% mu_star = 43075;%(u+l)/2; 
% s2_star = 2.5e08;
% 
% mu = NaN(n,1);
% 
% for i=1:n
% mu(i) = normrnd(mu_star,sqrt(s2_star));
% end
% 
% figure(3);clf(3)
% plot(1:n,mu)
% 
% theta = NaN(n,1);
% for i=1:n
%     theta(i) = normrnd(mu(i),sqrt(s2(i)));
% end
% 
% 
% figure(5);clf(5)
% plot(1:n,theta)
% 
% x = linspace(l,u,n);
% pdf = normpdf(x,mean(mu),sqrt(mean(s2)));
% figure(4);clf(4);
% plot(x,pdf)
% 
% 
% quantile(theta,[0.005 0.25,0.5,0.75,0.9,0.95,0.995])
% 
% pd = makedist('Normal','mu',mean(mu),'sigma',sqrt(mean(s2)));
% x = [l,u];
% y = cdf(pd,x);
% y(2)-y(1)
% 
% x=linspace(l,u,100);
% y = cdf(pd,x);
% 
% figure(7);clf(7)
% plot(x,y)
