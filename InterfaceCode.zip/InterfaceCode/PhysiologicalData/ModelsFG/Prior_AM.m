function prior = Prior_AM(par, l, u, sc, extra_p, gp_ind,  ...
    mu_stiff, s2_stiff, alp, bet, GP_hyperHyper, corrErr)

nd = extra_p(2); % total parameter dimensionality
nv = extra_p(3); % no of stiffness parameters corresponding to no of vessels
hd = extra_p(4); % no of GP cov fct parameters
nbio = nd-hd; % no of biological param

if corrErr == 1
    
    priorBio = sum( -0.5*(log(2*pi) + log(s2_stiff)) - ...
        ((par(1:nv).*sc(1:nv)-mu_stiff).^2)./(2.*s2_stiff) ) + ...
        sum( (alp-1) .* log(par(nv+1:nbio).*sc(nv+1:nbio)-l(nv+1:nbio)) + ...
        (bet-1) .* log(u(nv+1:nbio) - par(nv+1:nbio).*sc(nv+1:nbio)) );

    if gp_ind ~= 5
        priorCov = -log(par(end-1)*sc(end-1)) - log(sqrt(GP_hyperHyper(2)*2*pi)) - ...
            (log(par(end-1)*sc(end-1)) - GP_hyperHyper(1))^2/(2*GP_hyperHyper(2)) + ...
            -log(par(end)*sc(end)) - log(sqrt(GP_hyperHyper(4)*2*pi)) - ...
            (log(par(end)*sc(end)) - GP_hyperHyper(3))^2/(2*GP_hyperHyper(4));
    else
        priorCov = -log(par(end-1)*sc(end-1)) - log(GP_hyperHyper(2)-GP_hyperHyper(1)) + ...
            -log(par(end)*sc(end)) - log(GP_hyperHyper(4)-GP_hyperHyper(3));
        
    end
    
    prior = sum(log(sc)) + priorBio + priorCov;
    
else %corrErr=0
    
    priorBio = sum( -0.5*(log(2*pi) + log(s2_stiff)) - ...
        ((par(1:nv).*sc(1:nv)-mu_stiff).^2)./(2.*s2_stiff) ) + ...
        sum( (alp-1) .* log(par(nv+1:end).*sc(nv+1:end)-l(nv+1:end)) + ...
        (bet-1) .* log(u(nv+1:end) - par(nv+1:end).*sc(nv+1:end)) );
    
    prior = sum(log(sc)) + priorBio;
    
end

