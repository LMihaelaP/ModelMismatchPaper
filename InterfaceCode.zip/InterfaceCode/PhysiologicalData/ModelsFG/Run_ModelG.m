% MCMC with correlated errors and 21 stiffness parameters for the linear
% wall maths model

clear; close all;

% Add necessary paths ...

%% Load the real data
trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');

%% Set some parameters

if 1
    
    load('GPHMC_NN_samplingAM_corrErr.mat') % load workspace for 1 stiffness analysis to extract MAP to be used here
    
    id = 1; % id for data files
    nv = 21; % no of vessels, i.e. no of stiffness parameters
    hd = 2; % no of GP hyperparameters
    nbio = nv + 3; % no of bio param (21 stiffness + 3 Windkessel)
    nd = nbio + hd; % total no of parameters
    HB = 12; % no of heartbeats
    cycles = 1; % no of cardiac cycles
    T = 0.11; % cycle length (s)
    % Type of covariance function used for the residuals
    % 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
    % 4 - periodic; 5 - neural network
    gp_ind = 5;
    extra_p = [id, nd, nv, hd, HB, cycles, gp_ind, T];
    
    n = size(truePressure,1);
    ntp = size(truePressure,1);
    
    
    % Bounds for original parameters
    
    if gp_ind ~= 5
        % Bounds for original parameters
        l = [repmat(2e04,1,nv), 0.05, 0.05, 0.05, 0.5, 0.001];
        u = [repmat(1e05,1,nv), 2.5,  2.5,  2.5, 1.5,  0.06];
        % Parameter scaling for emulation
        sc = [repmat(10^5,1,nv), 10, 10, 10, 10, 10^(-1)];
        
    else
        % Bounds for original parameters
        l = [repmat(2e04,1,nv), 0.05, 0.05, 0.05, 10^4, 1];
        u = [repmat(1e05,1,nv), 2.5, 2.5, 2.5, 90000,   500];
        sc = [repmat(10^5,1,nv), 10, 10, 10, 10^6, 10^3];
    end
    
    %% Define prior (for original, unscaled parameters)
    % Derived from rescaled beta distribution on the bounded Windkessel parameters
    % Be(1,1) = Uniform
    % stiffness ~ N(mu_stiff, s2_stiff), so they're defined as unbounded,
    % values outside [l,u] will be rejected in the MCMC
    % mu_stiff ~ N(mu_star, s2_star)
    % s2_stiff ~ IG(a,b) <=> s2_stiff ~ 1/G(a,1/b)
    % Choice of mu_star, s2_star, a, b places 90% prior probability inside
    % [l,u] for the stiffness parameters
    alp = [1,1,1];
    bet = [1,1,1];
    a = 3; b = 0.6e09;%1.16e09; % for the variance of the stiffness parameters
    mu_star = 43075;%(u(1)+l(1))/2;
    s2_star = 2.5e08;
    
    % For GP hyperparameters
    % for sq exp, matern 3/2, 5/2, periodic:
    % amplitude ~ LogGauss(GPhyperHyper(1), GPhyperHyper(2)),LogGauss(mua,sigmaa^2)
    % lengthscale ~ LogGauss(GPhyperHyper(3), GPhyperHyper(4)),LogGauss(mul,sigmal^2)
    % cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
    % for neural network:
    % bias sigma2 ~ Logunif(GPhyperHyper(1), GPhyperHyper(2)),Logunif(loglb, logub)
    % weight sigma2 ~ Logunif(GPhyperHyper(3), GPhyperHyper(4)),Logunif(loglw, loguw)
    % cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
	% cov noise is kept fixed at a small value, e.g. 10^(-6)
    if gp_ind ~= 5
        GP_hyperHyper = [log(0.1), 0.095, log(0.0275), 0.1]; % amplitude: log(var(res))
    else
        GP_hyperHyper = [l(end-1), u(end-1), l(end), u(end)];
    end
    
    %% Take MAP from one stiffness parameter AM simulations
    % and set that as initial value for multiple stiffness parameters
    map_ind =  find(ObjFct_sim{1}==max(ObjFct_sim{1}));
    
    nSamples = 150000;
    n_burnin = 5000;
    
    adapt_int = 100; % adaptation interval (in AM)
    scale = 1; % scale the original paramerts bc of varying mgnitudes
    % proposal covariance for MH within the trajectory
    cov_MH = diag(repmat(5*10^(-4),nd,1));
    cov_MH(22,22) = 5*10^(-6); cov_MH(23,23) = 5*10^(-5); cov_MH(25,25) = 5*10^(-5);
    R = chol(cov_MH);
    
    extraPar_gp = [mean_y, std_y];
    
    p_sample = NaN(nSamples+n_burnin, nd); % parameter samples
    ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
    
    p_sample(1,1:nv) = repmat(par_sim{1}(map_ind,1),1,nv); % no transformation for unboundedness needed
    p_sample(1,nv+1:end) = (par_sim{1}(map_ind,2:end));
    
    mu_stiff = NaN(nSamples+n_burnin,1);
    s2_stiff = NaN(nSamples+n_burnin,1);
    
    qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
    qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
    sample_sigma = NaN; % sample sigma2 only for uncorrelated errors
    acc = 0; % acceptance rate of the algorithm
    rejout = 0; % rejection rate for being outside the range
    
    % delete(gcp('nocreate'))
    % parpool('local', nbio)
    
    mu_stiff(1) = normrnd(mu_star, sqrt(s2_star));
    
    s2_stiff(1) = 1/gamrnd(a, 1/b);
    
    ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),truePressure,...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, ...
        extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);
    
    oldObjFct = ObjFct_sample(1);
    oldpar = p_sample(1,:)./sc;
    oldprior = Prior_AM(oldpar,l,u,sc,extra_p,...
        gp_ind,mu_stiff(1),s2_stiff(1),alp,bet,GP_hyperHyper,corrErr);
    
    covchain = []; meanchain = []; wsum = []; lasti = 0;
    
end %1

%load('AMsimulator_Sampling_errorCorrel_contd.mat')
%
%acc = 0;
%
%par_start = p_sample(i,:);
%hyperpar_start = [mu_stiff(i),s2_stiff(i)];
%
%cov_MH = diag(repmat(5*10^(-5),nd,1));
%cov_MH(22,22) = 5*10^(-5); cov_MH(23,23) = 5*10^(-5); cov_MH(25,25) = 5*10^(-5);
%R = chol(cov_MH);
%
%p_sample = NaN(nSamples+n_burnin, nd); % parameter samples
%ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
%
%p_sample(1,:) = par_start; % no transformation for unboundedness needed
%
%mu_stiff = NaN(nSamples+n_burnin,1);
%s2_stiff = NaN(nSamples+n_burnin,1);
%
%mu_stiff(1) = hyperpar_start(1);
%
%s2_stiff(1) = hyperpar_start(2);
%
%ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),truePressure,...
%    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
%    gp_class, x_class, y_class, ...
%    extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);
%
%oldObjFct = ObjFct_sample(1);
%oldpar = p_sample(1,:)./sc;
%oldprior = Prior_AM(oldpar,l,u,sc,extra_p,...
%    gp_ind,mu_stiff(1),s2_stiff(1),alp,bet,GP_hyperHyper,corrErr);
%
%covchain = []; meanchain = []; wsum = []; lasti = 0;

initime = cputime();

% Main loop
for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar(nv+1:nv+3).*sc(nv+1:nv+3)<l(nv+1:nv+3)) || ...
            any(newpar(nv+1:nv+3).*sc(nv+1:nv+3)>u(nv+1:nv+3)) || ...
            any(newpar(1:nv).*sc(1:nv)<zeros(1,nv))
        % windkessel parameters outside boundaries and stiffness parameters negative
        % but error model parameters not within hard bounds
        
        disp('proposal outside boundaries')
        newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, truePressure, sc, ...
            gp_ind, corrErr);
        
        if pass == 0
            disp('proposal outside boundaries')
            newObjFct % this should be -10^10
        end
        
        newprior = Prior_AM(newpar,l,u,sc,extra_p,gp_ind,...
            mu_stiff(i-1),s2_stiff(i-1),alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    % Re-calculate oldprior based on newly drawn mu_stiff, s2_stiff
    oldprior = Prior_AM(oldpar,l,u,sc,extra_p,gp_ind,...
        mu_stiff(i-1),s2_stiff(i-1),alp,bet,GP_hyperHyper,corrErr);
    
    if newObjFct == -10^10 % outside boundaries
        tst = 0;
    else
        tst = exp(newObjFct - oldObjFct + newprior-oldprior);
    end
    
    %[newObjFct+newprior, oldObjFct+oldprior]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        p_sample(i,:) = newpar.*sc;
        
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        %oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        %oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
    
    
    mu_stiff(i) = normrnd( ( mu_star/s2_star + (1/s2_stiff(i-1)) * ...
        sum(p_sample(i,1:nv)) ) / ( 1/s2_star + k/s2_stiff(i-1) ), ...
        sqrt( (1/s2_star + k/s2_stiff(i-1))^(-1) )  );
    
    s2_stiff(i) = 1/gamrnd( a+nv/2, 1 / ( b + 0.5 * sum((p_sample(i,1:nv)-mu_stiff(i)).^2) ) );
    
    if mod(i,100) == 0
        %sprintf('acc rate is %d', acc/i)
        save('AMsimulator_Sampling_errorCorrel_contd_part2.mat')
    end
    
end

CPUtime = initime - cputime();

exit;