function [gp_regr, nlml_regr, gp_class, nlml_class] = ...
    GPmodel(x_regr, y_regr, x_class, y_class, H_r, H_c, gp_no, corrErr)
% Fits and return GP regression and GP classification model to x and y
% GP1 regr: neural network cov fct (non-stationary) with optimization of hyperparam
% GP2 regr: sexp cov fct (stationary) with optimization of hyperparam
% GP3 regr: sexp cov fct (stationary) with optimization of hyperparam
% when HMC or variants of HMC used, where we require 1st, 2nd or 3rd gradient,
% we always use gp_no = 2 (squared exponential), as we calculate numerical
% gradients for the sq exp kernel

%% GP regression

% Hyperpriors
if corrErr == 0
    plg = prior_unif(); % prior for lengthscale
    pms = prior_sqrtunif();
    ps = prior_logunif(); % prior for sigma2 in the likelihood
else
    plg = prior_logunif();
    pms = prior_logunif();
    ps = prior_logunif();
end

for i = 1:size(H_r,1)
    lik = lik_gaussian('sigma2', H_r(end), 'sigma2_prior', ps);
    
    % We allow for different lengthscale in every dimension (ARD)
    % One magnitude as it is a 1 single output (rss 1x1)
    
    if gp_no == 1
        % use non-stationary (neural network) cov fct for 1st GP
        gpcf = gpcf_neuralnetwork('biasSigma2', H_r(i,1), ...
            'weightSigma2', H_r(i,2:end-1), ...
            'biasSigma2_prior',prior_logunif(), ...
            'weightSigma2_prior',prior_logunif());
    else
        % use stationary (squared exponenetial) cov fct for 2nd & 3rd GP
        gpcf = gpcf_sexp('lengthScale', H_r(i,2:end-1), ...
            'magnSigma2', H_r(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
    end

    % Set a small amount of jitter to be added to the diagonal elements of the
    % covariance matrix K to avoid singularities when this is inverted
    jitter=1e-9;
    
    % Create the GP structure
    gp_regr_all{i} = gp_set('lik', lik, 'cf', gpcf,...
        'jitterSigma2', jitter);%, 'latent_method', 'EP');
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-11,'TolX',1e-11);
    
    % Optimize with the scaled conjugate gradient method
    [gp_regr_all{i}, nlml_regr(i)] = ...
        gp_optim(gp_regr_all{i},x_regr,y_regr,'opt',opt);
    
end

I = find(nlml_regr == min(nlml_regr));
gp_regr = gp_regr_all{I};

disp('done')
%% GP classifier
lik_class = lik_logit();

for i = 1:size(H_c,1)
    % We allow for different lengthscale in every dimension (ARD)
    % One magnitude as it is a 1 single output (rss 1x1)
    gpcf = gpcf_sexp('lengthScale', H_c(i,2:end), ...
        'magnSigma2', H_c(i,1),...
        'lengthScale_prior', plg, 'magnSigma2_prior', pms);
		
    % Create the GP structure (type is by default FULL)
    gp_class_all{i} = gp_set('lik', lik_class, 'cf', gpcf, ...
        'jitterSigma2', 1e-9);
    
    % ------- EP approximation --------
    % Set the approximate inference method - Laplace(default)
    gp_class_all{i} = gp_set(gp_class_all{i}, ...
        'latent_method', 'EP');
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-3,'TolX',1e-3);
    % Optimize with the scaled conjugate gradient method
    [gp_class_all{i}, nlml_class(i)] = ...
        gp_optim(gp_class_all{i}, x_class,y_class,'opt',opt);
    %, 'optimf', @fminlbfgs);
end

I = find(nlml_class == min(nlml_class));
gp_class = gp_class_all{I};

end

