function parsave(fname, results, chain, s2chain, sschain, options, params, model)
save(fname, 'results', 'chain', 's2chain', 'sschain', 'options', 'params', 'model')
end