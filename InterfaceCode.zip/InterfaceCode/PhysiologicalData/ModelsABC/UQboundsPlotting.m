%%

clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

delete(gcp('nocreate'))
parpool('local', 20)

id = 1;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end

AllPressures{1} = Pressure; AllFlows{1} = Flow;


%
figure(1); clf(1)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); clf(10)

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-k','LineWidth',1)
%     if j==1
%         legend('Measured', 'Generated (median)')
%     end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y(2,:))) max(max(Y(2,:))) ])
    title(sprintf('Median pressure - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(11); clf(11)

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-k','LineWidth',1)

    xlabel('Time (s)'); ylabel('Flow (ml/s)')
    axis tight
    ylim([min(min(Y(2,:))) max(max(Y(2,:))) ])
    title(sprintf('Median flow - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(12); clf(12)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-k','LineWidth',1)

    xlabel('Pressure (mmHg)'); ylabel('Area (cm^2)')
    axis tight
    %xlim([min(min(log(Y(2,:)))) max(max(log(Y(2,:)))) ]); 
    %ylim([min(min(log(Z(2,:)))) max(max(log(Z(2,:)))) ]); 
    title(sprintf('Pressure-Area - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13); clf(13)

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.k', 'Markersize', 20)
xlabel('r0 (cm)'); ylabel('Mean Pressure (mmHg)')
axis tight
title('Mean pressure versus vessel radius')
set(gca, 'FontSize',15)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 100;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{2} = Pressure;  AllFlows{2} = Flow;

%
figure(2); clf(2)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-b','LineWidth',1)
 
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-b','LineWidth',1)

end

%
figure(12); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv

    subplot(5,5,j); hold on

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-b')

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13);hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.m', 'Markersize', 20)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - Exponential stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_iid_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 1;

ntp = n;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end

AllPressures{3} = Pressure;  AllFlows{3} = Flow;

%
figure(3); clf(3)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on

for j=1:nv
    
    subplot(5,5,j);

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-c','LineWidth',1)
    
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-c','LineWidth',1)

end

%
figure(12); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-c','LineWidth',1)

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13); hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.c', 'Markersize', 20)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - Exponential stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 1;

ntp = n;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end

AllPressures{4} = Pressure;  AllFlows{4} = Flow;

%
figure(4); clf(4)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on

for j=1:nv
    
    subplot(5,5,j);

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), 'Color', [0.5 0.5 0.5],'LineWidth',1)
    
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), 'Color', [0.5 0.5 0.5],'LineWidth',1)

end

%
figure(12); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), 'Color', [0.5 0.5 0.5],'LineWidth',1)

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13); hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.', 'Color', [0.5 0.5 0.5], 'Markersize', 20)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - 21 stiffness and iid errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part6.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(8*10^4:i, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 100;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
            param, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{5} = Pressure;  AllFlows{5} = Flow;

%
figure(5); clf(5)

for j=1:nv
    Y = quantile(Pressure(:,ntp*(j-1)+1:ntp*j),[0.025 0.5 0.975],1); % for each row
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,:), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,:), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,:), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([5 23])
    title(sprintf('UQ (correlated errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), 'Color', [1 0.5 0], 'LineWidth',1)
 
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), 'Color', [1 0.5 0],'LineWidth',1)

end

%
figure(12); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv

    subplot(5,5,j); hold on

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), 'Color', [1 0.5 0])

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13);hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.', 'Color', [1 0.5 0], 'Markersize', 20)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - 21 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(end/2+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 100;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
        param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{6} = Pressure;  AllFlows{6} = Flow;

%
figure(6); clf(6)

for j=1:nv
    Y = quantile(Pressure(:,ntp*(j-1)+1:ntp*j),[0.025 0.5 0.975],1); % for each row
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,:), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,:), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,:), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([5 23])
    title(sprintf('UQ (correlated errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-m','LineWidth',1)
 
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-m','LineWidth',1)

end

%
figure(12); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv

    subplot(5,5,j); hold on

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-m')

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13);hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.m', 'Markersize', 20)

%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Nonlinear model with 1 stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear/GPMCMC_NN_sampling_RealData_widerStiff.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 100;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{7} = Pressure;  AllFlows{7} = Flow;

%
figure(7); clf(7)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-r','LineWidth',1)
 
end

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-r','LineWidth',1)

end

%
figure(12); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv

    subplot(5,5,j); hold on

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-r')

end

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13);hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.r', 'Markersize', 20)



%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Nonlinear model with exponential stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:i, 1:nd-hd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 1000;

nv = 21;

ntp = size(truePressure,1);

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', param, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{8} = Pressure;  AllFlows{8} = Flow;

save('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Flows_all8models.mat','AllFlows')

save('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat','AllPressures')
 
%
figure(8); clf(8)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',1)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',0.5)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
        %     else
        %         legend('Generated (median)', '95% CI')
    end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (iid errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

%
figure(10); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)
 
end
figure(10); subplot(5,5,1); hold on; legend('Measured', 'Lin 1s iid', 'Lin 1s correl', 'Lin Expo s iid', 'Lin Expo s correl', ...
    'Lin 21s iid', 'Lin 21s correl', 'Nonlin 1s correl', 'Nonlin expo s correl')

%
figure(11); hold on

Y = quantile(Flow,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-g','LineWidth',1)

end
figure(11); hold on; legend('Lin 1s iid', 'Lin 1s correl', 'Lin Expo s iid', 'Lin Expo s correl', ...
    'Lin 21s iid', 'Lin 21s correl', 'Nonlin 1s correl', 'Nonlin expo s correl')

%
figure(12); hold on
Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
Z = quantile(Area,[0.025 0.5 0.975],1); % for each row

for j=1:nv

    subplot(5,5,j); hold on

    plot(Y(2,ntp*(j-1)+1:ntp*j), Z(2,ntp*(j-1)+1:ntp*j), '-g')

end
figure(12); hold on; legend('Lin 1s iid', 'Lin 1s correl', 'Lin Expo s iid', 'Lin Expo s correl', ...
    'Lin 21s iid', 'Lin 21s correl', 'Nonlin 1s correl', 'Nonlin expo s correl')

%
r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

figure(13);hold on

Y = quantile(Pressure,0.5,1); % for each row
Y = reshape(Y, ntp, nv);

plot(r0,mean(Y,1), '.g', 'Markersize', 20)

figure(13); hold on; legend('Lin 1s iid', 'Lin 1s correl', 'Lin Expo s iid', 'Lin Expo s correl', ...
    'Lin 21s iid', 'Lin 21s correl', 'Nonlin 1s correl', 'Nonlin expo s correl', 'Location', 'southeast')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

delete(gcp('nocreate'))
parpool('local', 20)

id = 10^5;

nv = 21;

s=[]; temp = [];

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=1; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=2; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - Exponential stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_iid_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 10^5;

s=[]; temp = [];

ntp = n;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=3; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - Exponential stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 10^5;

ntp = n;

nv = 21;

s=[]; temp = [];

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);


parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;

    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=4; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - 21 stiffness and iid errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part6.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(8*10^4:end, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
            param, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=5; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - 21 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(end/2+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
    param, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=6; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Nonlinear model with 1 stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear/GPMCMC_NN_sampling_RealData_widerStiff.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = par_sim{10}(nburnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=7; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Nonlinear model with exponential stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:i, 1:nd-hd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

ntp = size(truePressure,1);

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', param, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end


Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=8; CredISignal{k} = temp;

%%

%clearvars except -CredISignal

% Linear B - 1 stiffness and correlated errors simulator
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/AMsimulator_Sampling_1Stiff_errorCorrel_RealData.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

Signal = reshape(Y,3,512,21);

tmp = mean(Signal,2); % (21,3)

for j=1:nv
    temp(:,j) = tmp(:,1,j); 
end

k=9; CredISignal{k} = temp;

save('CI_Signals.mat')

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (1 vessel: MPA) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_1vess_locMid_MimicData.mat')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_1vess_locMid_LowQ.mat')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_1vess_locMid_UppQ.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(10000+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 1000;

nv = 21;

Pressure = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,~,~,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        end
    end
    
    pressure = pressure';
    
    Pressure(s,:) = pressure;
    
end

figure(99); clf(99)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

j=1;
subplot(1,2,1);
hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'red', 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
xlabel('Time (s)'); ylabel('Pressure (mmHg)')
axis tight
ylim([min(min(Y)) max(max(Y)) ])
title(sprintf('UQ (correlated errors) - vessel %d', j))
set(gca, 'FontSize',10)
j=21;
subplot(1,2,2);
hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'red', 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
xlabel('Time (s)'); ylabel('Pressure (mmHg)')
axis tight
ylim([min(min(Y)) max(max(Y)) ])
title(sprintf('UQ (correlated errors) - vessel %d', j))
set(gca, 'FontSize',10)

figure(100); clf(100)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);
    
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'red', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'green','LineWidth',1)
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight
    ylim([min(min(Y)) max(max(Y)) ])
    title(sprintf('UQ (correlated errors) - vessel %d', j))
    set(gca, 'FontSize',10)
end

parnames = {'f_1', 'f_2', 'f_3', 'r_1', 'r_2', 'c'};

figure(101); clf(101)
for i=1:nd-2
[f, x] = ksdensity(parChain(1:end,i));
subplot(3,2,i);plot(x,f,'LineWidth',3);hold on
xlabel(parnames(i));set(gca, 'FontSize',20);axis tight;
end

%%

clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (3 vessels: MPA, RPA, LPA) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_3vessels_MimicData.mat')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_3vessels_LowQ.mat')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_3vessels_UppQ.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(10000+1:end, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 1000;

nv = 21;

Pressure = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,~,~,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        end
    end
    
    pressure = pressure';
    
    Pressure(s,:) = pressure;
    
end

figure(99); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

j=1;
subplot(1,2,1);
hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'm', 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)
j=21;
subplot(1,2,2);
hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'm', 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)


figure(100); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j);hold on
    
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'm', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'b','LineWidth',1)

end


figure(101); hold on
for i=1:nd-2
[f, x] = ksdensity(parChain(1:end,i));hold on
subplot(3,2,i);plot(x,f,'LineWidth',3);
end

%%

clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (21 vessels) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_21vessels_MimicData_contd.mat')

%load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_21vessels_LowQ_contd.mat')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_Sampling_ExpoStiff_errorCorrel_SimulatedData_21vessels_UppQ_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:i, 1:nd-2);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

id = 1000;

nv = 21;

Pressure = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,~,~,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        end
    end
    
    pressure = pressure';
    
    Pressure(s,:) = pressure;
    
end

figure(99); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

j=1;
subplot(1,2,1);
hold on
plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
j=21;
subplot(1,2,2);
hold on
plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)

figure(100); hold on

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    subplot(5,5,j); hold on
           
    plot(linspace(0,0.11,512),truePressure(ntp*(j-1)+1:ntp*j), '-k', 'LineWidth',1)

    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1) % orange color
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
end

%figure(100); hold on; legend('truePressure', '1vessel', '3vessels', '21vessels')


figure(101); hold on
for i=1:nd-2
[f, x] = ksdensity(parChain(1:end,i));
subplot(3,2,i);plot(x,f,'LineWidth',3);hold on; line([par_true(i) par_true(i)],ylim, 'Color', 'black', 'LineWidth',3)
end

figure(101); hold on; legend('1vessel', '3vessels', '21vessels')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Look at 20 different data instantiations for 21 vessels data
clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (21 vessels) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels')

nrun=20;

delete(gcp('nocreate'))
parpool('local', nrun)

n_burnin = 1000; nd = 8; ntp = 512;

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:140000, 1:nd-2);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    id = 10^5;
    
    nv = 21;
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
                    
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    PressureAll{i} = Pressure;
    
    figure(i+10);clf(i+10)
    
    Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row
    
    j=1;
    subplot(1,2,1);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    j=21;
    subplot(1,2,2);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
end

for i=1:nrun
    tmp1 = mean(PressureAll{i});
    tmp2 = reshape(tmp1, ntp, nv);
    meantemp(i,:) = mean(tmp2);
end

truePressureresh = reshape(truePressure, ntp, nv);
[mean(meantemp) ;mean(truePressureresh)] % should be similar


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (21 vessels) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels')

n_burnin = 1000; nd = 8; ntp = 512;

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

figure(1001); clf(1001);

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:140000, 1:nd);
    meanPar(i,:) = mean(parChain);
    
    figure(101); hold on
    for j=1:nd
        [f, x] = ksdensity(parChain(1:end,j));
        subplot(3,3,j);plot(x,f,'LineWidth',3);hold on; %line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3)
    end
    
end

meanParBest = mean(meanPar);
[meanParBest;par_true] % should be similar

figure(1001); hold on
for j=1:nd
    subplot(3,3,j);line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',4)
    subplot(3,3,j);line([meanParBest(j) meanParBest(j)],ylim, 'Color', 'red', 'LineWidth',4)
end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Measured data -- noisy credible intervals
clear

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

i = 1;

nv = 21;

s2Chain = s2_sim{10}(nburnin+1:end);
s2Chain = s2Chain';

M = size(s2Chain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = s2Chain(fix(linspace(1, M, S)),:);

for s=1:S
    
    %     C = mean(s2Chain)*eye(ntp,ntp);
    C = param_mat_noise(s)*eye(ntp,ntp);
    
    for j=1:nv
        if j == 1
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
        else
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j);
            
        end
        
    end
    
end

Y = quantile(NoisyPressures{i},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    figure(j+1); clf(j+1)
    if j==1
        plot(linspace(0,0.11,512), truePressure, '-','Color', 'k','LineWidth',3)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-','Color', [1 0.5 0], 'LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
%     ylim([min(min(Y-0.1)) max(max(Y+0.1)) ])
    ylim([6 25])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_iid/noisyCI_BestLin_iid_vessel %d.fig', j))

    if j==1
        figure(j*100+1); clf(j*100+1)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure', '-','Color', 'k','LineWidth',3)
        hold on
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        
        axis tight; grid on
        ylim([-3.5 3.5])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_iid/NoisyResidCI_BestLin_iid_vessel %d.fig', j))
        
    end
    
end

j=1;
meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
totalVar = varSig + mean(s2Chain);

l_CI = meanCleanPressure - 1.96 * sqrt(totalVar);
u_CI = meanCleanPressure + 1.96 * sqrt(totalVar);

for k=1:10^3
data(k,:) = mvnrnd(meanCleanPressure, mean(s2Chain)*eye(ntp, ntp));
figure(2); hold on
plot(linspace(0,0.11,512), data(k,:))
allIN(k) = (all(data(k,:)<u_CI))&&(all(l_CI<data(k,:)));
end
sum(allIN)/10^3 % proportion of draws completely (100%) inside the credible interval


% predictive CI
figure(1); clf(1)
hold on
plot(linspace(0,0.11,512), truePressure, '-k', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure - 1.96 * sqrt(totalVar), '--g', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure + 1.96 * sqrt(totalVar), '--g', 'Linewidth', 3)

% explanatory CI
Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
figure(1); hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-c', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
axis tight; grid on
ylim([6 25])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B - 1 stiffness and correlated errors

clear

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

i=2;

parChainNoise = par_sim{10}(nburnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    %     w = mean(parChainNoise(:,1));
    %     b = mean(parChainNoise(:,2));
    %
    %     kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));
    %
    %
    %     K = NaN(ntp,ntp);
    %     for k=1:ntp
    %         for j=1:ntp
    %             K(k,j) = kernel(t(k),t(j));
    %         end
    %     end
    %
    %     s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
    %
    %     C = K + s2*eye(ntp,ntp);
    %
    %     %The matrix is probably not symmetric due to round-off.
    %     % For example have a look at
    %     % YourMatrix - YourMatrix.' and you will likely see some non-zero values.
    %     %The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;
    %
    %     if ~issymmetric(C)
    %         C = (C+C')/2; % to fix roundoff errors
    %     end
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        if j == 1
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
        else
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j);
            
        end
        
    end
    
end

j=1;
meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));

w = mean(parChainNoise(:,1));
b = mean(parChainNoise(:,2));

varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));

totalVar = varSig' + varNoise;

figure(1); clf(1)
hold on
plot(linspace(0,0.11,512), truePressure, '-k', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure' - 1.96 .* sqrt(totalVar), '--g', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure' + 1.96 .* sqrt(totalVar), '--g', 'Linewidth', 3)

Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
figure(1); hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-c', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
axis tight; grid on
ylim([6 25])

Y = quantile(NoisyPressures{i},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    figure(j); clf(j)
    if j==1
        plot(linspace(0,0.11,512), truePressure, '-','Color', 'k','LineWidth',3)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-','Color', [1 0.5 0], 'LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
%     ylim([min(min(Y-0.1)) max(max(Y+0.1)) ])
    ylim([6 25])

    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_correl/noisyCI_BestLin_correl_vessel %d.fig', j))
    
    if j==1
        figure(j*100); clf(j*100)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure', '-','Color', 'k','LineWidth',3)
        hold on
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        
        axis tight; grid on
        ylim([-3.5 3.5])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_correl/NoisyResidCI_BestLin_correl_vessel %d.fig', j))
        
    end
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Nonlinear model with exponential stiffness and error correlation

clear

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

i=8;

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    %     w = mean(parChainNoise(:,1));
    %     b = mean(parChainNoise(:,2));
    %
    %     kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));
    %
    %
    %     K = NaN(ntp,ntp);
    %     for k=1:ntp
    %         for j=1:ntp
    %             K(k,j) = kernel(t(k),t(j));
    %         end
    %     end
    %
    %     s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
    %
    %     C = K + s2*eye(ntp,ntp);
    %
    %     %The matrix is probably not symmetric due to round-off.
    %     % For example have a look at
    %     % YourMatrix - YourMatrix.' and you will likely see some non-zero values.
    %     %The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;
    %
    %     if ~issymmetric(C)
    %         C = (C+C')/2; % to fix roundoff errors
    %     end
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        if j == 1
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
        else
            
            NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j);
            
        end
        
    end
    
end

j=1;
meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));

w = mean(parChainNoise(:,1));
b = mean(parChainNoise(:,2));

varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));

totalVar = varSig' + varNoise;

l_CI = meanCleanPressure' - 1.96 .* sqrt(totalVar);
u_CI = meanCleanPressure' + 1.96 .* sqrt(totalVar);

figure(1); clf(1)
hold on
plot(linspace(0,0.11,512), truePressure, '-k', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure' - 1.96 .* sqrt(totalVar), '--g', 'Linewidth', 3)
plot(linspace(0,0.11,512), meanCleanPressure' + 1.96 .* sqrt(totalVar), '--g', 'Linewidth', 3)

Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
figure(1); hold on
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-c', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--m', 'Linewidth', 3)
axis tight; grid on
ylim([6 25])


lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);

gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
    'weightSigma2', w, ...
    'biasSigma2_prior',prior_fixed, ...
    'weightSigma2_prior',prior_fixed);

gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);

[~,C] = gp_trcov(gp, t);

for k=1:10^4
data(k,:) = mvnrnd(meanCleanPressure, C);
%figure(2); hold on
%plot(linspace(0,0.11,512), data)
allIN(k) = (all(data(k,:)<u_CI'))&&(all(l_CI'<data(k,:)));
end
sum(allIN)/10^4 % proportion of draws completely (100%) inside the credible interval

Y = quantile(NoisyPressures{i},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    figure(j+2); clf(j+2)
    if j==1
        plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',3)
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '-','Color', [1 0.5 0], 'LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
%     ylim([min(min(Y-0.1)) max(max(Y+0.1)) ])
    ylim([6 25])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestNonLin_correl/noisyCI_BestNonLin_correl_vessel %d.fig', j))

    if j==1
        figure(j*100+2); clf(j*100+2)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure', '-','Color', 'k','LineWidth',3)
        hold on
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(1,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(3,ntp*(j-1)+1:ntp*j), '--','Color', 'c','LineWidth',3)
        
        axis tight; grid on
        ylim([-3.5 3.5])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestNonLin_correl/NoisyResidCI_BestNonLin_correl_vessel %d.fig', j))
        
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot the 95% explanatory credible intervals and 95% predictive credible
% intervals for the 3 best models
% Measured data -- noisy credible intervals
clear

addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

i = 1;

nv = 21;

s2Chain = s2_sim{10}(nburnin+1:end);
s2Chain = s2Chain';

t = linspace(0,0.11,ntp);

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    totalVar = varSig + mean(s2Chain);
    
    l_CI = meanCleanPressure - 1.96 * sqrt(totalVar);
    u_CI = meanCleanPressure + 1.96 * sqrt(totalVar);
    
    % predictive CI
    figure(j); clf(j)
    hold on

    ciplot(l_CI,u_CI,t,[0.9 0.9 0.9])
    
    % explanatory CI
    Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
    figure(j); hold on
    
    ciplot(Y(1,ntp*(j-1)+1:ntp*j),Y(3,ntp*(j-1)+1:ntp*j),t,[0.7 0.7 0.7])
    plot(t, Y(2,ntp*(j-1)+1:ntp*j), '--r', 'Linewidth', 5)

    if j==1
        plot(t, truePressure, '-k', 'Linewidth', 5)
    end
    
    axis tight; grid on
    ylim([5 25])
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/PredExplCI_Signals_BestLin_iid/CI_BestLin_iid_vessel %d.fig', j))

    
end

%%%%%%%%%%
% Linear B - 1 stiffness and correlated errors

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

i=2;

parChainNoise = par_sim{10}(nburnin+1:end,nd-1:nd);

for j=1:nv
    
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    l_CI = meanCleanPressure - 1.96 * sqrt(totalVar);
    u_CI = meanCleanPressure + 1.96 * sqrt(totalVar);
    
    % predictive CI
    figure(j); clf(j)
    hold on
    
    ciplot(l_CI,u_CI,t,[0.9 0.9 0.9])
    
    % explanatory CI
    Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
    figure(j); hold on
    
    ciplot(Y(1,ntp*(j-1)+1:ntp*j),Y(3,ntp*(j-1)+1:ntp*j),t,[0.7 0.7 0.7])
    
    plot(t, Y(2,ntp*(j-1)+1:ntp*j), '--r', 'Linewidth', 5)
    
    if j==1
        plot(t, truePressure, '-k', 'Linewidth', 5)
    end
    
    axis tight; grid on
    ylim([5 25])
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/PredExplCI_Signals_BestLin_correl/CI_BestLin_correl_vessel %d.fig', j))
    
    
end

%%%%

% Nonlinear model with exponential stiffness and error correlation


load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

i=8;

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);

for j=1:nv
    
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    l_CI = meanCleanPressure - 1.96 * sqrt(totalVar);
    u_CI = meanCleanPressure + 1.96 * sqrt(totalVar);
    
    % predictive CI
    figure(j); clf(j)
    hold on
    
    ciplot(l_CI,u_CI,t,[0.9 0.9 0.9])
    
    % explanatory CI
    Y = quantile(AllPressures{i},[0.025 0.5 0.975],1); % for each row
    figure(j); hold on
    
    ciplot(Y(1,ntp*(j-1)+1:ntp*j),Y(3,ntp*(j-1)+1:ntp*j),t,[0.7 0.7 0.7])
    plot(t, Y(2,ntp*(j-1)+1:ntp*j), '--r', 'Linewidth', 5)
    
    if j==1
        plot(t, truePressure, '-k', 'Linewidth', 5)
    end
    
    axis tight; grid on
    ylim([5 25])
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/PredExplCI_Signals_BestNonLin_correl/CI_BestNonLin_correl_vessel %d.fig', j))
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Now obtain the noisy credible interval for the MPA to populate the table in the paper

clear

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

i = 1;

nv = 21;

s2Chain = s2_sim{10}(nburnin+1:end);
s2Chain = s2Chain';

M = size(s2Chain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = s2Chain(fix(linspace(1, M, S)),:);

for s=1:S
    
    %     C = mean(s2Chain)*eye(ntp,ntp);
    C = param_mat_noise(s)*eye(ntp,ntp);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    varNoise = mean(s2Chain);
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end
% CredISignal{i} should be (21,2)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B - 1 stiffness and correlated errors (emulator)

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

i=2;

parChainNoise = par_sim{10}(nburnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end
% CredISignal{i} should be (21,2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B - Exponential stiffness and iid errors

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_iid_contd.mat')

i = 3;

ntp = 512; nv = 21;

ObjFctChain = ObjFct_sample(n_burnin+1:end);

% I forgot to save the s2 samples from the MCMC simulation
s2Chain = NaN(size(ObjFctChain,1),1);
for k=1:size(ObjFctChain,1)
    s2Chain(k) = 1/gamrnd(a_noisevar+0.5*n, 1/(b_noisevar+0.5*ObjFctChain(k)));
end

M = size(s2Chain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = s2Chain(fix(linspace(1, M, S)),:);

for s=1:S
    
    %     C = mean(s2Chain)*eye(ntp,ntp);
    C = param_mat_noise(s)*eye(ntp,ntp);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    varNoise = mean(s2Chain);
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end
% CredISignal{i} should be (21,2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B - exponential stiffness radius dependent with error correlation

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat') % exponential stiffness radius dependent with correl errors

i=4;

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B with 21 stiffnesses and iid

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part6.mat')

i = 5;

ObjFctChain = ObjFct_sample(8*10^4:end);

s2Chain = s2_noise(8*10^4:end);

M = size(s2Chain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = s2Chain(fix(linspace(1, M, S)),:);

for s=1:S
    
    %     C = mean(s2Chain)*eye(ntp,ntp);
    C = param_mat_noise(s)*eye(ntp,ntp);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    varNoise = mean(s2Chain);
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end
% CredISignal{i} should be (21,2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linear B - 21 stiffnesses with error correlation (simulator)

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

i = 6;

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Nonlinear model with 1 stiffness and error correlation

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear/GPHMC_NN_sampling_RealData_wider.mat')

i = 7;

parChainNoise = par_sim{10}(nburnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Nonlinear model with exponential stiffness and error correlation

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

i=8;

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);

M = size(parChainNoise, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

ntp = 512; nv = 21;
T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for s=1:S
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = AllPressures{i}(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Linear B - 1 stiffness and correlated errors (simulator)

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/AMsimulator_Sampling_1Stiff_errorCorrel_RealData.mat')

i = 9;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:end, 1:nd-2);

parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);


M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);

s=[]; temp = [];

id = 10^5;

nv = 21;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

for s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, HB, cycles, id+s));
    
     for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,q,A,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            flow(ntp*(j-1)+1:ntp*j) = q(:,1);
            area(ntp*(j-1)+1:ntp*j) = A(:,1);
        end
    end
    
    pressure = pressure';     flow = flow';     area = area';

    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
    AllPressures{i}(s,:) = Pressure(s,:);
    
    %
    
    w = param_mat_noise(s,1);
    b = param_mat_noise(s,2);
    
    lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
        'weightSigma2', w, ...
        'biasSigma2_prior',prior_fixed, ...
        'weightSigma2_prior',prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
    
    [~,C] = gp_trcov(gp, t);
    
    for j=1:nv
        
        res = mvnrnd(zeros(ntp,1), C, 1);
        
        NoisyPressures{i}(s,ntp*(j-1)+1:ntp*j) = Pressure(s,ntp*(j-1)+1:ntp*j) + res;
        
        
    end
    
end

for j=1:nv
    meanCleanPressure = mean(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    varSig = var(AllPressures{i}(:,ntp*(j-1)+1:ntp*j));
    
    w = mean(parChainNoise(:,1));
    b = mean(parChainNoise(:,2));
    
    varNoise = (2/pi) .* asin( (1+1./(2.*(b+w.*t.^2))).^(-1));
    
    totalVar = varSig' + varNoise;
    
    CredISignal{i}(j,1) = mean(meanCleanPressure' - 1.96 .* sqrt(totalVar));
    CredISignal{i}(j,2) = mean(meanCleanPressure' + 1.96 .* sqrt(totalVar));
    
end

save('noisyCI_Signals.mat')
