% GPMCMC with correlated errors and one stiffness parameter for the linear
% wall maths model

% Construct an emulator for the log likelihood
clear; close all;

% Add necessary paths ...

%% Load the real data
trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');

trueState = [trueFlow; truePressure];

%% Set necessary parameters
nd = 6; % no of parameters
HB = 12; % no of heartbeats
cycles = 1; % no of cardiac cycles
ntp = size(truePressure,1); % no of time points
% Type of covariance function used for error correlation
% 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
% 4 - periodic; 5 - neural network
gp_ind = 5;

id = 1000*gp_ind; % id for data files
extra_p = [id, nd, HB, cycles];

if gp_ind ~= 5
    % Bounds for original parameters
    l = [2e04, 0.05, 0.05, 0.05, 0.5, 0.001];
    u = [1e05, 2.5,  2.5,  2.5, 1.5,  0.06];
    % Parameter scaling for emulation
    sc = [10^5, 10, 10, 10, 10, 10^(-1)];
    
else
    % Bounds for original parameters
    l = [2e04, 0.05, 0.05, 0.05, 10^4, 1];
    u = [1e05, 2.5, 2.5, 2.5, 90000,   200];
    sc = [10^5, 10, 10, 10, 10^6, 10^3];
end

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded biological parameters theta
% Be(1,1) = Uniform
alp = [1,1,1,1];
bet = [1,1,1,1];
% For GP hyperparameters
% for sq exp, matern 3/2, 5/2, periodic:
% amplitude ~ LogGauss(GPhyperHyper(1), GPhyperHyper(2)),LogGauss(mua,sigma^2)
% lengthscale ~ LogGauss(GPhyperHyper(3), GPhyperHyper(4)),LogGauss(mul,sigma^2)
% cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
% for neural network:
% bias sigma2 ~ Logunif(GPhyperHyper(1), GPhyperHyper(2)),Logunif(loglb, logub)
% weight sigma2 ~ Logunif(GPhyperHyper(3), GPhyperHyper(4)),Logunif(loglw, loguw)
% cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
% cov noise is kept fixed to a small value, e.g. 10^(-6)
if gp_ind ~= 5
    GP_hyperHyper = [log(0.1), 0.095, log(0.0275), 0.1]; % amplitude:log(var(res))
else
    GP_hyperHyper = [l(5), u(5), l(6), u(6)];
end

%% Initial phase: Construct initial GP model
X = sobolset(6, 'Skip',1.4e4,'Leap',0.6e13);

f3_vec = l(1) + (u(1)-l(1)) * X(:,1);
rr1_vec = l(2) + (u(2)-l(2)) * X(:,2);
rr2_vec = l(3) + (u(3)-l(3)) * X(:,3);
cc1_vec = l(4) + (u(4)-l(4)) * X(:,4);
GPhyper1_vec = l(5) + (u(5)-l(5)) * X(:,5); % weight or magnitude
GPhyper2_vec = l(6) + (u(6)-l(6)) * X(:,6); % bias or lengthscale

par = [f3_vec, rr1_vec, rr2_vec, cc1_vec, GPhyper1_vec, GPhyper2_vec]./sc;

corrErr = 1; % we have correlated errors

% Run simulator to obtain log lik for training points
[loglik, pass] = Run_simulator(par, extra_p, truePressure, sc, ...
    gp_ind, corrErr);

pass = logical(pass);

save('GPMCMC_NN_initial_RealData_wider.mat')

%
%%%% INSTEAD OF FINDING THRESHOLD 'BY HAND'
n = size(loglik,1); k = 500; % no of points we want to keep to fit the GP regression
perc = 1-k/n;% keep the (1-k/n)th percentile (the largest k points)
T_ll = quantile(loglik,perc);
%%%

%%% OR
k = 500; % no of points we want to keep to fit the GP regression
temp = sort(loglik, 'descend');
T_ll = temp(k); % the threshold is the lowest loglik value out of the k values we keep to fit the GP regression
%%%

I_ll = loglik>T_ll;

% Construct classifier
x_class = par(I_ll,:); y_class = 2.*pass(I_ll)-1;
% For GP regr only look successful simulations from simulator
x_regr = par(pass&I_ll,:); y_regr = loglik(pass&I_ll);

%%%

mean_y = mean(y_regr);
std_y = std(y_regr);

loglik_max = max(max(loglik(loglik~=-10^10)));
loglik_min = min(min(loglik(loglik~=-10^10)));

y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y

% Build GP model (loglik emulator and classifier)
X_r = sobolset(8, 'Skip',2e12,'Leap',0.9e15); % 9 draw 10 values
n_r = size(X_r, 1);

l_r = [0.1  0.1  0.1  0.1  0.1  0.1 0.1 0.000000001];
u_r = [1 1 1 1 1 1 1 1];

% H_r matrix with magnsigma2, every lengthscale and sigma2 on separate rows
H_r = [l_r(1) + (u_r(1)-l_r(1)) * X_r(:,1), ...
    l_r(2) + (u_r(2)-l_r(2)) * X_r(:,2), ...
    l_r(3) + (u_r(3)-l_r(3)) * X_r(:,3), ...
    l_r(4) + (u_r(4)-l_r(4)) * X_r(:,4), ...
    l_r(5) + (u_r(5)-l_r(5)) * X_r(:,5), ...
    l_r(6) + (u_r(6)-l_r(6)) * X_r(:,6), ...
    l_r(7) + (u_r(7)-l_r(7)) * X_r(:,7), ...
    l_r(8) + (u_r(8)-l_r(8)) * X_r(:,8)];

X_c = sobolset(7, 'Skip',4e8,'Leap',0.9e15); % 8 draw 10 values
n_c = size(X_c, 1);

l_c = [1 1   0.1 0.5  0.5 0.5 0.5];
u_c = [10 20   5   5  5 5 5];
% H_c matrix with magnsigma2, every lengthscale and sigma2 on separate rows
H_c = [l_c(1) + (u_c(1)-l_c(1)) * X_c(:,1), ...
    l_c(2) + (u_c(2)-l_c(2)) * X_c(:,2), ...
    l_c(3) + (u_c(3)-l_c(3)) * X_c(:,3), ...
    l_c(4) + (u_c(4)-l_c(4)) * X_c(:,4), ...
    l_c(5) + (u_c(5)-l_c(5)) * X_c(:,5), ...
    l_c(6) + (u_c(6)-l_c(6)) * X_c(:,6), ...
    l_c(7) + (u_c(7)-l_c(7)) * X_c(:,7)];
	
%H(1)=1;H(end+1:end+6)=0.01*[1 1 1 1 1 1];H(end+1)=exp(-9.950929526405522);
[gp_regr, nlml_regr, gp_class, nlml_class] = ...
    GPmodel(x_regr, y_regr, x_class, y_class, H_r,...
    H_c(1,:), 2, corrErr);

[w,s] = gp_pak(gp_regr);
disp(exp(w))

[w,s] = gp_pak(gp_class);
disp(exp(w))

%Make predictions using gp_regr
[E, Var] = gp_pred(gp_regr, x_regr, y_regr, x_regr);
figure(1); clf(1); plot(y_regr, '.');
hold on; plot(y_regr,y_regr,'-r')
xlabel('Train data'); ylabel('Predictions')

% Make predictions using gp_class
[Eft_la, Varft_la, lpyt_la, Eyt_la, Varyt_la] = ...
    gp_pred(gp_class, x_class, y_class, x_class, ...
    'yt', ones(size(x_class,1),1) );
figure(2); clf(2)
% if good classifier, 2 dots on the plot: one at (0,-1) & another at (1,1)
plot(exp(lpyt_la), y_class, '.', 'markersize', 20)
xlabel('Predictions'); ylabel('Train labels')

save('GPMCMC_NN_initial_RealData_wider.mat')

%% Exploratory phase

load('GPMCMC_NN_initial_RealData_wider.mat')

extraPar_gp = [mean_y, std_y];
x_regr_refitted = x_regr;
y_regr_refitted = y_regr;
gp_regr_refitted = gp_regr;

do_nuts = 0; % run HMC, not NUTS in exploratory phase

do_DA = 1; % do delayed acceptance

% We will run Bayesian optimisation (BO) for HMC tuning performance
% i.e., for optimisation of step size and no of steps in Hamiltonian dynamics

hd = 2; % no of hyperparameters for HMC (epsilon, L)
% Set lower and upper bounds for epsilon and L in HMC to be used in
% Bayesian optimization
if gp_ind ~= 5
    l_HMC = [10^(-5), 5];
    u_HMC = [0.001, 500];
else
    l_HMC = [10^(-5), 5];
    u_HMC = [0.001, 1000];
end

X = sobolset(hd, 'Skip',1.4e4,'Leap',0.45e15); % draw 21 points

np = size(X, 1);

% Use first 20 points from Sobol sequence to build initial GP model
epsilon_init = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(1:np,1);
L_init = fix(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(1:np,2)); % L integer

% Set number of HMC samples to generate for every (eps, L) pair
nSamples = 5;

% Exploratory phase in Rasmussen's paper
phase_ind = 1;

p_sample_init = NaN((nSamples-1)*np+1, nd); % parameter samples from initial stage of BO algorithm
nESJD_init = NaN(np,1); % normalised ESJD from initial stage (only the successful runs (nESJD>0))

ObjFct_sample_init = NaN((nSamples-1)*np+1, 1); % sum-of-square samples from the sampling phase

sigma2 = NaN; S20 = NaN; N0 = NaN;

% Initialise position vector
j = find(y_regr_refitted==max(y_regr_refitted));
p0 = x_regr_refitted(j,:) .* sc; % original scale

p_sample_init(1,1:4) = log((p0(1:4)-l(1:4))./(u(1:4)-p0(1:4))); % unbounded

if gp_ind ~= 5
    p_sample_init(1,5:6) = log(p0(5:6));
else
    p_sample_init(1,5:6) = log((p0(5:6)-l(5:6))./(u(5:6)-p0(5:6))); % unbounded
end

param_extended = p0;

[ObjFct, pass] = Run_simulator(param_extended./sc, ...
    extra_p, truePressure, sc, gp_ind, corrErr);

ObjFct_sample_init(1) = ObjFct;
if pass == 0
    disp('Choose different starting values for the parameters')
end

em_ind = 0; % use simulator for beginning of trajectory
grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
[LogPosterior_sim, ~, ~, ~, ~, ObjFct_begin] = ...
    HMCDerivPosterior_all_MoreEfficient_Generic(p_sample_init(1,:), ...
    sigma2, truePressure, alp, bet, ...
    GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, mean_y, std_y, ...
    do_nuts, corrErr, gp_ind);

ObjFct_begin == ObjFct_sample_init(1)

em_ind = 1;
grad1_SimInd = NaN; grad23_EmInd = [0 0];
[LogPosterior_em, GradLogPost_em] = ...
    HMCDerivPosterior_all_MoreEfficient_Generic(p_sample_init(1,:), ...
    sigma2, truePressure, alp, bet, ...
    GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, mean_y, std_y, ...
    do_nuts, corrErr, gp_ind);

M = eye(nd,nd);
acc = 0;
next = 1; del = 1;

% Runs the initial phase of BO to build initial GP for nESJD
% the normalised expected squared jumping distance, see Wang and Freitas

for j = 1:np-1 % iterate through different (eps, L) pairs
    % to obtain nSamples for each pair
    for i=2:nSamples
        
        next = next + 1;
        [p_sample_init(next,:),LogPosterior_sim,LogPosterior_em,...
            GradLogPost_em,ObjFct_sample_init(next), ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, mean_y, std_y] = ...
            HMC_pulm_MoreEfficient(p_sample_init(next-1,:), sigma2, ...
            epsilon_init(j), L_init(j), ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, phase_ind, truePressure, alp, bet, GP_hyperHyper,...
            extra_p, l, u, sc, LogPosterior_sim, LogPosterior_em, ...
            GradLogPost_em, ObjFct_sample_init(next-1), ...
            mean_y, std_y, do_nuts, corrErr, gp_ind, M, do_DA);
        
        if all(p_sample_init(next,:) ~= p_sample_init(next-1,:)) % i.e. we've just accepted the new point
            acc = acc + 1;         
            
            if acc <= size(y_regr,1) % delete or skip when we've accepted
                if (y_regr_refitted(del) * std_y + mean_y) < T_ll
                    x_regr_refitted(del,:) = []; y_regr_refitted(del) = [];
                else
                    del = del + 1; % skip deleting
                end
            end
            
            % Turn unbounded parameters into original scale to add to GP
            param(1:4) = (u(1:4).*exp(p_sample_init(next,1:4))+l(1:4))./(1+exp(p_sample_init(next,1:4)));
            if gp_ind ~= 5
                param(5:6) = exp(p_sample_init(next,5:6));
            else
                param(5:6) = (u(5:6).*exp(p_sample_init(next,5:6))+l(5:6))./(1+exp(p_sample_init(next,5:6)));
                
            end
            
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point as a consequence of sqrt(Var)>=3,
                % add it as a training point
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1) = ObjFct_sample_init(next); % ObjFct is on original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
                
                %[E, ~] = gp_pred(gp_regr_refitted, x_regr_refitted, y_regr_refitted, x_regr_refitted);
                %[y_regr_refitted(1:10),E(1:10)]
            end
        end
        
    end % nSamples
    
    xj = p_sample_init(next-nSamples+1:next,:);
    nESJD_init(j) = ESJDfct(xj)/sqrt(L_init(j)); % obtain nESJD function values, function to be maximised
    %nESJD_init(j)
end

% Construct data set: ((eps, L), nESJD_init) on which we run initial GP model
% nESJD_init must have np length
sc_E = [10^(-3), 10^3]; % scaling for (eps, L) to be used in GP
x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np,2) size
y_E = nESJD_init(1:np-1);

mean_y_E = mean(y_E);
std_y_E = std(y_E);

y_E = (y_E-mean_y_E)./std_y_E; % mean 0 and std 1 of of y_E

gp_E = GPmodel_BlackBox(x_E, y_E, l_HMC./sc_E, u_HMC./sc_E); % GP model for nESJD

[w,~] = gp_pak(gp_E);
disp(mean(exp(w)))

%Make predictions using gp_E
[E, Var] = gp_pred(gp_E, x_E, y_E, x_E);
figure(1); clf(1); plot(y_E, E, '.', 'markersize', 20);
hold on; plot(y_E,y_E,'-r')
xlabel('Train data'); ylabel('Predictions')

fintime = cputime;
time_preprocessing_AdaptiveHMC=fintime-initime;

save('GPMCMC_NN_exploratory_RealData_wider.mat')


%%%%
% Now run main BO phase

k = 100; alpha = 4; delta = 0.1; % parameters to be used in BO
nSamples = 4; % draw nSamples-1 for every (eps,L) starting from previous run sample
% (that'll be the 1st out of nSamples)
% Set number of HMC samples to generate for every (eps, L) pair
n_adapt_hmc_burnin = floor(200/(nSamples-1)); % no of samples to draw in the burnin phase
n_adapt_hmc = ceil(600/(nSamples-1)); % no of samples to draw in the sampling phase
% total no of samples drawn will be 1 + (nSamples-1)*n_adapt_hmc + (nSamples-1)*n_adapt_hmc_burnin

epsilon_adapt = NaN(1+n_adapt_hmc+n_adapt_hmc_burnin,1); % stores the optimum step size from every BO iteration
L_adapt = NaN(1+n_adapt_hmc+n_adapt_hmc_burnin,1); % stores the optimum no of leapfrog steps from every BO iteration

epsilon_adapt(1) = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(np,1);
L_adapt(1) = fix(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(np,2)); % L integer

p_sample = NaN(1+(n_adapt_hmc+n_adapt_hmc_burnin)*(nSamples-1),nd); % param samples
ObjFct_sample = NaN(1+(n_adapt_hmc+n_adapt_hmc_burnin)*(nSamples-1),1); % loglik samples

nESJD = NaN(1+n_adapt_hmc+n_adapt_hmc_burnin,1); % nESJD samples

duplicate = 1; % no duplicates (eps, L) for regression due to performing optimization
convergence = 0; % has the optimization reached convergence? 0 - no
next = 1;
weight = linspace(0.1, 0.9, n_adapt_hmc_burnin)'; % decreasing weighting for duplicates in burnin phase
weight_ind = 0; % index that keeps track of order in weighting
del_ind = 0; % tracks total no of elements (in burnin+sampling) removed bc they're duplicates

% Initialise position vector
p_sample_init(182:190,:)=[]; ObjFct_sample_init(182:190)=[];
p_sample(1,:) = p_sample_init(end,:);

p0(1:4) = (u(1:4).*exp(p_sample(1,1:4))+l(1:4))./(1+exp(p_sample(1,1:4)));% original scale

if gp_ind ~= 5
    p0(5:6) = exp(p_sample(1,5:6));
else
    p0(5:6) = (u(5:6).*exp(p_sample(1,5:6))+l(5:6))./(1+exp(p_sample(1,5:6)));
    
end

[loglik, pass] = Run_simulator(p0./sc, extra_p, ...
    truePressure, sc, gp_ind, corrErr);

ObjFct_sample(1) = loglik;
if pass == 0
    disp('Choose different starting values for the parameters')
end

em_ind = 0; % use simulator for beginning of trajectory
grad1_SimInd = 1; grad23_EmInd = [NaN NaN];
[LogPosterior_sim, ~, ~, ~, ~, ObjFct_begin] = ...
    HMCDerivPosterior_all_MoreEfficient_Generic(p_sample(1,:), sigma2, ...
    truePressure, alp, bet, ...
    GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, mean_y, std_y, ...
    do_nuts, corrErr, gp_ind);

ObjFct_sample(1) == ObjFct_begin

nESJD_augm = nESJD_init(1:np-1); % this is unscaled
x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np,2) size
x_E_augm = x_E; % already scaled
s = alpha/max(nESJD_augm); % make sure max(nESJD_augm)~=0

next=1; del=1;
acc=0;

for j = 1:n_adapt_hmc+n_adapt_hmc_burnin
    % Run HMC nSample times for [epsilon_adapt(j), L_adapt(j)]
    for i = 2:nSamples
        % Call HMC to get p_sample
        next = next + 1;
        [p_sample(next,:),LogPosterior_sim,LogPosterior_em,...
            GradLogPost_em,ObjFct_sample(next), ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, mean_y, std_y] = ...
            HMC_pulm_MoreEfficient(p_sample(next-1,:), sigma2, ...
            epsilon_adapt(j), L_adapt(j), ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, phase_ind, truePressure, alp, bet, GP_hyperHyper,...
            extra_p, l, u, sc, LogPosterior_sim, LogPosterior_em, ...
            GradLogPost_em, ObjFct_sample(next-1), mean_y, std_y, ...
            do_nuts, corrErr, gp_ind, M, do_DA);
        
        if all(p_sample(next,:) ~= p_sample(next-1,:)) % i.e. we've just accepted the new point
            acc = acc + 1;            
            
            if acc <= size(y_regr,1) % delete or skip when we've accepted
                if (y_regr_refitted(del) * std_y + mean_y) < T_ll
                    x_regr_refitted(del,:) = []; y_regr_refitted(del) = [];
                else
                    del = del + 1; % skip deleting
                end
            end
            
            % Turn unbounded parameters into original scale to add to GP
            param(1:4) = (u(1:4).*exp(p_sample(next,1:4))+l(1:4))./(1+exp(p_sample(next,1:4)));
            if gp_ind ~= 5
                param(5:6) = exp(p_sample(next,5:6));
            else
                param(5:6) = (u(5:6).*exp(p_sample(next,5:6))+l(5:6))./(1+exp(p_sample(next,5:6)));
                
            end
            
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point as a consequence of sqrt(Var)>=3
                
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1) = ObjFct_sample(next); % ObjFct is on original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
                
                [E, ~] = gp_pred(gp_regr_refitted, x_regr_refitted, y_regr_refitted, x_regr_refitted);
                [y_regr_refitted(1:10),E(1:10)]
            end
        end
        
    end % nSamples
    
    %If we have gathered np data points in the sampling phase for the GP,
    %discard the points from the burnin phase (np points)
    %not to affect the inference
    %     if (j == np)
    %         nESJD_augm(1:np) = []; x_E_augm(1:np,:) = [];
    %     end
    
    % Obtain the objective function
    xj = p_sample(next-nSamples+1:next,:);
    nESJD(j) = ESJDfct(xj)/sqrt(L_adapt(j));
    
    % Augment data set with ([eps(j), L(j)], nESJD(j)) regardless of
    % whether (eps, L) is a duplicate or not
    % but only as long as the duplicate is because no optimization has been done
    % and not because we've reached convergence(same eps and L accepted)
    % if convergence, then store the new nESJD, as it'll be slightly
    % different than previous one
    if convergence == 1 || j==1
        nESJD_augm(end) = nESJD(j);
        x_E_augm(end,:) = [epsilon_adapt(j), L_adapt(j)]./sc_E;
    else
        nESJD_augm(end+1) = nESJD(j);
        x_E_augm(end+1,:) = [epsilon_adapt(j), L_adapt(j)]./sc_E;
    end
    % Draw o ~ Unif([0 1])
    o = rand;
    
    % Update parameter for adaptation p_adapt
    pj = (max(j-k+1,1))^(-0.5);
    
    % Conduct the Bayesian Optimization step
    if o > pj || j==1 % no update
        duplicate = duplicate + 1;
        epsilon_adapt(j+1) = epsilon_adapt(j);
        L_adapt(j+1) = L_adapt(j);
        
        if j <= n_adapt_hmc_burnin && j~=1
            weight_ind = weight_ind + 1; % keeps track of weighting index
        end                                   % for duplicates in burnin phase
        
        if j==1
            duplicate=duplicate-1;
        end
    else % update: minimise negative nESJD_augm using BO
        % Check if we have duplicates and average them before fitting gp
        % weighted average in burnin phase and equal average in sampling phase
        if j <= n_adapt_hmc_burnin
            % or if abs(unique(epsilon_adapt)[end]-unique(epsilon_adapt)[end-1] > 10^(-5)
            % && abs(unique(L_adapt)[end]-unique(L_adapt)[end-1] > 10
            disp('burnin phase')
            
            if duplicate ~= 1 % we have previous duplicates, so
                % we average nESJD for previous (eps, L) that are duplicates
                disp('We have duplicates')
                nESJD_weightedavg = (1*nESJD_augm(end) + ...
                    nESJD_augm((end-duplicate+1):(end-1))'* ...
                    weight((weight_ind-duplicate+2):weight_ind))/...
                    (1+sum(weight((weight_ind-duplicate+2):weight_ind)));
                nESJD_augm((end-duplicate+1):end) = [];
                del_ind = del_ind + duplicate;
                nESJD_augm(end+1) = nESJD_weightedavg;
                
                hyp = x_E_augm(end,:);
                x_E_augm((end-duplicate+1):end,:) = [];
                x_E_augm(end+1,:) = hyp;
                
                % else, no previous duplicates, so we use all [x_E_augm,
                % nESJD_augm] to fit the GP
            end
            
        else % sampling phase
            disp('sampling phase')
            
            if duplicate ~= 1 % we have previous duplicates, so
                % we average nESJD for previous (eps, L) that are duplicates
                % from (j-duplicate + 1) to j
                
                disp('We have duplicates')
                nESJDavg = mean(nESJD_augm((end-duplicate+1):end));
                nESJD_augm((end-duplicate+1):end) = [];
                del_ind = del_ind + duplicate;
                nESJD_augm(end+1) = nESJDavg;
                
                hyp = x_E_augm(end,:);
                x_E_augm((end-duplicate+1):end,:) = [];
                x_E_augm(end+1,:) = hyp;
                
                % else, no previous duplicates, so we use all [x_E_augm,
                % nESJD_augm] to fit the GP
            end
        end % j <= n_adapt_hmc_burnin
        
        % Update s, the scale invariance parameter
        if max(nESJD_augm) == nESJD(j)
            s = alpha/nESJD(j);
        end
        
        % Re-train GP
        mean_y_E = mean(nESJD_augm);
        std_y_E = std(nESJD_augm);
        x_E = x_E_augm; y_E = (nESJD_augm - mean_y_E)./std_y_E;
        
        % Refit only if re-optimise hyperparameters
        % gp_E = GPmodel_BlackBox(x_E, y_E, l_HMC./sc_E, u_HMC./sc_E);
        
        
        % Do optimisation of acquisition function
        betaj = 2*log((pi^2*(j+1)^(hd/2+2))/(3*delta));
        fh_ucb = @(x_new) UpperConfBound(x_new, gp_E, x_E, y_E, ...
            mean_y_E, std_y_E, s, pj, betaj);
        % Set the options for optimizer of the acquisition function
        optimf = @fmincon;
        
        optdefault=struct('GradObj','on','LargeScale','off','Display', 'off', ...
            'Algorithm','sqp','TolFun',1e-9,'TolX',1e-6);
        
        options = optimset(optdefault);
        
        nstarts = 12; % multiple restarts since acquisition function usually multimodal
        x0_E = NaN(nstarts, hd);
        x_E_optims = NaN(nstarts, hd); f_E_optims = NaN(nstarts, 1);
        for s1 = 1:nstarts
            % initial epsilon and L for the optimization
            x0_E(s1,:) = l_HMC./sc_E+(u_HMC-l_HMC)./sc_E * rand;
            
            [x_E_optims(s1,:), f_E_optims(s1)] = ...
                optimf(fh_ucb, x0_E(s1,:), [], [], [], [], ...
                l_HMC./sc_E, u_HMC./sc_E, [], options);
            
        end
        
        I_min = find(f_E_optims==min(f_E_optims));
        x_E_optim = x_E_optims(I_min(1),:);
        f_E_optim = f_E_optims(I_min(1));
        
        %x_E_optim.*sc_E
        
        % Store new optimum
        epsilon_adapt(j+1) = x_E_optim(1)*sc_E(1);
        L_adapt(j+1) = fix(x_E_optim(2)*sc_E(2)); % L integer
        
        % Check for convergence of optimization
        if epsilon_adapt(j+1) == epsilon_adapt(j) && ...
                L_adapt(j+1) == L_adapt(j)
            convergence = 1;
        else
            convergence = 0;
        end
        
        duplicate = 1; % no duplicate because of not doing optimization
        
    end % o>pj
    
end %n_adapt_hmc

save('GPMCMC_NN_exploratorycomplete_RealData_wider.mat')


% Now discard some of the samples - burnin phase
% (training points for the GP) for which log lik values
% are below some threshold T_ll
% to keep training points drawn from high posterior probability regions
y_regr_refitted = y_regr_refitted * std_y + mean_y;
k = 500; % no of points we want to keep to fit the GP regression
temp = sort(y_regr_refitted, 'descend');
T_ll = temp(k);
I_ll = find(y_regr_refitted > T_ll);
y_regr_refitted = y_regr_refitted(I_ll);
mean_y = mean(y_regr_refitted);
std_y = std(y_regr_refitted);

y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
x_regr_refitted = x_regr_refitted(I_ll,:);

% Refit GP with burnin phase removed
% Use this GP in the sampling phase
gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);

save('GPMCMC_NN_exploratorycomplete_RealData_wider.mat')

%% Sampling phase with AM

load('GPMCMC_NN_exploratorycomplete_RealData_wider.mat')

nrun = 10; % run 10 chains in parallel
nSamples = 5000; % no of sampling phase samples
nburnin = 100; % no of burnin phase samples
em_int = 50; % emulation interval (before evaluating PDEs)
phase_ind = 2; % sampling phase
adapt_int = 10; % adaptation interval (in AM)
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-8),nd,1));
extraPar_gp = [mean_y, std_y];
corrErr = 1; % correlated errors

delete(gcp('nocreate'))
parpool('local', nrun)

par_sim = cell(nrun,1); % parameter samples from the sampling phase
ObjFct_sim = cell(nrun,1); % sum-of-square samples from the sampling phase

% Initialise parameter chain
for j = 1:nrun
    par_sim{j}(1,:) = x_regr_refitted(end-25*j,:) .* sc;
end

sigma2 = NaN;
S20 = NaN; % prior for sigma2
N0 = NaN; % prior accuracy for S20

parfor j = 1:nrun %parfor
    extra_p = [1000*gp_ind+j, nd, HB, cycles];
    em_ind = 0; % use simulator for beginning of trajectory
    ObjFct = mice_pulm_ss(par_sim{j}(1,:),truePressure,...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, ...
        extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);
    
    if ObjFct ~= 1
        ObjFct_sim{j}(1) = ObjFct;
    else
        disp('Choose different starting values for the parameters')
    end
end

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
sample_sigma = NaN; % sample sigma2 only for uncorrelated errors
acc = zeros(nrun,1); % acceptance rate for every chain

% Store cpu times for every run and average the at the end
initime = NaN(nrun,1);
fintime = NaN(nrun,1);

% Run 10 chains in parallel from different initialisations and different
% random seed generators
parfor j = 1:nrun %parfor
    
    initime(j) = cputime;
    
    extra_p = [1000*gp_ind+j, nd, HB, cycles];
    % covariance update uses these to store previous values
    covchain = []; meanchain = []; wsum = []; lasti = 0;
    R = chol(cov_MH);
    for i=2:nSamples+nburnin
        % for every i^th sample, run the trajectory
        [par_sim{j}(i,:), ObjFct_sim{j}(i)] = ...
            AMtrj_informative(par_sim{j}(i-1,:), sigma2, R, em_int, extra_p, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, truePressure, l, u, sc, phase_ind, ...
            ObjFct_sim{j}(i-1), extraPar_gp, gp_ind, corrErr, alp, bet, GP_hyperHyper);
        if all(par_sim{j}(i,:) ~= par_sim{j}(i-1,:)) % just accepted the new point
            acc(j) = acc(j) + 1;
            %disp(sprintf('accept for run %d', j))
            %par_sim{j}(i,:);
        end
        
        
        if mod(i, adapt_int) == 0 % we adapt
            %disp('we adapt')
            if scale == 1 % calculate the chain covariance for the transformed parameters
                [covchain,meanchain,wsum] = covupd(par_sim{j}((lasti+1):i,1:nd)./sc,1, ...
                    covchain,meanchain,wsum);
            else
                [covchain,meanchain,wsum] = covupd(par_sim{j}((lasti+1):i,1:nd),1, ...
                    covchain,meanchain,wsum);
            end
            
            upcov = covchain; % update covariance based on past samples
            
            [Ra,p] = chol(upcov);
            if p % singular
                % try to blow it
                [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
                if p == 0 % choleski decomposition worked
                    % scale R
                    R = Ra * qcov_scale;
                end
            else
                R = Ra * qcov_scale;
            end
            
            lasti = i;
            
        end
        
    end
    
    fintime(j) = cputime;
    
end%parfor

time_HMC_AM=mean(fintime-initime);

%save('GPMCMC_NN_sampling_RealData_wider.mat')
save('GPHMC_NN_samplingAM_corrErr.mat')

exit;