%%

clear

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_lin1s_iid = median(parChain); % equivalent of quantile(parChain, 0.5);
ci_par_lin1s_iid = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_iid, HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=1; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_lin1s_iid = pressure';     flow_lin1s_iid = flow';     area_lin1s_iid = area';

RSS_lin1s_iid = sum((pressure_lin1s_iid(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid pressure_lin1s_iid ...
    flow_lin1s_iid area_lin1s_iid RSS_lin1s_iid pressure_v1  area_v1

% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_lin1s_corr = median(parChain);
ci_par_lin1s_corr = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_corr(1:end-2), HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=2; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_lin1s_corr = pressure';     flow_lin1s_corr = flow';     area_lin1s_corr = area';

RSS_lin1s_corr = sum((pressure_lin1s_corr(1:ntp)-truePressure).^2);

%%%%%%%%%%%%%%
% Check Em vs Simulator
% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/AMsimulator_Sampling_1Stiff_errorCorrel_RealData.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);

med_par_lin1s_corr_sim = median(parChain);
ci_par_lin1s_corr_sim = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_corr_sim(1:end-2), HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        
    end
end

pressure_lin1s_corr_sim = pressure';     flow_lin1s_corr_sim = flow';     area_lin1s_corr_sim = area';

RSS_lin1s_corr_sim = sum((pressure_lin1s_corr_sim(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim pressure_v1  area_v1
 
% Linear B - Exponential stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_iid_contd.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);

med_par_linExpos_iid = median(parChain);
ci_par_linExpos_iid = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_linExpos_iid, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=3; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_linExpos_iid = pressure';     flow_linExpos_iid = flow';     area_linExpos_iid = area';

RSS_linExpos_iid = sum((pressure_linExpos_iid(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_linExpos_iid ci_par_linExpos_iid ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...
    pressure_linExpos_iid flow_linExpos_iid  area_linExpos_iid ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid ...
    pressure_v1  area_v1

% Linear B - Exponential stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);

med_par_linExpos_corr = median(parChain);
ci_par_linExpos_corr = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_linExpos_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=4; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_linExpos_corr = pressure';     flow_linExpos_corr = flow';     area_linExpos_corr = area';

RSS_linExpos_corr = sum((pressure_linExpos_corr(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_linExpos_iid ci_par_linExpos_iid med_par_linExpos_corr ci_par_linExpos_corr ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...
    pressure_linExpos_iid flow_linExpos_iid area_linExpos_iid ...
    pressure_linExpos_corr flow_linExpos_corr area_linExpos_corr ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid ...
    RSS_linExpos_corr pressure_v1  area_v1

% Linear B - 21 stiffness and iid errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part6.mat')

parChain = p_sample(8*10^4:end, 1:nd);

med_par_lin21s_iid = median(parChain);
ci_par_lin21s_iid = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', med_par_lin21s_iid, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=5; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_lin21s_iid = pressure';     flow_lin21s_iid = flow';     area_lin21s_iid = area';

RSS_lin21s_iid = sum((pressure_lin21s_iid(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_linExpos_iid ci_par_linExpos_iid med_par_linExpos_corr ci_par_linExpos_corr ...
    med_par_lin21s_iid ci_par_lin21s_iid ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...
    pressure_linExpos_iid flow_linExpos_iid area_linExpos_iid ...
    pressure_linExpos_corr flow_linExpos_corr area_linExpos_corr ...
    pressure_lin21s_iid flow_lin21s_iid area_lin21s_iid ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid ...
    RSS_linExpos_corr RSS_lin21s_iid pressure_v1  area_v1

% Linear B - 21 stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

parChain = p_sample(end/2+1:end, 1:nd);

med_par_lin21s_corr = median(parChain);
ci_par_lin21s_corr = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
    med_par_lin21s_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=6; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_lin21s_corr = pressure;     flow_lin21s_corr = flow';     area_lin21s_corr = area';

RSS_lin21s_corr = sum((pressure_lin21s_corr(1:ntp)'-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_linExpos_iid ci_par_linExpos_iid med_par_linExpos_corr ci_par_linExpos_corr ...
    med_par_lin21s_iid ci_par_lin21s_iid med_par_lin21s_corr ci_par_lin21s_corr ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...   
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...
    pressure_linExpos_iid flow_linExpos_iid area_linExpos_iid ...
    pressure_linExpos_corr flow_linExpos_corr area_linExpos_corr ...
    pressure_lin21s_iid flow_lin21s_iid area_lin21s_iid ...
    pressure_lin21s_corr flow_lin21s_corr area_lin21s_corr ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid RSS_linExpos_corr ...
    RSS_lin21s_iid RSS_lin21s_corr pressure_v1  area_v1

% Nonlinear model with 1 stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear/GPMCMC_NN_sampling_RealData_widerStiff.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_nonlin1s_corr = median(parChain);
ci_par_nonlin1s_corr = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', med_par_nonlin1s_corr(1:end-2), HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=7; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_nonlin1s_corr = pressure';     flow_nonlin1s_corr = flow';     area_nonlin1s_corr = area';

RSS_nonlin1s_corr = sum((pressure_nonlin1s_corr(1:ntp)-truePressure).^2);

%%

clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_nonlin1s_corr ci_par_nonlin1s_corr ...
    med_par_linExpos_iid ci_par_linExpos_iid med_par_linExpos_corr ci_par_linExpos_corr ...
    med_par_lin21s_iid ci_par_lin21s_iid med_par_lin21s_corr ci_par_lin21s_corr ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...    
    pressure_nonlin1s_corr flow_nonlin1s_corr area_nonlin1s_corr ...
    pressure_linExpos_iid flow_linExpos_iid area_linExpos_iid ...
    pressure_linExpos_corr flow_linExpos_corr area_linExpos_corr ...
    pressure_lin21s_iid flow_lin21s_iid area_lin21s_iid ...
    pressure_lin21s_corr flow_lin21s_corr area_lin21s_corr ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid ...
    RSS_linExpos_corr RSS_lin21s_iid RSS_lin21s_corr RSS_nonlin1s_corr pressure_v1  area_v1

% Nonlinear model with exponential stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:i, 1:nd);

med_par_nonlinExpos_corr = median(parChain);
ci_par_nonlinExpos_corr = quantile(parChain, [0.025 0.975]);

nv = 21; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', med_par_nonlinExpos_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    if j~=1
        pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
        area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
    else
        pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        flow(ntp*(j-1)+1:ntp*j) = q(:,1);
        area(ntp*(j-1)+1:ntp*j) = A(:,1);
        %
        m=8; pressure_v1(ntp*(m-1)+1:ntp*m) = p(:,floor(end/2)); 
             area_v1(ntp*(m-1)+1:ntp*m) = A(:,floor(end/2));
    end
end

pressure_nonlinExpos_corr = pressure';     flow_nonlinExpos_corr = flow';     area_nonlinExpos_corr = area';

RSS_nonlinExpos_corr = sum((pressure_nonlinExpos_corr(1:ntp)-truePressure).^2);


clearvars -except med_par_lin1s_iid ci_par_lin1s_iid med_par_lin1s_corr ci_par_lin1s_corr ...
    med_par_lin1s_corr_sim ci_par_lin1s_corr_sim ...
    med_par_nonlin1s_corr ci_par_nonlin1s_corr med_par_nonlinExpos_corr ci_par_nonlinExpos_corr ...
    med_par_linExpos_iid ci_par_linExpos_iid med_par_linExpos_corr ci_par_linExpos_corr ...
    med_par_lin21s_iid ci_par_lin21s_iid med_par_lin21s_corr ci_par_lin21s_corr ...
    pressure_lin1s_iid flow_lin1s_iid area_lin1s_iid pressure_lin1s_corr flow_lin1s_corr area_lin1s_corr ...
    pressure_lin1s_corr_sim flow_lin1s_corr_sim area_lin1s_corr_sim ...    
    pressure_linExpos_iid flow_linExpos_iid area_linExpos_iid ...
    pressure_linExpos_corr flow_linExpos_corr area_linExpos_corr ...
    pressure_lin21s_iid flow_lin21s_iid area_lin21s_iid ...
    pressure_lin21s_corr flow_lin21s_corr area_lin21s_corr ...
    pressure_nonlin1s_corr flow_nonlin1s_corr area_nonlin1s_corr ...
    pressure_nonlinExpos_corr flow_nonlinExpos_corr area_nonlinExpos_corr ...
    RSS_lin1s_iid RSS_lin1s_corr RSS_lin1s_corr_sim RSS_linExpos_iid RSS_linExpos_corr ...
    RSS_lin21s_iid RSS_lin21s_corr RSS_nonlin1s_corr ...
    RSS_nonlinExpos_corr pressure_v1 area_v1

%%%%%%%%%%%%%%%%%%%%%%
Pressure(:,1) = pressure_lin1s_iid; Pressure(:,2) = pressure_lin1s_corr;
Pressure(:,3) = pressure_linExpos_iid; Pressure(:,4) = pressure_linExpos_corr;
Pressure(:,5) = pressure_lin21s_iid; Pressure(:,6) = pressure_lin21s_corr;
Pressure(:,7) = pressure_nonlin1s_corr; Pressure(:,8) = pressure_nonlinExpos_corr;

Flow(:,1) = flow_lin1s_iid; Flow(:,2) = flow_lin1s_corr;
Flow(:,3) = flow_linExpos_iid; Flow(:,4) = flow_linExpos_corr;
Flow(:,5) = flow_lin21s_iid; Flow(:,6) = flow_lin21s_corr;
Flow(:,7) = flow_nonlin1s_corr; Flow(:,8) = flow_nonlinExpos_corr;

Area(:,1) = area_lin1s_iid; 
Area(:,2) = area_lin1s_corr;
Area(:,3) = area_linExpos_iid; Area(:,4) = area_linExpos_corr;
Area(:,5) = area_lin21s_iid; Area(:,6) = area_lin21s_corr;
Area(:,7) = area_nonlin1s_corr; Area(:,8) = area_nonlinExpos_corr;

ntp = 512;

for i=1:8
    Area(1:ntp,i) = area_v1(ntp*(i-1)+1:ntp*i);
end

temp = reshape(Area, 512, 21, 8);

figure;plot(1:512,temp(:,1,1))

bla1=max(temp); bla2(1:21,1:8)=bla1(1,:,:);bla2=bla2';
standMaxfc = max(bla2);
bla3=min(temp); bla4(1:21,1:8)=bla3(1,:,:);bla4=bla4';
standMinfc = min(bla4);

for k=1:8
for j=1:21
    Area_standard(ntp*(j-1)+1:ntp*j,k) = (temp(:,j,k)-standMinfc(j))/(standMaxfc(j)-standMinfc(j));
end
end
 
ntp = 512; nv=21;

figure(1002); clf(1002)

for k=1:8
for j=1:nv
    
    subplot(5,5,j);

    if j~=1
        plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),'LineWidth',2); hold on
        axis tight
        xlim([min(min(Pressure)) max(max(Pressure)) ]);
        ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
    else
        plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),'LineWidth',2); hold on
        axis tight
        xlim([min(min(Pressure)) max(max(pressure_v1)) ]);
        ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
    end
end
end

Symb = {'--', '--', '--', '--', '--', '--', '-', '-'};
for j=1:nv
    figure(j); clf(j)
    for k=1:8
        if j~=1
            if k==6
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', 'c'); hold on
            elseif k==8
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', 'r'); hold on
            else
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
            end
            axis tight; grid on;  set(gca, 'YTickLabel', [], 'XTickLabel', [])
            xlim([min(min(Pressure)) max(max(pressure_v1)) ]);
            ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
        else
            if k==6
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', 'c'); hold on
            elseif k==8
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', 'r'); hold on
            else
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',5, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
            end
            axis tight;  grid on;
            xlim([min(min(Pressure)) max(max(pressure_v1)) ]);
            ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
        end
    end
    if j==1
        legend('lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
    end
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/PressureArea/PressureArea_vessel %d.fig', j))
end

Symb = {'--', '--', '--', '--', '--', '--', '-', '-'};
figure(101);clf(101)
for j=2:nv
    subplot(4,5,j-1)
    for k=1:8
        if j~=1
            if k==6
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', 'c'); hold on
            elseif k==8
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', 'r'); hold on
            else
                plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
            end
            axis tight; grid on;  set(gca, 'YTickLabel', [], 'XTickLabel', [])
            xlim([min(min(Pressure)) max(max(pressure_v1)) ]);
            ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
        else
            if k==6
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', 'c'); hold on
            elseif k==8
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', 'r'); hold on
            else
                plot(pressure_v1(ntp*(k-1)+1:ntp*k), Area_standard(ntp*(j-1)+1:ntp*j,k),Symb{k}, ...
                    'LineWidth',3, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
            end
            axis tight;  grid on;
            xlim([min(min(Pressure)) max(max(pressure_v1)) ]);
            ylim([min(min(Area_standard)) max(max(Area_standard)) ]);
        end
    end
end
legend('lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/PressureArea/PressureArea_vessels2to21')

figure(1003); clf(1003)

for k=1:8
for j=1:nv
    
    subplot(5,5,j);
    
    if j~=1
        plot(Pressure(ntp*(j-1)+1:ntp*j,k), Area(ntp*(j-1)+1:ntp*j,k),'LineWidth',2); hold on
        
        axis tight
        xlim([min(min(Pressure)) max(max(Pressure)) ]);
    else
        plot(pressure_v1(ntp*(j-1)+1:ntp*j,k), Area(ntp*(j-1)+1:ntp*j,k),'LineWidth',2); hold on
        
        axis tight
        xlim([min(min(pressure_v1)) max(max(pressure_v1)) ]);
    end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Best linear iid versus correlated errors
% (kernel densities and scatterplots)
clear
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

Par = par_sim{10}(nburnin+1:10:end,:); Par = Par';

figure(2);clf(2)
subplot(2,3,1);plot(Par(1,:),Par(2,:),'.', 'Color', [0.5 0.5 0.5], 'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('f_3');ylabel('r_1')
set(gca, 'XTick', linspace(min(Par(1,:)),max(Par(1,:)),2), ...
        'YTick', linspace(min(Par(2,:)),max(Par(2,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';
subplot(2,3,2);plot(Par(1,:),Par(3,:),'.', 'Color', [0.5 0.5 0.5],'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('f_3');ylabel('r_2')
set(gca, 'XTick', linspace(min(Par(1,:)),max(Par(1,:)),2), ...
        'YTick', linspace(min(Par(3,:)),max(Par(3,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';
subplot(2,3,3);plot(Par(1,:),Par(4,:),'.', 'Color', [0.5 0.5 0.5],'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('f_3');ylabel('c')
set(gca, 'XTick', linspace(min(Par(1,:)),max(Par(1,:)),2), ...
        'YTick', linspace(min(Par(4,:)),max(Par(4,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';
subplot(2,3,4);plot(Par(2,:),Par(3,:),'.', 'Color', [0.5 0.5 0.5],'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('r_1');ylabel('r_2')
set(gca, 'XTick', linspace(min(Par(2,:)),max(Par(2,:)),2), ...
        'YTick', linspace(min(Par(3,:)),max(Par(3,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';
subplot(2,3,5);plot(Par(2,:),Par(4,:),'.', 'Color', [0.5 0.5 0.5],'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('r_1');ylabel('c')
set(gca, 'XTick', linspace(min(Par(2,:)),max(Par(2,:)),2), ...
        'YTick', linspace(min(Par(4,:)),max(Par(4,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';
subplot(2,3,6);plot(Par(3,:),Par(4,:),'.', 'Color', [0.5 0.5 0.5],'Markersize', 25);axis tight
set(gca, 'FontSize',20)
xlabel('r_2');ylabel('c')
set(gca, 'XTick', linspace(min(Par(3,:)),max(Par(3,:)),2), ...
        'YTick', linspace(min(Par(4,:)),max(Par(4,:)),2))
ax = gca; ax.YAxis.TickLabelFormat = '%.2f'; ax.XAxis.TickLabelFormat = '%.2f';

parnames = {'stiffness','r_1','r_2','c'};
figure(3);clf(3);
for i=1:nd-2
[f, x] = ksdensity(Par(i,1:end));
subplot(2,2,i);plot(x,f,'Color', [0.5 0.5 0.5],'LineWidth',3);
xlabel(parnames(i));ylabel('pdf'); set(gca, 'FontSize',20);axis tight;
end

%%%%%%%

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

Par = par_sim{10}(nburnin+1:10:end-2,:); Par = Par';

figure(2);hold on
subplot(2,3,1);hold on; plot(Par(1,:),Par(2,:),'.k', 'Markersize', 25);
subplot(2,3,2);hold on; plot(Par(1,:),Par(3,:),'.k', 'Markersize', 25);
subplot(2,3,3);hold on; plot(Par(1,:),Par(4,:),'.k', 'Markersize', 25);
subplot(2,3,4);hold on; plot(Par(2,:),Par(3,:),'.k', 'Markersize', 25);
subplot(2,3,5);hold on; plot(Par(2,:),Par(4,:),'.k', 'Markersize', 25);
subplot(2,3,6);hold on; plot(Par(3,:),Par(4,:),'.k', 'Markersize', 25);
legend('correlated', 'iid')

parnames = {'f_3','r_1','r_2','c'};

figure(3);hold on
for i=1:4
[f, x] = ksdensity(Par(i,1:end));
subplot(2,2,i);hold on;plot(x,f,'-k', 'LineWidth',3);xlabel(parnames(i));set(gca, 'FontSize',20);axis tight;
end
legend('correlated', 'iid')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Best linear vs best nonlinear
clear
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

Par = par_sim{10}(nburnin+1:end,1:nd-2);

figure;[S,AX,BigAx,H,HAx] = plotmatrix(Par);

for i=1:size(Par,2)
    for j=1:size(Par,2)
        S(i,j).Color = 'k';
        S(i,j).MarkerSize = 5;
    end
    H(i).EdgeColor = 'k';
    H(i).FaceColor = 'k';
end

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

Par = p_sample(nburnin+1:100:end,1:nd-2);

r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018], 'descend');

Par_mod(:,1) = Par(:,1).*exp(Par(:,2).*r0(10)) + Par(:,3);
Par_mod(:,2:5) = Par(:,4:end);

figure;[S,AX,BigAx,H,HAx] = plotmatrix(Par_mod);

for i=1:size(Par_mod,2)
    for j=1:size(Par_mod,2)
        S(i,j).Color = 'k';
        S(i,j).MarkerSize = 5;
    end
    H(i).EdgeColor = 'k';
    H(i).FaceColor = 'k';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Constant stiffness vs systolic, diastolic, pulse pressure
clear
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/AMsimulator_Sampling_1Stiff_errorCorrel_RealData.mat')

r0 = sort([0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
    0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
    0.015, 0.022, 0.018], 'descend');

f3 = [10^4, 2*10^4, 3*10^4, 4*10^4, 5*10^4, 6*10^4, 7*10^4, 8*10^4, ...
    9*10^4, 10^5, 1.2*10^5, 1.4*10^5, 1.6*10^5, 1.8*10^5, 2*10^5, ...
    2.2*10^5, 2.4*10^5, 2.6*10^5, 2.8*10^5, 3*10^5, ...
    3.2*10^5, 3.4*10^5, 3.6*10^5, 3.8*10^5, 4*10^5, ...
    4.2*10^5, 4.4*10^5, 4.6*10^5, 4.8*10^5, 5*10^5];

param = []; pass = NaN(numel(f3),1);
ObjFct3 = NaN(numel(f3),1);
sysp = zeros(numel(f3),1); diasp = zeros(numel(f3),1); pulsep = zeros(numel(f3),1);

l = 4*10^3;

parfor i=1:numel(f3)
    param=[f3(i),p_sample(l,2:end)];
    [ObjFct3(i), pass(i), Z, C, L, pressure3] = Run_simulator(param./sc, [10^6+i extra_p(2:end)], ...
        truePressure, sc, gp_ind, corrErr);
    if pass(i)~=0
        sysp(i) = max(pressure3(1:512));
        diasp(i) = min(pressure3(512/2:512));
        pulsep(i) = sysp(i)-diasp(i);
    end
    
    Pressure(i,:) = pressure3;
end

figure(100); clf(100)
subplot(3,1,1);plot(f3, sysp,'.', 'Color', [0.5 0.5 0.5], 'Markersize', 30); ylabel('systolic pressure')
hold on
plot(5*10^4, 21.5, 'xk', 'Markersize', 40, 'linewidth', 5)
%title('Constant stiffness versus pressure')
set(gca, 'FontSize', 20)
subplot(3,1,2);plot(f3, diasp,'.', 'Color', [0.5 0.5 0.5], 'Markersize', 30); ylabel('diastolic pressure')
hold on
plot(5*10^4, 11.05, 'xk', 'Markersize', 40, 'linewidth', 5)
set(gca, 'FontSize', 20)
subplot(3,1,3);plot(f3, pulsep,'.', 'Color', [0.5 0.5 0.5],'Markersize', 30); xlabel('f_3'); ylabel('pulse pressure')
hold on
plot(5*10^4, 10.5, 'xk', 'Markersize', 30, 'linewidth', 5)
set(gca, 'FontSize', 20)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Stiffness vs r0 when no parametric form assumed, i.e. from the 21 stiffness analysis

clear

% Linear B - 21 stiffnesses with error correlation (simulator)

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

r0 = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
    0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
    0.015, 0.022, 0.018];

Y = quantile(p_sample(end/2+1:end,1:nv),[0.025 0.5 0.975],1); % for each row

figure(1);clf(1)
plot(r0, Y(1,:), '.k', 'Markersize' , 20)
hold on
plot(r0, Y(2,:), 'xk', 'Markersize' , 20)
plot(r0, Y(3,:), 'ok', 'Markersize' , 10)
xlabel('Vessel radii r0'); ylabel('Stiffness values')
legend('2.5th percentile', '50th percentile', '97.5th percentile')
%title('Stiffness per vessel radius')
set(gca, 'FontSize', 12)

minInd = find(ObjFct_sample==min(ObjFct_sample)); minInd = minInd(1);
maxInd = find(ObjFct_sample==max(ObjFct_sample)); maxInd = maxInd(1);

figure(2);clf(2)
plot(r0, p_sample(minInd,1:nv), '.', 'Markersize' , 20)
hold on
plot(r0, p_sample(maxInd,1:nv), '.', 'Markersize' , 20)
xlabel('Radii r0'); ylabel('Stiffness')
legend('Min RSS', 'Max RSS')
title('Stiffness per vessel radius')

figure(3);clf(3)
plot(r0, p_sample(10000,1:nv), '.', 'Markersize' , 30)
hold on
plot(r0, p_sample(50000,1:nv), 'x', 'Markersize' , 30)
plot(r0, p_sample(100000,1:nv), 'o', 'Markersize' , 30)
plot(r0, p_sample(150000,1:nv), '+', 'Markersize' , 30)
xlabel('Radii r0'); ylabel('Stiffness')
title('Stiffness per vessel radius - Random draws')

figure(4);clf(4)
plotmatrix(p_sample(10001:100:end,1:nbio))
title('Pairwise ')


% 21 stiffness iid
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part2_PDEconv_contd.mat') 
Par = p_sample(50001:end,1:nbio); Par = Par';

parnames = {'stiff 1','r_1','r_2','c'};
figure(3);clf(3);
for i=1:nbio
[f, x] = ksdensity(Par(i,:));
subplot(4,6,i);plot(x,f,'LineWidth',3);set(gca, 'FontSize',20);axis tight;
end

parnames = {'stiffness','r_1','r_2','c'};

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB_MultipleStiffness/AMsimulator_Sampling_errorCorrel.mat')
Par = p_sample(50001:end,1:nbio); Par = Par';

figure(3);hold on
for i=1:nbio
[f, x] = ksdensity(Par(i,:));
subplot(4,6,i);hold on;plot(x,f,'LineWidth',3);set(gca, 'FontSize',20);axis tight;
end
legend('iid', 'correlated')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5%%%%
%% Resistance and Compliance for terminal arteries
clear

r0 = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018];

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

stiff_par = median(parChain(:,1:3));
figure(200);clf(200)
plot(r0, stiff_par(1).*exp(stiff_par(2).*r0) + stiff_par(3), '.g', 'Markersize', 20) % nonlinear model
hold on
plot(r0, 10^4 * 5.1682, '.k', 'Markersize', 20) % this is median posterior distribution value for f3 from best linear model
xlabel('r0'); ylabel('Eh/r0')
set(gca, 'Fontsize', 20)
legend('Best Nonlinear', 'Best Linear')

ind_terminalV = [4, 6, 8, 10, 11, 12, 14, 16, 18, 19, 20]+1;

R1_init = [510.4072231, 388.0002164, 538.8259481, 466.9618518, 1807.757766, ...
1173.676967, 266.0796751, 1041.232548, 107.1125395, 116.974148, 83.43084455];
R2_init = [2041.628892, 1552.000866, 2155.303792, 1867.847407, 7231.031065, ...
4694.70787, 1064.3187, 4164.930191, 428.4501579, 467.896592, 333.7233782];
C_init = [0.005254628, 0.006912367, 0.004977489, 0.00574351, 0.001483606, ...
0.002389967, 0.01054214, 0.00269397, 0.026187868, 0.023980077, 0.033621248];

% Nonlin
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')
parChain = p_sample(n_burnin+1:i, 1:nd);
Wk_nonlin = median(parChain(:,5:nd-2));
R1_nonlin = R1_init .* Wk_nonlin(1);
R2_nonlin = R2_init .* Wk_nonlin(2);
C_nonlin = C_init .* Wk_nonlin(3);
R_total_nonlin = R1_nonlin + R2_nonlin;

% Lin
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')
parChain = par_sim{10}(nburnin+1:end, 1:nd);
Wk_lin = median(parChain(:,2:nd));
R1_lin = R1_init .* Wk_lin(1);
R2_lin = R2_init .* Wk_lin(2);
C_lin = C_init .* Wk_lin(3);
R_total_lin = R1_lin + R2_lin;
figure(200); clf(200)
plot(r0(ind_terminalV), R_total_nonlin, '.g', 'Markersize', 20)
hold on
plot(r0(ind_terminalV), R_total_lin, '.k', 'Markersize', 20)
xlim([min(r0) max(r0)])
xlabel('r0 (terminal arteries)')
ylabel('Total resistance R1+R2')
legend('Best Nonlinear', 'Best Linear')
set(gca, 'FontSize', 20)
figure(201); clf(201)
subplot(1,2,1)
plot(r0(ind_terminalV), R1_nonlin, '.g', 'Markersize', 20)
hold on
plot(r0(ind_terminalV), R1_lin, '.k', 'Markersize', 20)
xlim([min(r0) max(r0)])
xlabel('r0 (terminal arteries)')
ylabel('Resistance R1')
legend('Best Nonlinear', 'Best Linear')
set(gca, 'FontSize', 20)
subplot(1,2,2)
plot(r0(ind_terminalV), R2_nonlin, '.g', 'Markersize', 20)
hold on
plot(r0(ind_terminalV), R2_lin, '.k', 'Markersize', 20)
xlim([min(r0) max(r0)])
xlabel('r0 (terminal arteries)')
ylabel('Resistance R2')
set(gca, 'FontSize', 20)

figure(202); clf(202)
plot(r0(ind_terminalV), C_nonlin, '.g', 'Markersize', 20)
hold on
plot(r0(ind_terminalV), C_lin, '.k', 'Markersize', 20)
xlim([min(r0) max(r0)])
xlabel('r0 (terminal arteries)')
ylabel('Compliance C')
legend('Best Nonlinear', 'Best Linear')
set(gca, 'FontSize', 20)

% Now load results from multiobjective optimisation for best lin and best
% nonlin where we keep the WK param fixed across models
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/MultiObjOptimisation.mat')
par_lin = x_ps1(end,[1 end-2:end]);
par_nonlin = x_ps1(end,[4:7 end-2:end]);
Wk_common = x_ps1(end,end-2:end);
R1_common = R1_init .* Wk_common(1);
R2_common = R2_init .* Wk_common(2);
C_common = C_init .* Wk_common(3);

figure(203); clf(203)
subplot(1,3,1)
plot(r0(ind_terminalV), R1_common, '.g', 'Markersize', 20)
xlabel('r0 (terminal arteries)')
ylabel('Resistance R1')
set(gca, 'FontSize', 20)
subplot(1,3,2)
plot(r0(ind_terminalV), R2_common, '.g', 'Markersize', 20)
xlabel('r0 (terminal arteries)')
ylabel('Resistance R2')
set(gca, 'FontSize', 20)
subplot(1,3,3)
plot(r0(ind_terminalV), C_common, '.g', 'Markersize', 20)
xlabel('r0 (terminal arteries)')
ylabel('Compliance C')
set(gca, 'FontSize', 20)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot mean pressure vs r0 for best linear and best nonlinear model
clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parChain = par_sim{10}(nburnin+1:end, 1:nd-2);
med_par_lin1s_corr = median(parChain);
id=10^6;
cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_corr, HB, cycles, id));
for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
    
end

pressure_lin1s_corr = pressure';

pressure_lin1s_corr_mean = mean(pressure_lin1s_corr);

% Nonlinear model with exponential stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

parChain = p_sample(n_burnin+1:i, 1:nd);

med_par_nonlinExpos_corr = median(parChain);

nv = 21; ntp = 512;

id = 10^6;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', med_par_nonlinExpos_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
    
end

pressure_nonlinExpos_corr = pressure';

pressure_nonlinExpos_corr_mean = mean(pressure_nonlinExpos_corr);

%
r0 = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018];
%
figure(23); clf(23)
plot(r0,pressure_lin1s_corr_mean, '.k', 'Markersize', 20)
hold on
plot(r0,pressure_nonlinExpos_corr_mean, '.g', 'Markersize', 20)
plot(r0(1),mean(truePressure), '.r', 'Markersize', 20)
xlabel('r0 (cm)'); ylabel('Mean Pressure (mmHg)')
axis tight
title('Mean pressure versus vessel radius')
set(gca, 'FontSize',15)

%%% Now with parameter estimates from the multiobjective optimisation (keeping the wk param common to the linear and nonlinear model)

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/MultiObjOptimisation.mat')


par_lin = x_ps1(end,[1 end-2:end]);
par_nonlin = x_ps1(end,[4:7 end-2:end]);

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

nv=21; ntp=512;

id=10^6;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', par_lin, HB_lin, cycles_lin, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
    
end

pressure_lin1s_corr = reshape(pressure,ntp,nv);

pressure_lin1s_corr_mean = mean(pressure_lin1s_corr,1);

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

id = 10^6;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', par_nonlin, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,q,A,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
    
end

pressure_nonlinExpos_corr = reshape(pressure,ntp,nv);

pressure_nonlinExpos_corr_mean = mean(pressure_nonlinExpos_corr,1);

%
figure(24); clf(24)
plot(r0,pressure_lin1s_corr_mean, '.k', 'Markersize', 20)
hold on
plot(r0,pressure_nonlinExpos_corr_mean, '.g', 'Markersize', 20)
plot(r0(1),mean(truePressure), '.r', 'Markersize', 20)
xlabel('r0 (cm)'); ylabel('Mean Pressure (mmHg)')
axis tight
title('Mean pressure versus vessel radius')
set(gca, 'FontSize',15)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now also re-do the plotmatrix for linear exponential with black colours
% Linear B - Exponential stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);
figure;[S,AX,BigAx,H,HAx] = plotmatrix(parChain);

for i=1:size(parChain,2)
    for j=1:size(parChain,2)
        S(i,j).Color = 'k';
    end
    H(i).EdgeColor = 'k';
    H(i).FaceColor = 'k';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the clean and noisy credible width intervals for the pressure predictions for all the
% models
load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/CI_Signals')
cleanCredISignal = CredISignal;

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/noisyCI_Signals')
noisyCredISignal = CredISignal;

r0 = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, 0.017, ...
0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
0.015, 0.022, 0.018];

for j=1:nv
    sprintf('%d & %0.2f & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f) & %0.2f (%0.2f %0.2f) (%0.2f %0.2f)', ...
        j, r0(j), ...
        cleanCredISignal{1}(2,j), cleanCredISignal{1}(1,j), cleanCredISignal{1}(3,j), noisyCredISignal{1}(j,1), noisyCredISignal{1}(j,2), ...
        cleanCredISignal{2}(2,j), cleanCredISignal{2}(1,j), cleanCredISignal{2}(3,j), noisyCredISignal{2}(j,1), noisyCredISignal{2}(j,2), ...
        cleanCredISignal{9}(2,j), cleanCredISignal{9}(1,j), cleanCredISignal{9}(3,j), noisyCredISignal{9}(j,1), noisyCredISignal{9}(j,2), ...
        cleanCredISignal{3}(2,j), cleanCredISignal{3}(1,j), cleanCredISignal{3}(3,j), noisyCredISignal{3}(j,1), noisyCredISignal{3}(j,2), ...
        cleanCredISignal{4}(2,j), cleanCredISignal{4}(1,j), cleanCredISignal{4}(3,j), noisyCredISignal{4}(j,1), noisyCredISignal{4}(j,2), ...
        cleanCredISignal{5}(2,j), cleanCredISignal{5}(1,j), cleanCredISignal{5}(3,j), noisyCredISignal{5}(j,1), noisyCredISignal{5}(j,2), ...
        cleanCredISignal{6}(2,j), cleanCredISignal{6}(1,j), cleanCredISignal{6}(3,j), noisyCredISignal{6}(j,1), noisyCredISignal{6}(j,2), ...
        cleanCredISignal{7}(2,j), cleanCredISignal{7}(1,j), cleanCredISignal{7}(3,j), noisyCredISignal{7}(j,1), noisyCredISignal{7}(j,2), ...
        cleanCredISignal{8}(2,j), cleanCredISignal{8}(1,j), cleanCredISignal{8}(3,j), noisyCredISignal{8}(j,1), noisyCredISignal{8}(j,2))
end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot of the residuals
%%

clear

% Linear B - 1 stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPMCMC_sampling_RealData_iid.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_lin1s_iid = median(parChain); % equivalent of quantile(parChain, 0.5);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_iid, HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu); 
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
end

pressure_lin1s_iid = pressure';

res_lin1s_iid = pressure_lin1s_iid-truePressure;

%%
clearvars -except pressure_lin1s_iid res_lin1s_iid

% Linear B - 1 stiffness and correlated errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/GPHMC_NN_samplingAM_corrErr.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_lin1s_corr = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_lin1s_corr(1:end-2), HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);   
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);  
end

pressure_lin1s_corr = pressure';

res_lin1s_corr = pressure_lin1s_corr-truePressure;

%%

clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr

% Linear B - Exponential stiffness and iid errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_iid_contd.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);

med_par_linExpos_iid = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_linExpos_iid, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);       
end

pressure_linExpos_iid = pressure';

res_linExpos_iid = pressure_linExpos_iid-truePressure;

%%
clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid

% Linear B - Exponential stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/RealData_MPA/AMsimulator_Sampling_ExpoStiff_errorCorrel.mat')

parChain = p_sample(n_burnin+1:end, 1:nd);

med_par_linExpos_corr = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', med_par_linExpos_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);      
end

pressure_linExpos_corr = pressure';

res_linExpos_corr = pressure_linExpos_corr-truePressure;

%%

clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid pressure_linExpos_corr res_linExpos_corr 

% Linear B - 21 stiffness and iid errors
cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_iid_contd_part6.mat')

parChain = p_sample(8*10^4:i, 1:nd);

med_par_lin21s_iid = median(parChain);
ci_par_lin21s_iid = quantile(parChain, [0.025 0.975]);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', med_par_lin21s_iid, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);       
end

pressure_lin21s_iid = pressure'; 

res_lin21s_iid = pressure_lin21s_iid-truePressure;


%%

clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid pressure_linExpos_corr res_linExpos_corr ...
    pressure_lin21s_iid res_lin21s_iid

% Linear B - 21 stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_21Stiffness/AMsimulator_Sampling_errorCorrel_contd_part2.mat')

parChain = p_sample(end/2+1:end, 1:nd);

med_par_lin21s_corr = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %d', ...
    med_par_lin21s_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu); 
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);  
end

pressure_lin21s_corr = pressure';  

res_lin21s_corr = pressure_lin21s_corr-truePressure;

%%

clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid pressure_linExpos_corr res_linExpos_corr ...
    pressure_lin21s_iid res_lin21s_iid pressure_lin21s_corr res_lin21s_corr

% Nonlinear model with 1 stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_NonLinear/GPMCMC_NN_sampling_RealData_widerStiff.mat')

parChain = par_sim{10}(nburnin+1:end, 1:nd);

med_par_nonlin1s_corr = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', med_par_nonlin1s_corr(1:end-2), HB, cycles, id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);      
end

pressure_nonlin1s_corr = pressure';   

res_nonlin1s_corr = pressure_nonlin1s_corr-truePressure;

%%

clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid pressure_linExpos_corr res_linExpos_corr ...
    pressure_lin21s_iid res_lin21s_iid pressure_lin21s_corr res_lin21s_corr ...
    pressure_nonlin1s_corr res_nonlin1s_corr

% Nonlinear model with exponential stiffness and error correlation

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness')

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_Nonlinear_ExpoStiffness/AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get uncertainty bounds on all vessels

parChain = p_sample(n_burnin+1:i, 1:nd);

med_par_nonlinExpos_corr = median(parChain);

nv = 1; ntp = 512;

id = 10^4;

cx = unix(sprintf('./sor06 %f %f %f %f %f %f %f %d', med_par_nonlinExpos_corr(1:end-2), id));

for j=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', j, id));
    [~,~,p,~,~,~] = gnuplot(pu);
    pressure(ntp*(j-1)+1:ntp*j) = p(:,1);        
end

pressure_nonlinExpos_corr = pressure'; 

res_nonlinExpos_corr = pressure_nonlinExpos_corr-truePressure;

%% 
clearvars -except pressure_lin1s_iid res_lin1s_iid pressure_lin1s_corr res_lin1s_corr ...
    pressure_linExpos_iid res_linExpos_iid pressure_linExpos_corr res_linExpos_corr ...
    pressure_lin21s_iid res_lin21s_iid pressure_lin21s_corr res_lin21s_corr ...
    pressure_nonlin1s_corr res_nonlin1s_corr pressure_nonlinExpos_corr res_nonlinExpos_corr

figure(1); clf(1)
k=1;plot(linspace(0,0.11, 512/2), res_lin1s_iid(1:2:end), '--', ...
    'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=2;plot(linspace(0,0.11, 512/2), res_lin1s_corr(1:2:end), '--', ...
'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=3;plot(linspace(0,0.11, 512/2), res_linExpos_iid(1:2:end), '--', ...
'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=4;plot(linspace(0,0.11, 512/2), res_linExpos_corr(1:2:end), '--', ...
'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=5;plot(linspace(0,0.11, 512/2), res_lin21s_iid(1:2:end), '--', ...
    'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=6;plot(linspace(0,0.11, 512/2), res_lin21s_corr(1:2:end), '--', ...
    'Color', 'cyan', 'Linewidth', 5); hold on
k=7;plot(linspace(0,0.11, 512/2), res_nonlin1s_corr(1:2:end), '-', ...
'Color', [0.2 0.2 0.2]+0.1*k,'Linewidth', 5); hold on
k=8;plot(linspace(0,0.11, 512/2), res_nonlinExpos_corr(1:2:end), '-', ...
'Color', 'red','Linewidth', 5); hold on
xlabel('Time (s)'); ylabel('Residuals')
set(gca, 'Fontsize', 15)
axis tight
legend('A', 'B', 'D', 'E', 'F', 'G', 'H', 'I')

savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/Residuals.fig')


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot credible intervals (taken from UQboundsPlotting.m)
%%%%%%

% load the already saved CI for the signals

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

% Best linear iid
Y = quantile(AllPressures{1},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',3, 'Color', 'k')
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(Y)) max(max(truePressure+0.1)) ])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_iid/CI_BestLin_iid_vessel %d.fig', j))

end

%%%%%

% Best linear correl

Y = quantile(AllPressures{2},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',3, 'Color', 'k')
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(Y)) max(max(Y+0.1)) ])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_correl/CI_BestLin_correl_vessel %d.fig', j))

end

%%%%%

% Best linear iid vs correl

Y_lin_iid = quantile(AllPressures{1},[0.025 0.5 0.975],1); % for each row
Y_lin_correl = quantile(AllPressures{2},[0.025 0.5 0.975],1); % for each row

% both in one plot
for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),-(truePressure'-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)),'--r', 'LineWidth',3)
        hold on
        plot(linspace(0,0.11,512),-(truePressure'-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)),'--m', 'LineWidth',3)
        
    end
    hold on
    plot(linspace(0,0.11,512), -(Y_lin_iid(1,ntp*(j-1)+1:ntp*j)-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), -(Y_lin_iid(3,ntp*(j-1)+1:ntp*j)-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)
    hold on
    plot(linspace(0,0.11,512), -(Y_lin_correl(1,ntp*(j-1)+1:ntp*j)-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)), '-c','LineWidth',3)
    plot(linspace(0,0.11,512), -(Y_lin_correl(3,ntp*(j-1)+1:ntp*j)-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)), '-c','LineWidth',3)
    
     if j==1
         legend('Residuals iid', ...
             '2.5^{th} perc residuals iid', '97.5^{th} perc residuals iid', ...
             'Residuals correl', ...
             '2.5^{th} perc residuals correl', '97.5^{th} perc residuals correl')
     end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([-2.3 3])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/LinIID_vs_LinCORREL/CI_LinIID_vs_LinCORREL_vessel %d.fig', j))

end

% in two separate plots
% IID
for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),-(truePressure'-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)),'--r', 'LineWidth',3)
    end
    hold on
    plot(linspace(0,0.11,512), -(Y_lin_iid(1,ntp*(j-1)+1:ntp*j)-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), -(Y_lin_iid(3,ntp*(j-1)+1:ntp*j)-Y_lin_iid(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)

    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([-2.3 3])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/LinIID/CI_LinIID_vessel %d.fig', j))

end
% CORREL
for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),-(truePressure'-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)),'--r', 'LineWidth',3)   
    end
    hold on
    plot(linspace(0,0.11,512), -(Y_lin_correl(1,ntp*(j-1)+1:ntp*j)-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), -(Y_lin_correl(3,ntp*(j-1)+1:ntp*j)-Y_lin_correl(2,ntp*(j-1)+1:ntp*j)), '-g','LineWidth',3)
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([-2.3 3])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/LinCORREL/CI_LinCORREL_vessel %d.fig', j))

end

%%%%%

% Best nonlinear correl

Y = quantile(AllPressures{8},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',3, 'Color', 'k')
    end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated (median)', '95% CI')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(Y)) max(max(Y+0.1)) ])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestNonLin_correl/CI_BestNonLin_correl_vessel %d.fig', j))

end

%%%%%

% Best linear correl vs nest nonlinear correl

Y_lin = quantile(AllPressures{2},[0.025 0.5 0.975],1); % for each row
Y_nonlin = quantile(AllPressures{8},[0.025 0.5 0.975],1); % for each row

for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'LineWidth',3, 'Color', 'k')
    end
    hold on
    plot(linspace(0,0.11,512), Y_lin(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y_lin(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y_lin(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    hold on
    plot(linspace(0,0.11,512), Y_nonlin(2,ntp*(j-1)+1:ntp*j), '--m','LineWidth',3)
    plot(linspace(0,0.11,512), Y_nonlin(1,ntp*(j-1)+1:ntp*j), '-c','LineWidth',3)
    plot(linspace(0,0.11,512), Y_nonlin(3,ntp*(j-1)+1:ntp*j), '-c','LineWidth',3)
    
    if j==1
        legend('Measured', 'Generated linear (median)', ...
            '2.5^{th} perc linear', '97.5^{th} perc linear', ...
            'Generated nonlinear (median)', '2.5^{th} perc nonlinear', '97.5^{th} perc nonlinear')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    %xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(min(Y_lin)), min(min(Y_nonlin))) max(max(max(Y_lin+0.1)), max(max(Y_nonlin+0.1)))])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/CI_Signals/BestLin_vs_BestNonLin/CI_BestLin_vs_BestNonLin_vessel %d.fig', j))

end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot the predictions (taken from UQboundsPlotting.m)
%%%%%%

% load the already saved median for the PRESSURE signals

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Pressures_all8models.mat')

Symb = {'--', '--', '--', '--', '--', '--', '-', '-'};

for j=1:nv
    
    figure(j); clf(j)
    
    if j==1
        plot(linspace(0,0.11,512),truePressure,'-k','LineWidth',5); hold on
    end
    
    for k=1:8
        
        Y = quantile(AllPressures{k},0.5,1); % for each row
        
        if k==6
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', 'c'); hold on
        elseif k==8
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', 'r'); hold on
        else
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
        end
        
    end
    
    if j==1
        legend('Measured', 'lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
    end
    
    if j~=1
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    axis tight; grid on;
    ylim([min(min(AllPressures{5}-0.1)) max(max(truePressure+0.1)) ])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/PressurePredictions/PressurePredictions_vessel %d.fig', j))
    
end

figure(101);clf(101)
for j=2:nv
    
subplot(4,5,j-1)

    if j==1
        plot(linspace(0,0.11,512),truePressure,'-k','LineWidth',3); hold on
    end
    
    for k=1:8
        
        Y = quantile(AllPressures{k},0.5,1); % for each row
        
        if k==6
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', 'c'); hold on
        elseif k==8
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', 'r'); hold on
        else
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
        end
        
    end
    
            set(gca, 'XTickLabel', '', 'YTickLabel', '')
    
    axis tight; grid on;
    ylim([min(min(AllPressures{5}-0.1)) max(max(truePressure+0.1)) ])
    set(gca, 'FontSize',20)
    
    
end
        legend('lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
    savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/PressurePredictions/PressurePredictions_vessels2to21.fig')

%
% load the already saved median for the FLOW signals

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/Flows_all8models.mat')

Symb = {'--', '--', '--', '--', '--', '--', '-', '-'};

nv = 21; ntp = 512;

for j=1:nv
    
    figure(j); clf(j)
    
    for k=1:8
        
        Y = quantile(AllFlows{k},0.5,1); % for each row
        
        if k==6
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', 'c'); hold on
        elseif k==8
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', 'r'); hold on
        else
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',5, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
        end
        
    end
    
    if j==2
        legend('lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
    end
    
    if j~=2
        set(gca, 'XTickLabel', '', 'YTickLabel', '')
    end
    
    axis tight; grid on;
    ylim([min(min(AllFlows{5}-0.01)) max(max(AllFlows{1}+0.01)) ])
    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/FlowPredictions/FlowPredictions_vessel %d.fig', j))
    
end

figure(101); clf(101)
for j=2:nv
    
subplot(4,5,j-1)   

    for k=1:8
        
        Y = quantile(AllFlows{k},0.5,1); % for each row
        
        if k==6
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', 'c'); hold on
        elseif k==8
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', 'r'); hold on
        else
            plot(linspace(0,0.11,512), Y(ntp*(j-1)+1:ntp*j),Symb{k}, ...
                'LineWidth',3, 'Color', [0.2 0.2 0.2]+0.1*k); hold on
        end
        
    end
    
                set(gca, 'XTickLabel', '', 'YTickLabel', '')

    axis tight; grid on;
    ylim([min(min(AllFlows{5}-0.01)) max(max(AllFlows{1}+0.01)) ])
    set(gca, 'FontSize',20)
        
end
 legend('lin1s iid','lin1s correl','lin expo s iid','lin expo s correl','lin 21s iid','21s correl','nonlin 1s','nonlin expo s')
    savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/FlowPredictions/FlowPredictions_vessels2to21.fig')

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter finding: checking if we recover the ground truth parameter
% value for 20 data instantiations without the rejection mechanism
clear

GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/CommonFunctions')

% Linear B - Simulated data (1 vessel: MPA) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

% parameter space

parChainCombined = [];

ntp = 512;

SumPressure = zeros(ntp,1);

for i=1:20
    load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))

    nd = size(p_sample, 2);
    
    parChain{i} = p_sample(10^4+1:8*10^4, 1:nd);
    AvgPar(i,:) = mean(parChain{i});
    parChainCombined = [parChainCombined; parChain{i}];
    
    SumPressure = SumPressure + truePressure;
end

AvgPressure = SumPressure./20;

mean_par_paramFinding = mean(AvgPar); % gives the average par value ver 20 different data instantiations
ci_par_paramFinding = quantile(parChainCombined, [0.025 0.975]);

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

parnames = {'f_1', 'f_2', 'f_3', 'r_1', 'r_2', 'c', 'error correl par 1', 'error correl par 2'};
figure(1); clf(1)
for i=1:nd
[f, x] = ksdensity(parChainCombined(:,i));
subplot(3,3,i);plot(x,f,'LineWidth',3, 'Color', [0.5 0.5 0.5]); xlabel(parnames(i))
hold on; line([par_true(i) par_true(i)],ylim, 'Color', 'black', 'LineWidth',3)
hold on; line([mean_par_paramFinding(i) mean_par_paramFinding(i)],ylim, 'Color', [0.8 0.8 0.8], 'LineWidth',3)
end

% functional space
M = size(parChainCombined, 1); % no of chain iterations

S = 500; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChainCombined(fix(linspace(1, M, S)),:);

delete(gcp('nocreate'))
parpool('local', 20)

id = 10^7;

nv = 21;

Pressure = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = param_mat(s,:);
    
    cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s));
        [~,~,p,~,~,~] = gnuplot(pu);
        if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
        else
            pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
        end
    end
    
    pressure = pressure';
    
    Pressure(s,:) = pressure;
    
end

figure(2); clf(2)

Y = quantile(Pressure,[0.025 0.5 0.975],1); % for each row

j=1;
subplot(1,2,1);
hold on
plot(linspace(0,0.11,512), AvgPressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
j=21;
subplot(1,2,2);
hold on
plot(linspace(0,0.11,512), AvgPressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% iid versus correlated on correlated synthetic data
%
clear

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

% parameter space

parChainCombined_iid = []; parChainCombined_correl = [];

ntp = 512;

SumPressure_iid = zeros(ntp,1); SumPressure_correl = zeros(ntp,1);

for i=1:20
    load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    nd = size(p_sample, 2);
    
    parChain_iid{i} = p_sample(10^4+1:13*10^4, 1:nd);
    AvgPar_iid(i,:) = mean(parChain_iid{i});
    parChainCombined_iid = [parChainCombined_iid; parChain_iid{i}];
    
    SumPressure_iid = SumPressure_iid + truePressure;
    
    load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))

    nd = size(p_sample, 2);
    
    parChain_correl{i} = p_sample(10^4+1:13*10^4, 1:nd-2);
    AvgPar_correl(i,:) = mean(parChain_correl{i});
    parChainCombined_correl = [parChainCombined_correl; parChain_correl{i}];
    
    SumPressure_correl = SumPressure_correl + truePressure;
    
end

AvgPressure_iid = SumPressure_iid./20;

mean_par_iid = mean(AvgPar_iid); % gives the average par value ver 20 different data instantiations
ci_par_iid = quantile(parChainCombined_iid, [0.025 0.975]);

AvgPressure_correl = SumPressure_correl./20;

mean_par_correl = mean(AvgPar_correl); % gives the average par value ver 20 different data instantiations
ci_par_correl = quantile(parChainCombined_correl, [0.025 0.975]);


par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

parnames = {'f_1', 'f_2', 'f_3', 'r_1', 'r_2', 'c'};
l = [-10^6, -320, 3.2*10^4, 0.024, 0.5, 0.55];
u = [1.12e+07, 25, 5.2*10^4, 0.8, 1.2, 2.6];

figure(2); clf(2); figure(3); clf(3)
for i=1:6
for j=15:17%20
[f_iid, x_iid] = ksdensity(parChain_iid{j}(:,i));
[f_corr, x_corr] = ksdensity(parChain_correl{j}(:,i));
figure(2); subplot(3,2,i);plot(x_iid,f_iid,'LineWidth',3, 'Color', [0.5 0.5 0.5]); 
xlim ([l(i),u(i)]); %axis tight
xlabel(parnames(i)); hold on
figure(3); subplot(3,2,i);plot(x_corr,f_corr,'LineWidth',3, 'Color', [0.5 0.5 0.5]); 
xlim ([l(i),u(i)]); axis tight
xlabel(parnames(i)); hold on
end
figure(2); hold on; line([par_true(i) par_true(i)],ylim, 'Color', 'black', 'LineWidth',3, 'LineStyle', '--')
figure(3); hold on; line([par_true(i) par_true(i)],ylim, 'Color', 'black', 'LineWidth',3, 'LineStyle', '--')
%hold on; line([mean_par_iid(i) mean_par_iid(i)],ylim, 'Color', 'black', 'LineWidth',5)
end
figure(2);savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/IID_vs_CORREL/Synthetic_IID')
figure(3);savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/IID_vs_CORREL/Synthetic_CORREL')

% agglomerated posterior distribution parameter space
parnames = {'f_1', 'f_2', 'f_3', 'r_1', 'r_2', 'c'};
figure(4); clf(4)
for j=1:nd-2
    [f, x] = ksdensity(parChainCombined_iid(:,j));
    subplot(2,3,j);plot(x,f,'LineWidth',3, 'Color', [0.5 0.5 0.5]);hold on; %line([meanParBest_1v(j) meanParBest_1v(j)],ylim, 'Color', 'b', 'LineWidth',3)
    [f, x] = ksdensity(parChainCombined_correl(:,j));
    subplot(2,3,j);plot(x,f,'LineWidth',3, 'Color', [0.8 0.8 0.8]);hold on; %line([meanParBest_21v(j) meanParBest_21v(j)],ylim, 'Color', 'y', 'LineWidth',3) 
    axis tight; xlabel(parnames(j))
    hold on; line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3, 'LineStyle', '--')
    set(gca, 'FontSize', 15)
end
subplot(2,3,1); ylabel('pdf')
subplot(2,3,4); ylabel('pdf')

% Compute the posterior distribution of the true parameter for every data
% set, for every error model; and take the average over the data sets
% the post distr which makes the correct error model should have higher
% average posterior distribution

% Do it marginally per parameter first
for i=1:6
    for j=1:20
        [postDistrTrueParam_correl(i,j), xi, bw] = ksdensity(parChain_correl{j}(:,i),par_true(i));
    end
end
avgPostDistrTrueParam_correl = mean(postDistrTrueParam_correl,2);
medPostDistrTrueParam_correl = median(postDistrTrueParam_correl,2);

for i=1:6
    for j=1:20
        postDistrTrueParam_iid(i,j) = ksdensity(parChain_iid{j}(:,i),par_true(i));
    end
end
avgPostDistrTrueParam_iid= mean(postDistrTrueParam_iid,2);
medPostDistrTrueParam_iid= median(postDistrTrueParam_iid,2);

[avgPostDistrTrueParam_iid, avgPostDistrTrueParam_correl] % iid versus correl
[medPostDistrTrueParam_iid, medPostDistrTrueParam_correl] % iid versus correl

%
%%% Show the residuals
% IID
for i=1:nrun
    
    cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')
    
    load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    nd = size(p_sample, 2);
    
    parChain = p_sample(10^4+1:13*10^4, 1:nd);
    
    s2Chain = s2_sample(10^4+1:13*10^4);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    param_mat_noise = s2Chain(fix(linspace(1, M, S)));
    
    id = 10^5;
    
    nv = 21; ntp = 512;
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
                    
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
            
            C = param_mat_noise(s)*eye(ntp,ntp);
            
            res = mvnrnd(zeros(ntp,1), C, 1);

            pressure(ntp*(j-1)+1:ntp*j) = pressure(ntp*(j-1)+1:ntp*j) + res;
            
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    NoisyPressure_iid{i} = Pressure;
    
    Y = quantile(NoisyPressure_iid{i},[0.025 0.5 0.975],1); % for each row
    
    figure(i+10);clf(i+10)
        
    j=1;
    subplot(1,2,1);
    hold on
    plot(linspace(0,0.11,512), truePressure', '-','Color', 'k','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    
    axis tight; grid on
    ylim([6 22])

    set(gca, 'FontSize',20)
    
    %
    subplot(1,2,2);
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure', '-','Color', 'k','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    
    axis tight; grid on
    ylim([-3 3])

    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/IID_vs_CORREL/noisyCI_IID_dataInst %d.fig', i))
    
end

clear

% CORREL
for i=1:nrun
    
    cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')
    
    load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    nd = size(p_sample, 2);
    
    parChain = p_sample(10^4+1:13*10^4, 1:nd-2);
    
    parChainNoise = p_sample(10^4+1:13*10^4, end-1:end);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);
    id = 10^5;
    
    ntp = 512; nv = 21;
    T = 0.11;
    deltaT = T/(ntp-1);
    t = 0:deltaT:T;
    
    t = t';
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
        
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
            
            w = param_mat_noise(s,1);
            b = param_mat_noise(s,2);
            
            lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
            
            gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
                'weightSigma2', w, ...
                'biasSigma2_prior',prior_fixed, ...
                'weightSigma2_prior',prior_fixed);
            
            gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
            
            [~,C] = gp_trcov(gp, t);
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            pressure(ntp*(j-1)+1:ntp*j) = pressure(ntp*(j-1)+1:ntp*j) + res;
            
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    NoisyPressure_correl{i} = Pressure;
    
    Y = quantile(NoisyPressure_correl{i},[0.025 0.5 0.975],1); % for each row
    
    figure(i+20);clf(i+20)
        
    j=1;
    subplot(1,2,1);
    hold on
    plot(linspace(0,0.11,512), truePressure', '-','Color', 'k','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    
    axis tight; grid on
    ylim([6 22])

    set(gca, 'FontSize',20)
    
    %
    subplot(1,2,2);
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure', '-','Color', 'k','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',3)
    
    axis tight; grid on
    ylim([-4 4])

    set(gca, 'FontSize',20)
    
    savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/IID_vs_CORREL/noisyCI_CORREL_dataInst %d.fig', i))
    
    
end

%%% WAIC for comparison between error models
% Linear B - exponential stiffness radius dependent with iid (simulator)

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

for j=1:20
    
    load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', j))
    
    id = 10^7; nv = 1; hd = 0; nbio = 6; nd = nbio + hd; T = 0.11; ntp = 512;
    gp_ind = NaN; em_ind = 0; corrErr = 0; loc = 2; extra_p = [id, hd, gp_ind, T, loc];
    l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
    u = [10^7, -50, 6*10^4, 2.5,  2.5,  2.5];
    % Parameter scaling
    sc = max(abs(l),abs(u));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate WAIC
    S = 1000; % no of PDE param samples to use for WAIC
    
    parChain = p_sample(10^4+1:???,:);
    
    ObjFctChain = ObjFct_sample(10^4+1:???);
    
    s2Chain = s2_sample(10^4+1:???);
    
    M = size(parChain, 1); % no of chain iterations
    
    n = size(truePressure,1);
    
    % There is correlation in the data, so we thin the chain and take every
    % 5^th chain sample (i.e. take 1000 PDE param samples from the posterior
    % and get every individual ss(i) for every data point i, i=1,...512)
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    % find corresponding s2 estimate for the s^th chain sample
    s2 = s2Chain(fix(linspace(1, M, S)));
    
    rss_waic = NaN(n, S);
    
    for s = 1:S
    
        param = param_mat(s,:);
    
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id));
    
        state = CreateData_Optim(id);
        pressure = state(end/2+1:end);
    
        rss_waic(:,s) = (pressure - truePressure).^2;
    
    end
    
    % Calculate lpd
    lpd = 0;
    pd = NaN(n,S); % stores p(y_i|theta_s)
    log_pd = NaN(n,S); % stores log(p(y_i|theta_s))
    for i = 1:n
        for s = 1:S
            % n = 1 in calc_logLik because we only use one y_i
            log_pd(i,s) = calc_logLik(rss_waic(i,s), s2(s), 1); %log(p(y_i|theta_s))
            pd(i,s) = exp(log_pd(i,s)); %p(y_i|theta_s);
        end
        lpd = lpd + log(mean(pd(i,:))); % add log(1/S * sum p(y_i|s)) for every i
    end
    
    % Calculate p_waic
    p_waic = 0;
    for i = 1:n
        p_waic = p_waic + calc_var(log_pd(i,:), S);
    end
    
    WAIC_LinB_ExpoStiff_iid(j) = -2*(lpd - p_waic);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate DIC
    
    param = mean(parChain);
    
    sigma2 = mean(s2Chain);
    
    % Calculate log(p(y|theta_Bayes))
    RSS_meanPost = Run_simulator(param./sc, ...
        extra_p, truePressure, sc, corrErr);
    
    ll_meanPost = -n/2*log(sigma2)-n/2*log(2*pi) - RSS_meanPost/(2*sigma2);
    
    % Claculate ll_post = E w.r.t. post of the log(y|theta_s)
    % ll_post corresponding to all posterior samples
    
    ll_post = -n/2.*log(s2Chain)-n/2*log(2*pi) - ObjFctChain./(2.*s2Chain);
    
    % Calculate p_dic
    p_dic = 2*(ll_meanPost - mean(ll_post));
    
    % Finally, calculate DIC
    DIC_LinB_ExpoStiff_iid(j) = -2*(ll_meanPost - p_dic);
    
    
    %%%%%%%%%%
    
    load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', j))
    
    id = 10^7; hd = 2; nbio = 6; nd = nbio + hd; T = 0.11;nv = 1; ntp = 512;
    gp_ind = 5;em_ind = 0;corrErr = 1;extra_p = [id, hd, gp_ind, T, nv];
    if gp_ind ~= 5
        l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05, 0.5, 0.001];
        u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5, 1.5, 0.06];
    else
        l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05, 10^4, 1];
        u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5, 9*10^4, 500];
    end
    sc = max(abs(l),abs(u));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate WAIC
    S = 1000; % no of PDE param samples to use for WAIC
    
    parChain = p_sample(10^4+1:???,:);
    
    ObjFctChain = ObjFct_sample(10^4+1:???);
    
    M = size(parChain, 1); % no of chain iterations
    
    n = size(truePressure,1);
    
    % There is correlation in the data, so we thin the chain and take every
    % 5^th chain sample (i.e. take 1000 PDE param samples from the posterior
    % and get every individual loglik(i) for every data point i, i=1,...512)
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    % Calculate lpd
    lpd = 0;
    pd = NaN(n,S); % stores p(y_i|theta_s)
    log_pd = NaN(n,S); % stores log(p(y_i|theta_s))
    
    for s = 1:S
        param = param_mat(s,:);
    
        [ObjFct, pass, Z, C, L, pressure] = Run_simulator(param./sc, ...
            extra_p, truePressure, sc, gp_ind, corrErr);
    
        a = (L\(-Z)); % or a = L\(-res);
        MH_term = a.*a; % Mahalanobis distance
        LogDet_term = repmat(1*log(2*pi),n) + 2*log(diag(L));
        for i = 1:n
            log_pd(i,s) = -0.5*LogDet_term(i) - 0.5*MH_term(i);  %log(p(y_i|theta_s))
            pd(i,s) = exp(log_pd(i,s)); %p(y_i|theta_s);
        end
    
        % ObjFct == sum(log_pd(:,s))
    
    end
    
    for i = 1:n
        lpd = lpd + log(mean(pd(i,:))); % add log(1/S * sum p(y_i|s)) for every i
    end
    
    % Calculate p_waic
    p_waic = 0;
    for i = 1:n
        p_waic = p_waic + calc_var(log_pd(i,:), S);
    end
    
    WAIC_LinB_ExpoStiff_corrErr(j) = -2*(lpd - p_waic);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate DIC
    
    param = mean(parChain);
    
    % Calculate log(p(y|theta_Bayes))
    ll_meanPost = Run_simulator(param./sc, ...
        extra_p, truePressure, sc, corrErr);
    
    % Calculate ll_post = E w.r.t. post of the log(y|theta_s)
    % ll_post corresponding to all posterior samples
    
    ll_post = ObjFctChain;
    
    % Calculate p_dic
    p_dic = 2*(ll_meanPost - mean(ll_post));
    
    % Finally, calculate DIC
    DIC_LinB_ExpoStiff_corrErr(j) = -2*(ll_meanPost - p_dic);
    
end


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% results from 1 vessel, 3 vessels, 21 vessels on correlated synthetic data
% Linear B - Simulated data Expo stiffness and correlated errors

% 21 vessels

clear

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels')

n_burnin = 1000; nd = 8; ntp = 512;

% PARAMETER SPACE

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

nrun = 20;

agglom_ci_21v = []; parChainAgglom_21v = [];

figure(101); clf(101);

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd);
    parChain_21v{i} = parChain;
    parChainAgglom_21v = [parChainAgglom_21v; parChain];
    meanPar(i,:) = mean(parChain);
    med_par_21v(i,:) = median(parChain); % equivalent of quantile(parChain, 0.5);
    ci_par_21v{i} = quantile(parChain, [0.025 0.975]);
    
    agglom_ci_21v =  [agglom_ci_21v; ci_par_21v{i}];
    
    figure(101); hold on
    for j=1:nd
        [f, x] = ksdensity(parChain(1:end,j));
        subplot(3,3,j);plot(x,f,'LineWidth',3);hold on; %line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3)
    end
    
end

meanParBest_21v = mean(meanPar);
[meanParBest_21v;par_true] % should be similar


figure(101); hold on
for j=1:nd
    subplot(3,3,j);line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',4)
    subplot(3,3,j);line([meanParBest_21v(j) meanParBest_21v(j)],ylim, 'Color', 'red', 'LineWidth',4)
end

% OUTPUT SPACE
nrun=20;

delete(gcp('nocreate'))
parpool('local', nrun)

n_burnin = 1000; nd = 8; ntp = 512;

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd-2);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    id = 10^5;
    
    nv = 21;
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
                    
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    PressureAll_21v{i} = Pressure;
    
end

for i=1:nrun
    tmp1 = mean(PressureAll_21v{i});
    tmp2 = reshape(tmp1, ntp, nv);
    meantemp_21v(i,:) = mean(tmp2);
end

truePressureresh = reshape(truePressure, ntp, nv);
[mean(meantemp_21v) ;mean(truePressureresh)] % should be similar

% clean credible intervals on noisy data (inconsistent)
for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))

    figure(i+10000);clf(i+10000)
    
    Y = quantile(PressureAll_21v{i},[0.025 0.5 0.975],1); % for each row
    
    j=1;
    subplot(1,2,1);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    j=21;
    subplot(1,2,2);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
end

% noisy credible intervals on noisy data (consistent)

T = 0.11;
deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);
    
    param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);
    
    for s=1:S
        
        w = param_mat_noise(s,1);
        b = param_mat_noise(s,2);
        
        %         kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));
        %
        %
        %         K = NaN(ntp,ntp);
        %         for k=1:ntp
        %             for j=1:ntp
        %                 K(k,j) = kernel(t(k),t(j));
        %             end
        %         end
        %
        %         s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
        %
        %         C = K + s2*eye(ntp,ntp);
        %
        %         %The matrix is probably not symmetric due to round-off.
        %         % For example have a look at
        %         % YourMatrix - YourMatrix.' and you will likely see some non-zero values.
        %         %The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;
        %
        %         if ~issymmetric(C)
        %             C = (C+C')/2; % to fix roundoff errors
        %         end
        
        lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
        
        gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
            'weightSigma2', w, ...
            'biasSigma2_prior',prior_fixed, ...
            'weightSigma2_prior',prior_fixed);
        
        gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
        
        [~,C] = gp_trcov(gp, t);
        
        for j=1:nv
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            
%             while sum(abs(res)) > 250
%                 
%                 res = mvnrnd(zeros(ntp,1), C, 1);
%                 
%             end
            
            NoisyPressure_21v{i}(s,ntp*(j-1)+1:ntp*j) = PressureAll_21v{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
            
        end
    end
end

% now plot the noisy credible intervals for the signals
for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))

    figure(i+10000);clf(i+10000)
    
    Y = quantile(NoisyPressure_21v{i},[0.025 0.5 0.975],1); % for each row
    
    j=1;
    subplot(2,2,1);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    j=2;
    subplot(2,2,2);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    j=3;
    subplot(2,2,3);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    j=21;
    subplot(2,2,4);
    hold on
    plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
end

% now plot the credible intervals for the residuals
for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    figure(i+30000);clf(i+30000)
    
    res = NoisyPressure_21v{i}-truePressure';
    Y = quantile(res,[0.025 0.5 0.975],1); % for each row
    
    j=1;
    subplot(2,2,1)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=2;
    subplot(2,2,2)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=3;
    subplot(2,2,3)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=21;
    subplot(2,2,4)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
end

% plot the distribution which will show which data points lie outside
% the credible interval
% if 2.5th<trueP<97.5th, then 50th-97.5th<50th-trueP<50th-2.5th
for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    figure(i+20000);clf(i+20000)
    
    Y = quantile(NoisyPressure_21v{i},[0.025 0.5 0.975],1); % for each row
    
    j=1;
    subplot(2,2,1)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure(ntp*(j-1)+1:ntp*j)', '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=2;
    subplot(2,2,2)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure(ntp*(j-1)+1:ntp*j)', '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=3;
    subplot(2,2,3)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure(ntp*(j-1)+1:ntp*j)', '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
    
    j=21;
    subplot(2,2,4)
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j)-truePressure(ntp*(j-1)+1:ntp*j)', '--','Color', 'k','LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c', 'LineWidth',1)
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j) - Y(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
end

%%%%%%%%%%%%%%%%%%%%%%%%%
% 3 vessels

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels')

n_burnin = 1000; nd = 8; ntp = 512;

% PARAMETER SPACE

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

nrun = 20;

agglom_ci_3v = []; parChainAgglom_3v = [];

figure(102); clf(102);

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_3vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd);
    parChain_3v{i} = parChain;
    parChainAgglom_3v = [parChainAgglom_3v; parChain];
    meanPar(i,:) = mean(parChain);
    med_par_3v(i,:) = median(parChain); % equivalent of quantile(parChain, 0.5);
    ci_par_3v{i} = quantile(parChain, [0.025 0.975]);
    
    agglom_ci_3v =  [agglom_ci_3v; ci_par_3v{i}];
    
    figure(102); hold on
    for j=1:nd
        [f, x] = ksdensity(parChain(1:end,j));
        subplot(3,3,j);plot(x,f,'LineWidth',3);hold on; %line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3)
    end
    
end

meanParBest_3v = mean(meanPar);
[meanParBest_3v;par_true] % should be similar


figure(102); hold on
for j=1:nd
    subplot(3,3,j);line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',4)
    subplot(3,3,j);line([meanParBest_3v(j) meanParBest_3v(j)],ylim, 'Color', 'red', 'LineWidth',4)
end

% OUTPUT SPACE
nrun=20;

delete(gcp('nocreate'))
parpool('local', nrun)

n_burnin = 1000; nd = 8; ntp = 512;

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_3vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd-2);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    id = 10^5;
    
    nv = 21;
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
                    
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    PressureAll_3v{i} = Pressure;
    
end

for i=1:nrun
    tmp1 = mean(PressureAll_3v{i});
    tmp2 = reshape(tmp1, ntp, nv);
    meantemp_3v(i,:) = mean(tmp2);
end

truePressureresh = reshape(truePressure, ntp, nv);
[mean(meantemp_3v) ;mean(truePressureresh)] % should be similar

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_3vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_3vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);
    
    param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);
    
    for s=1:S
        
        w = param_mat_noise(s,1);
        b = param_mat_noise(s,2);
        
        %         kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));
        %
        %
        %         K = NaN(ntp,ntp);
        %         for k=1:ntp
        %             for j=1:ntp
        %                 K(k,j) = kernel(t(k),t(j));
        %             end
        %         end
        %
        %         s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
        %
        %         C = K + s2*eye(ntp,ntp);
        %
        %         %The matrix is probably not symmetric due to round-off.
        %         % For example have a look at
        %         % YourMatrix - YourMatrix.' and you will likely see some non-zero values.
        %         %The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;
        %
        %         if ~issymmetric(C)
        %             C = (C+C')/2; % to fix roundoff errors
        %         end
        
        lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
        
        gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
            'weightSigma2', w, ...
            'biasSigma2_prior',prior_fixed, ...
            'weightSigma2_prior',prior_fixed);
        
        gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
        
        [~,C] = gp_trcov(gp, t);
        
        for j=1:nv
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            
            while sum(abs(res)) > 250
                
                res = mvnrnd(zeros(ntp,1), C, 1);
                
            end
            
            NoisyPressure_3v{i}(s,ntp*(j-1)+1:ntp*j) = PressureAll_3v{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
            
        end
    end
end


%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%
% 1 vessel

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

n_burnin = 1000; nd = 8; ntp = 512;

% PARAMETER SPACE

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

nrun = 20;

agglom_ci_1v = [];
parChainAgglom_1v = [];

figure(103); clf(103);

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd);
    parChain_1v{i} = parChain;
    parChainAgglom_1v = [parChainAgglom_1v; parChain];
    meanPar(i,:) = mean(parChain);
    med_par_1v(i,:) = median(parChain); % equivalent of quantile(parChain, 0.5);
    ci_par_1v{i} = quantile(parChain, [0.025 0.975]);
    
    agglom_ci_1v =  [agglom_ci_1v; ci_par_1v{i}];
    
    figure(103); hold on
    for j=1:nd
        [f, x] = ksdensity(parChain(1:end,j));
        subplot(3,3,j);plot(x,f,'LineWidth',3);hold on; %line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3)
    end
    
end

meanParBest_1v = mean(meanPar);
[meanParBest_1v;par_true] % should be similar


figure(103); hold on
for j=1:nd
    subplot(3,3,j);line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',4)
    subplot(3,3,j);line([meanParBest_1v(j) meanParBest_1v(j)],ylim, 'Color', 'red', 'LineWidth',4)
end

% OUTPUT SPACE
nrun=20;

delete(gcp('nocreate'))
parpool('local', nrun)

n_burnin = 1000; nd = 8; ntp = 512;

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Get uncertainty bounds on all vessels
    
    parChain = p_sample(n_burnin+1:end, 1:nd-2);
    
    M = size(parChain, 1); % no of chain iterations
    
    S = 100; % no of MCMC samples to use for creating the uncertainty bounds
    
    param_mat = parChain(fix(linspace(1, M, S)),:);
    
    id = 10^5;
    
    nv = 21;
    
    Pressure = NaN(S,ntp*nv);
    
    parfor s = 1:S
        
        param = param_mat(s,:);
        
        cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', param, id+s));
                    
        for j=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', j, id+s));
            [~,~,p,~,~,~] = gnuplot(pu);
            if j~=1
                pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            else
                pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
            end
        end
        
        pressure = pressure';
        
        Pressure(s,:) = pressure;
        
    end
    
    PressureAll_1v{i} = Pressure;
  
end

load('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/CleanPressures_SyntheticData_1321vessels.mat')

for i=1:nrun
    tmp1 = mean(PressureAll_1v{i});
    tmp2 = reshape(tmp1, ntp, nv);
    meantemp_3v(i,:) = mean(tmp2);
end

truePressureresh = reshape(truePressure, ntp, nv);
[mean(meantemp_1v) ;mean(truePressureresh)] % should be similar

for i=1:nrun
    
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA/AMsimulator_ExpoStiff_errorCorrel_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    parChainNoise = p_sample(n_burnin+1:end,nd-1:nd);
    
    param_mat_noise = parChainNoise(fix(linspace(1, M, S)),:);
    
    for s=1:S
        
        w = param_mat_noise(s,1);
        b = param_mat_noise(s,2);
        
        %         kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));
        %
        %
        %         K = NaN(ntp,ntp);
        %         for k=1:ntp
        %             for j=1:ntp
        %                 K(k,j) = kernel(t(k),t(j));
        %             end
        %         end
        %
        %         s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
        %
        %         C = K + s2*eye(ntp,ntp);
        %
        %         %The matrix is probably not symmetric due to round-off.
        %         % For example have a look at
        %         % YourMatrix - YourMatrix.' and you will likely see some non-zero values.
        %         %The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;
        %
        %         if ~issymmetric(C)
        %             C = (C+C')/2; % to fix roundoff errors
        %         end
        
        lik = lik_gaussian('sigma2', 2.44e-06, 'sigma2_prior', prior_fixed);
        
        gpcf = gpcf_neuralnetwork('biasSigma2', b, ...
            'weightSigma2', w, ...
            'biasSigma2_prior',prior_fixed, ...
            'weightSigma2_prior',prior_fixed);
        
        gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 1e-6);
        
        [~,C] = gp_trcov(gp, t);
        
        for j=1:nv
            
            res = mvnrnd(zeros(ntp,1), C, 1);
            
            
            while sum(abs(res)) > 250
                
                res = mvnrnd(zeros(ntp,1), C, 1);
                
            end
            
            NoisyPressure_1v{i}(s,ntp*(j-1)+1:ntp*j) = PressureAll_1v{i}(s,ntp*(j-1)+1:ntp*j) + res;
            
            
        end
    end
end


%%%% Compare 1, 3, 21 vessels

% PARAMETER SPACE

% agglomerated posterior distribution parameter space
parnames = {'f_1', 'f_2', 'f_3', 'r_1', 'r_2', 'c', 'error correl param 1', 'error correl param 2'};
figure(1000); clf(1000)
for j=1:nd-2
    [f, x] = ksdensity(parChainAgglom_1v(:,j));
    subplot(2,3,j);plot(x,f,'LineWidth',3, 'Color', [0.1 0.1 0.1]);hold on; %line([meanParBest_1v(j) meanParBest_1v(j)],ylim, 'Color', 'b', 'LineWidth',3)
    [f, x] = ksdensity(parChainAgglom_3v(:,j));
    subplot(2,3,j);plot(x,f,'LineWidth',3, 'Color', [0.5 0.5 0.5]);hold on; %line([meanParBest_3v(j) meanParBest_3v(j)],ylim, 'Color', 'r', 'LineWidth',3)
    [f, x] = ksdensity(parChainAgglom_21v(:,j));
    subplot(2,3,j);plot(x,f,'LineWidth',3, 'Color', [0.8 0.8 0.8]);hold on; %line([meanParBest_21v(j) meanParBest_21v(j)],ylim, 'Color', 'y', 'LineWidth',3) 
    axis tight; xlabel(parnames(j))
    hold on; line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3, 'LineStyle', '--')
    set(gca, 'FontSize', 15)
end
subplot(2,3,1); ylabel('pdf')
subplot(2,3,4); ylabel('pdf')
%subplot(3,3,1);title('agglomerated posterior distributions over 20 data instantiations (with rejection mechanism)')
%legend(' 1 vessel', '3 vessels', '21 vessels', 'true')
savefig('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/SyntheticData_1321Vess.fig')

% Calculate the average posterior distribution to show that the 21 vessels
% provides a narrower (higher post distr)

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

% Do it marginally per parameter first
for i=1:6
    for j=1:20
        [postDistrTrueParam_1v(i,j), xi, bw] = ksdensity(parChain_1v{j}(:,i),par_true(i));
        [postDistrTrueParam_3v(i,j), xi, bw] = ksdensity(parChain_3v{j}(:,i),par_true(i));
        [postDistrTrueParam_21v(i,j), xi, bw] = ksdensity(parChain_21v{j}(:,i),par_true(i));
    end
end
avgPostDistrTrueParam_1v = mean(postDistrTrueParam_1v,2);
medPostDistrTrueParam_1v = median(postDistrTrueParam_1v,2);
avgPostDistrTrueParam_3v= mean(postDistrTrueParam_3v,2);
medPostDistrTrueParam_3v= median(postDistrTrueParam_3v,2);
avgPostDistrTrueParam_21v= mean(postDistrTrueParam_21v,2);
medPostDistrTrueParam_21v= median(postDistrTrueParam_21v,2);

[avgPostDistrTrueParam_1v, avgPostDistrTrueParam_3v, avgPostDistrTrueParam_21v] % 1v vs 3v vs 21v
[medPostDistrTrueParam_1v, medPostDistrTrueParam_3v, medPostDistrTrueParam_21v]

l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05, 10^4, 1];
u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5, 9*10^4, 500];
sc = max(abs(l),abs(u));

% Do it in 6D
nd = 6;

for j=1:20
    parChain = parChain_1v{j}(:,1:nd)./sc(1:nd);
    n = size(parChain,1);
    variances = var(parChain);
    bandwidths = sqrt(variances) .* (4/(n*(nd+2)))^(1/(nd+4));
    
    postDistrTrueParam_1v(j) = mvksdensity(parChain,par_true(1:nd)./sc(1:nd),...
        'Bandwidth',bandwidths, 'Kernel','normal');
    
    parChain = parChain_3v{j}(:,1:nd)./sc(1:nd);
    n = size(parChain,1);
    variances = var(parChain);
    bandwidths = sqrt(variances) .* (4/(n*(nd+2)))^(1/(nd+4));
    
    postDistrTrueParam_3v(j) = mvksdensity(parChain,par_true(1:nd)./sc(1:nd),...
        'Bandwidth',bandwidths, 'Kernel','normal');
    
    parChain = parChain_21v{j}(:,1:nd)./sc(1:nd);
    n = size(parChain,1);
    variances = var(parChain);
    bandwidths = sqrt(variances) .* (4/(n*(nd+2)))^(1/(nd+4));
    
    postDistrTrueParam_21v(j) = mvksdensity(parChain,par_true(1:nd)./sc(1:nd),...
        'Bandwidth',bandwidths, 'Kernel','normal');
    
end

[median(postDistrTrueParam_1v), median(postDistrTrueParam_3v), median(postDistrTrueParam_21v)]

nv = 21;

%%% OUTPUT SPACE
for i=1:3%nrun
    % load to extract TruePressure
    load(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_21vessels/AMsimulator_ExpoStiff_errorCorrel_SimData_21vess_MimicData_DataInstantiation_correct %d.mat', i))
    
    Y_21 = quantile(NoisyPressure_21v{i},[0.025 0.5 0.975],1); % for each row
    Y_3 = quantile(NoisyPressure_3v{i},[0.025 0.5 0.975],1); % for each row
    Y_1 = quantile(NoisyPressure_1v{i},[0.025 0.5 0.975],1); % for each row
    
    for j=1:nv
        figure(j); clf(j);
        hold on
        plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
        plot(linspace(0,0.11,512), Y_21(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
        plot(linspace(0,0.11,512), Y_21(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        plot(linspace(0,0.11,512), Y_21(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        
        if j~=1
            set(gca, 'XTickLabel', '', 'YTickLabel', '')
        end
        
        axis tight; grid on
        ylim([min(min(Y_1-0.1)) max(max(Y_1+0.1)) ])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/1321Vessels/OutputSpace/CI_21vess_vessel %d_dataSet %d.fig', j, i))
    end
    
    
    for j=1:nv
        figure(j); clf(j);
        hold on
        plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
        plot(linspace(0,0.11,512), Y_3(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
        plot(linspace(0,0.11,512), Y_3(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        plot(linspace(0,0.11,512), Y_3(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        
        if j~=1
            set(gca, 'XTickLabel', '', 'YTickLabel', '')
        end
        
        axis tight; grid on
        ylim([min(min(Y_1-0.1)) max(max(Y_1+0.1)) ])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/1321Vessels/OutputSpace/CI_3vess_vessel %d_dataSet %d.fig', j, i))
    end
    
    
    for j=1:nv
        figure(j); clf(j);
        hold on
        plot(linspace(0,0.11,512), truePressure(ntp*(j-1)+1:ntp*j), '-','Color', 'k','LineWidth',1)
        plot(linspace(0,0.11,512), Y_1(2,ntp*(j-1)+1:ntp*j), '--','Color', [1 0.5 0], 'LineWidth',1)
        plot(linspace(0,0.11,512), Y_1(1,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        plot(linspace(0,0.11,512), Y_1(3,ntp*(j-1)+1:ntp*j), '-','Color', 'c','LineWidth',1)
        
        if j~=1
            set(gca, 'XTickLabel', '', 'YTickLabel', '')
        end
        
        axis tight; grid on
        ylim([min(min(Y_1-0.1)) max(max(Y_1+0.1)) ])
        set(gca, 'FontSize',20)
        
        savefig(sprintf('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_21vessels_LinearB/plotsMette/SyntheticData/1321Vessels/OutputSpace/CI_1vess_vessel %d_dataSet %d.fig', j, i))
    end
end
