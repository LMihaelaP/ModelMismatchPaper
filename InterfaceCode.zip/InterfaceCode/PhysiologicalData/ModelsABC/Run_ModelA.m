% GPMCMC with iid errors and one stiffness parameter for the linear
% wall maths model

% Construct an emulator for the log likelihood
clear; close all;

% Add necessary paths ...

%% Load the real data
trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');

trueState = [trueFlow; truePressure];

%% Set necessary parameters
nd = 4; % no of parameters
HB = 12; % no of heartbeats
cycles = 1; % no of cardiac cycles
ntp = size(truePressure,1); % no of time points
% Type of covariance function used for error correlation
% 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
% 4 - periodic; 5 - neural network
gp_ind = NaN;

id = 50000; % id for data files
extra_p = [id, nd, HB, cycles];

GP_hyperHyper = NaN(6, 1);

l = [2e04, 0.05, 0.05, 0.05];
u = [1e05, 2.5,  2.5,  2.5];
% Parameter scaling for emulation
sc = [10^5, 10, 10, 10];

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded biological parameters theta
% Be(1,1) = Uniform
alp = [1,1,1,1];
bet = [1,1,1,1];

if 1
    %% Initial phase: Construct GP model in initial phase
    X = sobolset(nd, 'Skip',1.4e4,'Leap',0.15e14);
    
    f3_vec = l(1) + (u(1)-l(1)) * X(:,1);
    rr1_vec = l(2) + (u(2)-l(2)) * X(:,2);
    rr2_vec = l(3) + (u(3)-l(3)) * X(:,3);
    cc1_vec = l(4) + (u(4)-l(4)) * X(:,4);
    
    par = [f3_vec, rr1_vec, rr2_vec, cc1_vec]./sc;
    
    corrErr = 0; % iid errors
    
    % Run simulator to obtain log lik for training points
    [rss, pass] = Run_simulator(par, extra_p, truePressure, sc, ...
        gp_ind, corrErr);
    
    pass = logical(pass);
    
    save('GPMCMC_initial_RealData_iid.mat')
    
    k = 500; % no of points we want to keep to fit the initial GP regression model
    temp = sort(rss, 'ascend');
    T_ss = temp(k); % the threshold is the lowest loglik value out of the k values we keep to fit the GP regression
    
    I_ss = rss<T_ss;
    
    % Construct classifier
    x_class = par(I_ss,:); y_class = 2.*pass(I_ss)-1;
    % For GP regr only look successful simulations from simulator
    x_regr = par(pass&I_ss,:); y_regr = rss(pass&I_ss);
    
    %%%
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP model (loglik emulator and classifier)
    X_r = sobolset(6, 'Skip',2e12,'Leap',0.9e15); % 9 draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.1  0.1  0.1  0.1  0.1  0.1 0.1 0.000000001];
    u_r = [1 1 1 1 1 1 1 1];
    
    % H_r matrix with magnsigma2, every lengthscale and sigma2 on separate rows
    H_r = [l_r(1) + (u_r(1)-l_r(1)) * X_r(:,1), ...
        l_r(2) + (u_r(2)-l_r(2)) * X_r(:,2), ...
        l_r(3) + (u_r(3)-l_r(3)) * X_r(:,3), ...
        l_r(4) + (u_r(4)-l_r(4)) * X_r(:,4), ...
        l_r(5) + (u_r(5)-l_r(5)) * X_r(:,5), ...
        l_r(6) + (u_r(6)-l_r(6)) * X_r(:,6)];
    
    X_c = sobolset(5, 'Skip',4e8,'Leap',0.9e15); % 8 draw 10 values
    n_c = size(X_c, 1);
    
    l_c = [1 1   0.1 0.5  0.5 0.5 0.5];
    u_c = [10 20   5   5  5 5 5];
    % H_c matrix with magnsigma2, every lengthscale and sigma2 on separate rows
    H_c = [l_c(1) + (u_c(1)-l_c(1)) * X_c(:,1), ...
        l_c(2) + (u_c(2)-l_c(2)) * X_c(:,2), ...
        l_c(3) + (u_c(3)-l_c(3)) * X_c(:,3), ...
        l_c(4) + (u_c(4)-l_c(4)) * X_c(:,4), ...
        l_c(5) + (u_c(5)-l_c(5)) * X_c(:,5)];
		
    %H(1)=1;H(end+1:end+4)=0.01*ones(nd,1);H(end+1)=exp(-9.950929526405522);
    [gp_regr, nlml_regr, gp_class, nlml_class] = ...
        GPmodel(x_regr, y_regr, x_class, y_class, H,...
        H_c(2,:), 2, corrErr);
    
    [w,s] = gp_pak(gp_regr);
    disp(exp(w))
    
    [w,s] = gp_pak(gp_class);
    disp(exp(w))
    
    %Make predictions using gp_regr
    [E, Var] = gp_pred(gp_regr, x_regr, y_regr, x_regr);
    figure(1); clf(1); plot(y_regr, E, '.');
    hold on; plot(y_regr,y_regr,'-r')
    xlabel('Train data'); ylabel('Predictions')
    
    % Make predictions using gp_class
    [Eft_la, Varft_la, lpyt_la, Eyt_la, Varyt_la] = ...
        gp_pred(gp_class, x_class, y_class, x_class, ...
        'yt', ones(size(x_class,1),1) );
    figure(2); clf(2)
    % if good classifier, 2 dots on the plot: one at (0,-1) & another at (1,1)
    plot(exp(lpyt_la), y_class, '.', 'markersize', 20)
    xlabel('Predictions'); ylabel('Train labels')
    
    save('GPMCMC_initial_RealData_iid.mat')
    
    %% Exploratory phase
    
    phase_ind = 1; % phase index 1 (exploratory) in Rasmussen's algorithm
    
    do_DA = 1; % couple algorithm with delayed acceptance
    
    do_nuts = 0; % we run HMC, not NUTS, in exploratory phase
    
    extraPar_gp = [mean_y, std_y];
    x_regr_refitted = x_regr;
    y_regr_refitted = y_regr;
    gp_regr_refitted = gp_regr;
    
    sigma2 = 1.1; % fixed noise variance
    nSamples = 1000; % no of HMC samples
    L = 50; % no of steps in the leapfrog scheme
    epsilon = 0.0003; % step size
    M = eye(nd); % mass matrix for momentum (identity matrix)
    
    p = NaN(nSamples, nd); % parameter samples from the exploratory phase
    ss = NaN(nSamples, 1); % sum-of-square samples from the exploratory phase
    
    T_ss = quantile(y_regr_refitted.*std_y+mean_y, 0.0001); % threshold for RSS (delete points above this threshold)
    
    j = find(y_regr_refitted.*std_y+mean_y==min(y_regr_refitted.*std_y+mean_y));
    p(1,:) = x_regr_refitted(j,:) .* sc; % original scale
    
    NLL = Run_simulator(p(1,:)./sc, extra_p, truePressure, sc, gp_ind, corrErr);
    
    if NLL ~=10^10
        ss(1) = NLL;
    else
        disp('Choose different starting values for the parameters')
    end
    
    p(1,:) = log((p(1,:)-l)./(u-p(1,:))); % unbounded
    
    em_ind = 0; % use simulator for beginning of trajectory
    grad1_SimInd = 0; grad23_EmInd = [NaN, NaN];
    LogPosterior_sim = HMCDerivPosterior_all_MoreEfficient_Generic(p(1,:), sigma2, ...
        truePressure, alp, bet, ...
        GP_hyperHyper,extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind);
    
    em_ind = 1;
    grad1_SimInd = NaN; grad23_EmInd = [0 0];
    [LogPosterior_em, GradLogPost_em] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic(p(1,:), sigma2, ...
        truePressure, alp, bet, ...
        GP_hyperHyper,extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind);
    
    acc = 0; % number of accepted MCMC samples
    
    j = 1; % delete j^th training point in the GP model
    
	% main loop for emulation HMC
    for k = 2:nSamples
        % for every i^th sample, run the trajectory
        [p(k,:), LogPosterior_sim, LogPosterior_em, GradLogPost_em, ss(k), ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, mean_y, std_y] = ...
            HMC_pulm_MoreEfficient(p(k-1,:), sigma2, epsilon, L, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, phase_ind, truePressure, alp, bet, ...
            GP_hyperHyper, extra_p, l, u, sc, LogPosterior_sim, LogPosterior_em, ...
            GradLogPost_em, ss(k-1), mean_y, std_y, ...
            do_nuts, corrErr, gp_ind, M, do_DA);

        % if new point accepted, at the end of every trajectory,
        % remove the j^th point and add the newly accepted point as a training
        % point in the GP, and re-fit the GP
        if all(p(k,:) ~= p(k-1,:)) % i.e. we've just accepted the new point
            acc = acc + 1;
            
            % starting from beginning, gradually remove the old [size(y_regr,1)] training
            % points whose rss > T_ss, as we accept new train points & refit GP
            if acc <= size(y_regr,1) % delete or skip when we've accepted
                if (y_regr_refitted(j) * std_y + mean_y) > T_ss
                    x_regr_refitted(j,:) = []; y_regr_refitted(j) = [];
                else
                    j = j + 1; % skip deleting
                end
            end
            
            param = (u.*exp(p(k,:))+l)./(1+exp(p(k,:))); % parameters on original scale
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point (in HMC_pulm_MoreEfficient) as a consequence of sqrt(Var)>=3,
                % add it as a training point
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1) = ss(k); % because rss is on original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted); % re-optimise GP
                
                %[E, ~] = gp_pred(gp_regr_refitted, x_regr_refitted, y_regr_refitted, x_regr_refitted);
                %[y_regr_refitted(1:10),E(1:10)]
                
            end
        end
    end
    
    save('GPMCMC_exploratory_RealData_iid.mat')
    
    % Now discard some of the samples - burnin phase
    % (training points for the GP) for which sum-of-squares, ss
    % are above some threshold T_ss
    % this is to keep training points from high posterior probability regions
    
    y_regr_refitted = y_regr_refitted * std_y + mean_y;
    I_ss = find(y_regr_refitted < T_ss);
    y_regr_refitted = y_regr_refitted(I_ss);
    mean_y = mean(y_regr_refitted);
    std_y = std(y_regr_refitted);
    
    y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
    x_regr_refitted = x_regr_refitted(I_ss,:);
    
    % Refit GP with burnin phase removed
    % Use this GP in the sampling phase
    gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
    
    save('GPMCMC_exploratory_RealData_iid.mat')
    
end % 1

%% Sampling phase with AM

load('GPMCMC_exploratory_RealData_iid.mat')

nrun = 10; % run 10 chains in parallel
nSamples = 5000; % no of sampling phase samples
nburnin = 100; % no of burnin phase samples
em_int = 50; % emulation interval (call PDEs every 50 emulation steps)
phase_ind = 2; % sampling phase
adapt_int = 10; % adaptation interval (in AM)
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-8),nd,1));
extraPar_gp = [mean_y, std_y];

delete(gcp('nocreate'))
parpool('local', nrun)

par_sim = cell(nrun,1); % parameter samples from the sampling phase
ObjFct_sim = cell(nrun,1); % sum-of-square samples from the sampling phase
s2_sim = cell(nrun,1); % noise variance sigma2 samples from the sampling phase

% Initialise parameter chain
for j = 1:nrun
    par_sim{j}(1,:) = x_regr_refitted(end-50*j,:) .* sc;
end


a = 0.001; b = 0.001; % Inv-Gamma(a,b) prior for the noise variance

parfor j = 1:nrun
    extra_p = [1000+j, nd, HB, cycles];
    em_ind = 0; % use simulator for beginning of trajectory
    ObjFct = mice_pulm_ss(par_sim{j}(1,:),truePressure,...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, ...
        extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);
    
    if ObjFct ~= 1
        ObjFct_sim{j}(1) = ObjFct; s2_sim{j}(1) = ObjFct_sim{j}(1)/(ntp-nd);
    else
        disp('Choose different starting values for the parameters')
    end
end

gp_regr_refitted = ReFitGP(x_regr_refitted, y_regr_refitted); % re-train the GP

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
acc = zeros(nrun,1); % no of accepted samples for every chain

% Store cpu times for every run
initime = NaN(nrun,1);
fintime = NaN(nrun,1);

% Run 10 chains in parallel from different initialisations and different
% random seed generators
parfor j = 1:nrun %parfor
    
    initime(j) = cputime;
    
    extra_p = [1000+j, nd, HB, cycles];
    % covariance update uses these to store previous values
    covchain = []; meanchain = []; wsum = []; lasti = 0;
    R = chol(cov_MH);
    for i=2:nSamples+nburnin
        % for every i^th sample, run the trajectory
        [par_sim{j}(i,:), ObjFct_sim{j}(i)] = ...
            AMtrj_informative(par_sim{j}(i-1,:), s2_sim{j}(i-1), R, em_int, extra_p, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, truePressure, l, u, sc, phase_ind, ...
            ObjFct_sim{j}(i-1), extraPar_gp, gp_ind, corrErr, alp, bet, GP_hyperHyper);
        if all(par_sim{j}(i,:) ~= par_sim{j}(i-1,:)) % just accepted the new point
            acc(j) = acc(j) + 1;
            %disp(sprintf('accept for run %d', j))
            %par_sim{j}(i,:);
        end
        
        if i<nburnin % sample sigma2 in sampling phase
            %disp('burnin phase')
            s2_sim{j}(i) = s2_sim{j}(i-1);
        else
            s2_sim{j}(i) = 1/gamrnd(a+0.5*ntp, 1/(b+0.5*ObjFct_sim{j}(i)));
        end
        
        
        if mod(i, adapt_int) == 0 % we adapt
            %disp('we adapt')
            if scale == 1 % calculate the chain covariance for the transformed parameters
                [covchain,meanchain,wsum] = covupd(par_sim{j}((lasti+1):i,1:nd)./sc,1, ...
                    covchain,meanchain,wsum);
            else
                [covchain,meanchain,wsum] = covupd(par_sim{j}((lasti+1):i,1:nd),1, ...
                    covchain,meanchain,wsum);
            end
            
            upcov = covchain; % update covariance based on past samples
            
            [Ra,p] = chol(upcov);
            if p % singular
                % try to blow it
                [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
                if p == 0 % choleski decomposition worked
                    % scale R
                    R = Ra * qcov_scale;
                end
            else
                R = Ra * qcov_scale;
            end
            
            lasti = i;
            
        end
        
    end
    
    fintime(j) = cputime;
    
end%parfor

time_HMC_AM=mean(fintime-initime);

save('GPMCMC_sampling_RealData_iid.mat')

exit;