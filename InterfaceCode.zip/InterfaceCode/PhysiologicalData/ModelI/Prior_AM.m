function prior = Prior_AM(par, l, u, sc, extra_p, gp_ind,  ...
    alp, bet, GP_hyperHyper, corrErr)

hd = extra_p(2); % no of GP cov fct parameters

if corrErr == 1
    
    priorBio = sum( (alp-1) .* log(par(1:end-hd).*sc(1:end-hd)-l(1:end-hd)) + ...
        (bet-1) .* log(u(1:end-hd) - par(1:end-hd).*sc(1:end-hd)) );

    if gp_ind ~= 5
        priorCov = -log(par(end-1)*sc(end-1)) - log(sqrt(GP_hyperHyper(2)*2*pi)) - ...
            (log(par(end-1)*sc(end-1)) - GP_hyperHyper(1))^2/(2*GP_hyperHyper(2)) + ...
            -log(par(end)*sc(end)) - log(sqrt(GP_hyperHyper(4)*2*pi)) - ...
            (log(par(end)*sc(end)) - GP_hyperHyper(3))^2/(2*GP_hyperHyper(4));
    else
        priorCov = -log(par(end-1)*sc(end-1)) - log(GP_hyperHyper(2)-GP_hyperHyper(1)) + ...
            -log(par(end)*sc(end)) - log(GP_hyperHyper(4)-GP_hyperHyper(3));
        
    end
    
    prior = sum(log(sc)) + priorBio + priorCov;
    
else %corrErr=0
    
    priorBio = sum( (alp-1) .* log(par.*sc-l) + (bet-1) .* log(u-par.*sc) );
    
    prior = sum(log(sc)) + priorBio;
    
end

