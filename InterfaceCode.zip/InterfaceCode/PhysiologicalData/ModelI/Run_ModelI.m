
clear; close all;

% Add path to GPstuff toolbox
GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('MCMC_run')

!make clean
!make

if 1
    
%% Load the real data
hypo = 0; % indicator if hypoxic mouse (1) or control mouse (0) is used

if hypo
   trueFlow = importdata('qH1_512.dat');
   truePressure = importdata('pH1_512.dat');
else
   trueFlow = importdata('qC6_512.dat');
   truePressure = importdata('pC6_512.dat');
end

%% Set some parameters
id = 10; % id for data files
hd = 2; % no of GP hyperparameters
nbio = 7;
nd = nbio + hd; % total no of parameters
T = 0.11; % cycle length (s)
% Type of covariance function used for the residuals
% 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
% 4 - periodic; 5 - neural network
gp_ind = 5;

em_ind = 0;

corrErr = 1;
extra_p = [id, hd, gp_ind, T];

% Bounds for original parameters
if gp_ind ~= 5
    l = [5*10^3, -200,   10^4,   1,   0.05,  0.05,  0.05,  0.5, 0.001];
    u = [10^5,      0, 5*10^5, 2*pi,   2.5,   2.5,   2.5,  1.5,  0.06];
else
    l = [5*10^3, -200,   10^4,   1,   0.05,  0.05,  0.05,    10^4,     1];
    u = [10^5,      0, 5*10^5, 2*pi,   2.5,   2.5,   2.5,  9*10^4,   500];
end

% Parameter scaling
sc = max(abs(l),abs(u));


%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded Windkessel parameters
% Be(1,1) = Uniform

alp = [1,1,1,1,1,1,1];
bet = [1,1,1,1,1,1,1];

% For GP hyperparameters
% for sq exp, matern 3/2, 5/2, periodic:
% amplitude ~ LogGauss(GPhyperHyper(1), GPhyperHyper(2)),LogGauss(mua,sigmaa^2)
% lengthscale ~ LogGauss(GPhyperHyper(3), GPhyperHyper(4)),LogGauss(mul,sigmal^2)
% cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
% for neural network:
% bias sigma2 ~ Logunif(GPhyperHyper(1), GPhyperHyper(2)),Logunif(loglb, logub)
% weight sigma2 ~ Logunif(GPhyperHyper(3), GPhyperHyper(4)),Logunif(loglw, loguw)
% cov noise ~ InvGamma(GPhyperHyper(5), GPhyperHyper(6)),InvGamma(alpha, beta)
if gp_ind ~= 5
    GP_hyperHyper = [log(0.1), 0.095, log(0.0275), 0.1]; % amplitude: log(var(res))
else
    GP_hyperHyper = [l(end-1), u(end-1), l(end), u(end)];
end

%% Run AM sampling
% Take estimates for NN GP kernel param from 1 stiffness with error correlation results
% and set that as initial value for parameters in simulator AM algorithm
par_start =  [10^4, -100, 9.2*10^4, 5, 0.4, 0.9, 1.6, 5*10^4, 190];

end

nSamples = 150000;
n_burnin = 1000;

adapt_int = 100; % adaptation interval
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-6),nd,1));
R = chol(cov_MH);

gp_regr_refitted = NaN; x_regr_refitted= NaN; y_regr_refitted = NaN;
gp_class = NaN; x_class = NaN; y_class = NaN; extraPar_gp = NaN; phase_ind = NaN;

p_sample = NaN(nSamples+n_burnin, nd); % unbounded HMC samples
ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples

p_sample(1,:) = par_start;

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
sample_sigma = NaN; % sample sigma2 only for uncorrelated errors
acc = 0; % acceptance rate of the algorithm
rejout = 0; % rejection rate for being outside the range

ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),truePressure,...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, ...
    extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);

sigma2 = NaN; % observation noise variance

oldObjFct = ObjFct_sample(1);
oldpar = p_sample(1,:)./sc;
oldprior = Prior_AM(oldpar,l,u,sc,extra_p,gp_ind,alp,bet,GP_hyperHyper,corrErr);

covchain = []; meanchain = []; wsum = []; lasti = 0;

initime = cputime();

% for i=2:nSamples+n_burnin
for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar.*sc<l) || any(newpar.*sc>u)
        % original points outside boundaries - amplitude and lengthscale not within hard bounds
        
        %disp('proposal outside boundaries')
        %newObjFct = 10^10; % ss
        newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, truePressure, sc, ...
            gp_ind, corrErr);
        
        newprior = Prior_AM(newpar,l,u,sc,extra_p,gp_ind,...
            alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    if newObjFct == -10^10 % outside boundaries
        tst = 0;
    else
        %tst = exp(-0.5/sigma2*(newObjFct - oldObjFct) + newprior-oldprior); % for ss
        tst = exp(newObjFct - oldObjFct + newprior-oldprior); % for loglik
    end
    
    %[newObjFct, oldObjFct]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        
        p_sample(i,:) = newpar.*sc;
                
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
        
    if mod(i,100) == 0
        %sprintf('acc rate is %d', acc/i)
        save('AMsimulator_Sampling_ExpoStiffNonlinear_errorCorrel_contd.mat')
    end
    
end

CPUtime = initime - cputime();

exit;