function state = CreateData_Optim(id)

pu1 = load(sprintf('pu1_%d.2d', id)); % id is for every run in parallel  

[~,~,p,q,~,~] = gnuplot(pu1);
pressure1 = p(:,floor(end/2)); flow1 = q(:,floor(end/2));

pu2 = load(sprintf('pu2_%d.2d', id)); % id is for every run in parallel  

[~,~,p,q,~,~] = gnuplot(pu2);
pressure2 = p(:,floor(end/2)); flow2 = q(:,floor(end/2));

pu3 = load(sprintf('pu3_%d.2d', id)); % id is for every run in parallel  

[~,~,p,q,~,~] = gnuplot(pu3);
pressure3 = p(:,floor(end/2)); flow3 = q(:,floor(end/2));

state = [flow1; flow2; flow3; pressure1; pressure2; pressure3];

end