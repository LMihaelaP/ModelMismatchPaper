% MAKE THE WRONG IID ASSUMPTION TO CHECK IF PDE PARAMETERS ARE WORSE
% LEARNT THAN WHEN CORREL ASSUMPTION MADE FOR SYNTHETIC CORRELATED DATA, 
% ALSO RUN WAIC FOR MODEL SELECTION (IID VS CORREL ON WHAT IS CLEARLY CORELATED DATA)

clear; close all;

% Add necessary paths ...

nrun=20;

delete(gcp('nocreate'))
parpool('local', nrun)

parfor nins=1:nrun
    
%% Set some parameters
id = 200+nins; % id for data files
nv = 1; % no of vessels
hd = 0; % no of GP hyperparameters
nbio = 6; % no of biophysical parameters
nd = nbio + hd; % total no of parameters
T = 0.11; % cycle length (s)
ntp = 512; % no of time points per pressure from every vessel
% Type of covariance function used for the residuals
% 1 - squared exponential; 2 - matern 3/2; 3 - matern 5/2;
% 4 - periodic; 5 - neural network
gp_ind = NaN;

em_ind = 0; % no emulation

corrErr = 0; % iid errors assumed

loc = 2; % take pressure from mid location of the MPA

extra_p = [id, hd, gp_ind, T, loc];

% Bounds for original parameters

% Bounds for original parameters
l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
u = [10^7, -50, 6*10^4, 2.5,  2.5,  2.5];
% Parameter scaling
sc = max(abs(l),abs(u));

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded Windkessel parameters
% Be(1,1) = Uniform

alp = [1,1,1,1,1,1];
bet = [1,1,1,1,1,1];

a_noisevar = 0.001; b_noisevar = 0.001; % uninformative IG prior for the observation noise variance

GP_hyperHyper = NaN(6,1);

%% Simulate the noisy data

% Set the true parameters for the simulated data
par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
    0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];

% Calling PDEs Solver (C++)
cx = unix(sprintf('./sor06 %f %f %f %f %f %f %d', ...
    par_true(1), par_true(2), par_true(3), par_true(4), par_true(5), par_true(6), id));

cleanPressure = NaN(nv*ntp,1);

if cx == 0
    for i=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', i, id));
        [~,~,p,~,~,~] = gnuplot(pu);
        cleanPressure(ntp*(i-1)+1:ntp*i) = p(:,floor(end/2)); % clean, noiseless data
    end
    
else
    disp('..... Choose different parameter values .....')
end

deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

if gp_ind == 2 % matern 3/2
    
    magnS2 = par_true(nbio+1);
    lgtScale = par_true(nbio+2);
    Lambda = diag(1./(lgtScale.^2));
    
    kernel = @(x,y) magnS2 * (1 + sqrt(3 * ((x-y)*Lambda*(x-y)'))) * ...
        exp(-sqrt(3 * ((x-y)*Lambda*(x-y)')));
        
elseif gp_ind == 3 % matern 5/2
    
    magnS2 = par_true(nbio+1);
    lgtScale = par_true(nbio+2);
    Lambda = diag(1./(lgtScale.^2));
    
    kernel = @(x,y) magnS2 * (1 + sqrt(5 * ((x-y)*Lambda*(x-y)')) + ...
        (5/3)*(x-y)*Lambda*(x-y)') * exp(-sqrt(5 * ((x-y)*Lambda*(x-y)')));
    
else % gp_ind == 5 neural network
    
    w = par_true(nbio+1);
    b = par_true(nbio+2);
    
     kernel = @(x,y) (2/pi) * asin((2*(b+w*x*y))/((sqrt((1+2*b+2*w*(x^2))*(1+2*b+2*w*(y^2))))));

end

if gp_ind == 2 || gp_ind == 3 % Matern 3/2 or Matern 5/2
    
    cov_vec = NaN(1,ntp);
    for i = 1:ntp
        cov_vec(1,i) =  kernel(t(1,:), t(i,:));
    end
    K = NaN(ntp,ntp);
    for i=1:ntp
        for j=1:ntp
            K(i,j) = cov_vec(abs(i-j)+1);
        end
    end
    
else % Neural network
    K = NaN(ntp,ntp);
    for i=1:ntp
        for j=1:ntp
            K(i,j) = kernel(t(i),t(j));
        end
    end
    
end

if gp_ind == 2 || gp_ind == 3 % Matern 3/2 or Matern 5/2
    s2 = 2.82e-06; 
else % Neural Network
    s2 = 2.44e-06; % does not lead to nonsymmetric covariance matrix
end

C = K + s2*eye(ntp,ntp);

%The matrix is probably not symmetric due to round-off. 
% For example have a look at
% YourMatrix - YourMatrix.' and you will likely see some non-zero values.
%The usual trick is to use: YourMatrix = (YourMatrix + YourMatrix.') / 2;

if ~issymmetric(C)
    C = (C+C')/2; % to fix roundoff errors
end

SNR = NaN(nv,1);

% To get the same data used for the 1, 3, 21 vessels analysis
rng(4+nins,'v5uniform')

for j=1:nv
    
    res = mvnrnd(zeros(ntp,1), C, 1); res=res';
    
    % if monotonicity constraint violated, re-draw residuals
    while sum(abs(res)) > 250
        
        res = mvnrnd(zeros(ntp,1), C, 1); res=res';
        
    end
    
    noisyPressure(ntp*(j-1)+1:ntp*j) =  cleanPressure(ntp*(j-1)+1:ntp*j) + res;
    
    %end
    
    SNR(j) = var(cleanPressure(ntp*(j-1)+1:ntp*j))/var(res);
    
end

noisyPressure = noisyPressure';

truePressure = noisyPressure;

figure(1); clf(1);
for j=1:nv
    subplot(5,5,j)
    plot(1:ntp, cleanPressure(ntp*(j-1)+1:ntp*j), '-k', 1:ntp, truePressure(ntp*(j-1)+1:ntp*j), '-r')
    set(gca, 'ylim', [0 25])   
end
legend('clean pressure', 'noisy pressure')
xlabel('time'); ylabel('pressure')

%% Run AM sampling

par_start =  par_true(1:end-2);

nSamples = 150000;
n_burnin = 1000;

adapt_int = 100; % adaptation interval
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-6),nd,1));
R = chol(cov_MH);

gp_regr_refitted = NaN; x_regr_refitted= NaN; y_regr_refitted = NaN;
gp_class = NaN; x_class = NaN; y_class = NaN; extraPar_gp = NaN; phase_ind = NaN;

p_sample = NaN(nSamples+n_burnin, nd); % unbounded HMC samples
ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
s2_sample = NaN(nSamples+n_burnin,1); % noise variance samples
p_sample(1,:) = par_start;

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
acc = 0; % acceptance rate of the algorithm
rejout = 0; % rejection rate for being outside the range

ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),truePressure,...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, extraPar_gp, em_ind, phase_ind, extra_p, ...
    sc, corrErr);

s2_sample(1) = ObjFct_sample(1)/(ntp-nd); % observation noise variance

oldObjFct = ObjFct_sample(1);

oldpar = p_sample(1,:)./sc;

oldprior = Prior_AM(oldpar,l,u,sc,extra_p,alp,bet,GP_hyperHyper,corrErr);

covchain = []; meanchain = []; wsum = []; lasti = 0;

initime = cputime();

% Main loop
for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar.*sc<l) || any(newpar.*sc>u)        
        %disp('proposal outside boundaries')
        newObjFct = 10^10; % ss
        %newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, truePressure, sc, ...
            corrErr);
        
        newprior = Prior_AM(newpar,l,u,sc,extra_p,alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    if newObjFct == 10^10 % outside boundaries
        tst = 0;
    else
        tst = exp(-0.5/s2_sample(i-1)*(newObjFct - oldObjFct) + newprior-oldprior); % for ss
        %tst = exp(newObjFct - oldObjFct + newprior-oldprior); % for loglik
    end
    
    %[newObjFct, oldObjFct]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        
        p_sample(i,:) = newpar.*sc;
                
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
    
    s2_sample(i) = 1/gamrnd(a_noisevar+0.5*ntp, 1/(b_noisevar+0.5*ObjFct_sample(i)));

    if mod(i,100) == 0
        parsave2(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', nins), ...
            cleanPressure, truePressure, p_sample, ObjFct_sample, s2_sample, acc);
    end
    
end

CPUtime = initime - cputime()

end

exit;