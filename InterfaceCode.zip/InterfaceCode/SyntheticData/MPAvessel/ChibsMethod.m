clear

addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/MCMC_run');
GPpath = genpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/MCMC_run')

% Linear B - Simulated data (1 vessel: MPA) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

corrErr = 1;

% if corrErr == 1
%     hd = 2;
% else
    hd = 0;
% end

id = 1; nbio = 6; nd = nbio + hd; T = 0.11; nv = 1; ntp = 512;
gp_ind = 5; em_ind = 0; extra_p = [id, hd, gp_ind, T, nv];
% if corrErr == 1
%     l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05, 10^4, 1];
%     u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5, 9*10^4, 500];
% else
    l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
    u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5];
% end

sc = max(abs(l),abs(u));
alp = [1,1,1,1,1,1];
bet = [1,1,1,1,1,1];
if gp_ind ~= 5
    GP_hyperHyper = [log(0.1), 0.095, log(0.0275), 0.1]; % amplitude: log(var(res))
else
    GP_hyperHyper = [l(end-1), u(end-1), l(end), u(end)];
end

% if corrErr == 1
%     par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
%         0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];
% else
    par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
        0.000000288893362, 0.000000873476079, 0.000001368980536];
    
    par_true = par_true./sc;
    
% end

errPar = 10^6 * [0.054676266677259, 0.000141486099902]./[9*10^4 500];

% delete(gcp('nocreate'))
% parpool('local', 20)

K = 100;

% prior = @(par) sum( (alp-1) .* log(par(1:end-hd)-l(1:end-hd)) + ...
%     (bet-1) .* log(u(1:end-hd) - par(1:end-hd)) - ...
%     (alp+bet-1) .* log(u(1:end-hd)-l(1:end-hd)) - log(beta(alp,bet)) );% + ...
%-log(par(end-1)) - log(GP_hyperHyper(2)-GP_hyperHyper(1)) + ...
%-log(par(end)) - log(GP_hyperHyper(4)-GP_hyperHyper(3));

prior = @(par) sum(log(sc)) + sum( (alp-1) .* log(par(1:end-hd).*sc(1:end-hd)-l(1:end-hd)) + ...
    (bet-1) .* log(u(1:end-hd) - par(1:end-hd).*sc(1:end-hd)) )- ...
    sum((alp+bet-1) .* log(u(1:end-hd)-l(1:end-hd)) - log(beta(alp,bet)));

nd = 6;

for i=1:20
    
    if corrErr == 1
        load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))
    else
        load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    end
        
    parChain = p_sample(10^4+1:10^3:120000, 1:nd)./sc;
    if corrErr==0
        ObjFctChain = ObjFct_sample(10^4+1:10^3:120000, 1);
    end
    
    if corrErr == 1
        LL_true = Run_simulator([par_true errPar], extra_p, truePressure, [sc 9*10^4 500], corrErr); % log likelihood
    else
        s2 = mean(s2_sample((10^4+1:120000)));
        
        RSS_true = Run_simulator(par_true, extra_p, truePressure, sc, corrErr); % rss
        LL_true = -ntp/2 * log(2*pi*s2) - 0.5*RSS_true/s2;
    end
    
    Lp_true = prior(par_true); % log prior
    LP_true = LL_true + Lp_true;
    
    
    covchain = []; meanchain = []; wsum = [];
    covchain = covupd(parChain,1, covchain,meanchain,wsum);
    [R,p] = chol(covchain);
    if p % singular
        [R,p] = chol(covchain + eye(nd)*1e-8);
    end
    
    propDens = @(par1,par2) mvnpdf(par1, par2, covchain); % calculates q(par1|par2, covchain) = N(par2, covchain) evaluated at par1
    accProb = @(par1, par2, LP1, LP2) min(1, (LP1*propDens(par2,par1))/(LP2*propDens(par1,par2)));% calculates alpha(par1|par2, covchain)
    
    parfor j=1:size(parChain,1)
        LPri = prior(parChain(j,:)); % log prior
        if corrErr == 1
            LL = Run_simulator([parChain(j,:) errPar], [j,extra_p(2:end)], truePressure, [sc 9*10^4 500], corrErr); % log likelihood
            LP = LL + LPri;
        else
            LP = -ntp/2 * log(2*pi*s2) - 0.5*ObjFctChain(j)/s2 + LPri;
        end
        
        nom(i,j) = propDens(par_true,parChain(j,:)) * accProb(par_true,parChain(j,:), exp(LP_true), exp(LP));
    end
    
    parfor k=1:K
        q = randn(1,nd);
        
        newProp = par_true + q*R;
        
        LPri = prior(newProp); % log prior
        if corrErr == 1
            LL = Run_simulator([newProp errPar], [k,extra_p(2:end)], truePressure, [sc 9*10^4 500], corrErr); % log likelihood
        else
            RSS = Run_simulator(newProp, [k,extra_p(2:end)], truePressure, sc, corrErr); % RSS
            LL = -ntp/2 * log(2*pi*s2) - 0.5*RSS/s2;
        end
        
        LP = LL + LPri;
        denom(i,k) = accProb(newProp, par_true, exp(LP), exp(LP_true));
    end
       
       EstimatePostTrue(i) = mean(nom(i,:),2)/mean(denom(i,:),2);
       
end

if corrErr == 1
    meanEst_corr = mean(EstimatePostTrue); % 897 for correl for correlated simulated data MPA
else
    meanEst_iid = mean(EstimatePostTrue); % 2.5e-21 for iid for correlated simulated data MPA
end

%% for 2d
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/MCMC_run');
GPpath = genpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/MCMC_run')

% Linear B - Simulated data (1 vessel: MPA) Expo stiffness and correlated errors

cd('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Model_MJC_ExponentialStiffness/SimulatedData_MPA')

corrErr = 1;

% if corrErr == 1
%     hd = 2;
% else
    hd = 0;
% end

id = 1; nbio = 6; nd = nbio + hd; T = 0.11; nv = 1; ntp = 512;
gp_ind = 5; em_ind = 0; extra_p = [id, hd, gp_ind, T, nv];
% if corrErr == 1
%     l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05, 10^4, 1];
%     u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5, 9*10^4, 500];
% else
    l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
    u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5];
% end

sc = max(abs(l),abs(u));
alp = [1,1,1,1,1,1];
bet = [1,1,1,1,1,1];
if gp_ind ~= 5
    GP_hyperHyper = [log(0.1), 0.095, log(0.0275), 0.1]; % amplitude: log(var(res))
else
    GP_hyperHyper = [l(end-1), u(end-1), l(end), u(end)];
end

% if corrErr == 1
%     par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
%         0.000000288893362, 0.000000873476079, 0.000001368980536, 0.054676266677259, 0.000141486099902];
% else
    par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
        0.000000288893362, 0.000000873476079, 0.000001368980536];
    
    par_true = par_true./sc;
    
% end

errPar = 10^6 * [0.054676266677259, 0.000141486099902]./[9*10^4 500];

% delete(gcp('nocreate'))
% parpool('local', 20)

K = 100;

% prior = @(par) sum( (alp-1) .* log(par(1:end-hd)-l(1:end-hd)) + ...
%     (bet-1) .* log(u(1:end-hd) - par(1:end-hd)) - ...
%     (alp+bet-1) .* log(u(1:end-hd)-l(1:end-hd)) - log(beta(alp,bet)) );% + ...
%-log(par(end-1)) - log(GP_hyperHyper(2)-GP_hyperHyper(1)) + ...
%-log(par(end)) - log(GP_hyperHyper(4)-GP_hyperHyper(3));

prior = @(par) sum(log(sc(5:6))) + sum( (alp(5:6)-1) .* log(par.*sc(5:6)-l(5:6)) + ...
    (bet(5:6)-1) .* log(u(5:6) - par.*sc(5:6)) )- ...
    sum((alp(5:6)+bet(5:6)-1) .* log(u(5:6)-l(5:6)) - log(beta(alp(5:6),bet(5:6))));

nd = 2;

for i=1:20
    
    if corrErr == 1
        load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))
    else
        load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    end
        
    parChain = p_sample(10^4+1:10^3:120000, 5:6)./sc(5:6);
    if corrErr==0
        ObjFctChain = ObjFct_sample(10^4+1:10^3:120000, 1);
    end
    
    if corrErr == 1
        LL_true = Run_simulator([par_true errPar], extra_p, truePressure, [sc 9*10^4 500], corrErr); % log likelihood
    else
        s2 = mean(s2_sample((10^4+1:120000)));
        
        RSS_true = Run_simulator(par_true, extra_p, truePressure, sc, corrErr); % rss
        LL_true = -ntp/2 * log(2*pi*s2) - 0.5*RSS_true/s2;
    end
    
    Lp_true = prior(par_true(5:6)); % log prior
    LP_true = LL_true + Lp_true;
    
    
    covchain = []; meanchain = []; wsum = [];
    covchain = covupd(parChain,1, covchain,meanchain,wsum);
    [R,p] = chol(covchain);
    if p % singular
        [R,p] = chol(covchain + eye(nd)*1e-8);
    end
    
    propDens = @(par1,par2) mvnpdf(par1, par2, covchain); % calculates q(par1|par2, covchain) = N(par2, covchain) evaluated at par1
    accProb = @(par1, par2, LP1, LP2) min(1, (LP1*propDens(par2,par1))/(LP2*propDens(par1,par2)));% calculates alpha(par1|par2, covchain)
    
    parfor j=1:size(parChain,1)
        LPri = prior(parChain(j,:)); % log prior
        if corrErr == 1
            LL = Run_simulator([par_true(1:4) parChain(j,:) errPar], [j,extra_p(2:end)], truePressure, [sc 9*10^4 500], corrErr); % log likelihood
            LP = LL + LPri;
        else
            LP = -ntp/2 * log(2*pi*s2) - 0.5*ObjFctChain(j)/s2 + LPri;
        end
        
        nom(i,j) = propDens(par_true(5:6),parChain(j,:)) * accProb(par_true(5:6),parChain(j,:), exp(LP_true), exp(LP));
    end
    
    parfor k=1:K
        q = randn(1,nd);
        
        newProp = par_true(5:6) + q*R;
        
        LPri = prior(newProp); % log prior
        if corrErr == 1
            LL = Run_simulator([par_true(1:4) newProp errPar], [k,extra_p(2:end)], truePressure, [sc 9*10^4 500], corrErr); % log likelihood
        else
            RSS = Run_simulator([par_true(1:4) newProp], [k,extra_p(2:end)], truePressure, sc, corrErr); % RSS
            LL = -ntp/2 * log(2*pi*s2) - 0.5*RSS/s2;
        end
        
        LP = LL + LPri;
        denom(i,k) = accProb(newProp, par_true(5:6), exp(LP), exp(LP_true));
    end
       
       EstimatePostTrue(i) = mean(nom(i,:),2)/mean(denom(i,:),2);
       
end

if corrErr == 1
    meanEst_corr = mean(EstimatePostTrue); % 897 for correl for correlated simulated data MPA
else
    meanEst_iid = mean(EstimatePostTrue); % 2.5e-21 for iid for correlated simulated data MPA
end

quantile(EstimatePostTrue, [0.025 0.5 0.975])

%save('Chibs_iid.mat')
%save('Chibs_correl.mat')

for i=1:20
    
    if corrErr == 1
        load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))
    else
        load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    end
        
    parChain = p_sample(10^4+1:10^3:120000, 5:6)./sc(5:6);
    
    [postDistrTrueParam(i), xi, bw] = ksdensity(parChain,par_true(5:6));
end

mean(postDistrTrueParam)

quantile(postDistrTrueParam, [0.025 0.5 0.975])

%% 2 with ksdensity
corrErr = 1;

l = [10^3, -300, 3*10^4, 0.05, 0.05, 0.05];
    u = [10^7, 0, 6*10^4, 2.5,  2.5,  2.5];
% end

sc = max(abs(l),abs(u));

par_true = 10^6 * [5.079589768309998, -0.000174244068580, 0.043181907874987, ...
        0.000000288893362, 0.000000873476079, 0.000001368980536];
    
par_true = par_true./sc;

for i=1:20
    
    if corrErr == 1
        load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))
    else
        load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    end
        
    parChain = p_sample(10^4+1:10^3:120000, 5:6)./sc(5:6);
    
    [postDistrTrueParam(i), xi, bw] = ksdensity(parChain,par_true(5:6));
end

median(postDistrTrueParam)

%%
% n D with multivariate kernel density estimation
nd = 6;

for i=1:20
    
    if corrErr == 1
        load(sprintf('AMsimulator_ExpoStiff_errorCorrel_SimData_ParamFinding_DataInstantiation_correct %d.mat', i))
    else
        load(sprintf('AMsimulator_ExpoStiff_wrongIID_SimData_1vess_MimicData_DataInstantiation_correct %d.mat', i))
    end
    
parChain = p_sample(10^4+1:10^3:120000, 1:nd)./sc;

n = size(parChain,1);
variances = var(parChain);
bandwidths = sqrt(variances) .* (4/(n*(nd+2)))^(1/(nd+4));

postDistrTrueParam(i) = mvksdensity(parChain,par_true,...
	'Bandwidth',bandwidths, 'Kernel','normal');
end

median(postDistrTrueParam)

quantile(postDistrTrueParam, [0.025 0.5 0.975])
