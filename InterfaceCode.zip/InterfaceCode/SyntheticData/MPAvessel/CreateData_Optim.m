function state = CreateData_Optim(id,loc)

pu1 = load(sprintf('pu1_%d.2d', id)); % id is for every run in parallel

[~,~,p,q,~,~] = gnuplot(pu1);

if loc == 1
    pressure = p(:,1); flow = q(:,floor(end/2));
else
    pressure = p(:,floor(end/2)); flow = q(:,floor(end/2));
end

state = [flow; pressure];

end