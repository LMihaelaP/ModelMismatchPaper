function parsave2(fname, cleanPressure, truePressure, p_sample, ObjFct_sample, s2_sample, acc)
save(fname, 'cleanPressure', 'truePressure', 'p_sample', 'ObjFct_sample', 's2_sample', 'acc')
end