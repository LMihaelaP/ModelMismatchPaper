function parsave(fname, cleanPressure, truePressure, p_sample, ObjFct_sample, acc)
save(fname, 'cleanPressure', 'truePressure', 'p_sample', 'ObjFct_sample', 'acc')
end