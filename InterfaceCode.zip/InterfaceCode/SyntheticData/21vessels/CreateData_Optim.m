function pressure = CreateData_Optim(id, nv, ntp)%, meanTruePressure, stdTruePressure)
 % Outputs standardised pressure, since pressure from the 21 vessels have
 % varying amplitudes
 
for i=1:nv % loop over vessels
    pu = load(sprintf('pu%d_%d.2d', i, id));
    [~,~,p,~,~,~] = gnuplot(pu);
%     pressure(ntp*(i-1)+1:ntp*i) = ( p(:,floor(end/2)) - meanTruePressure(i) ) ./ stdTruePressure(i);
    pressure(ntp*(i-1)+1:ntp*i) = p(:,floor(end/2));
end

pressure = pressure';

end