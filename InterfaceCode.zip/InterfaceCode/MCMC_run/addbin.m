function status=addbin(filename,x, overwrite)
%ADDBIN add columns to a V4 matfile
% Usage: addbin(filename,x)
% Adds columns of x to data in mat file. Columns are added because
% MATLAB stores data columnwise. Transpose the data to add rows.
% The file should contain only one double precision matrix.
% This is used in MCMCRUN to save and append temporary mcmc
% chains into binary files.
% See also SAVEBIN and READBIN.

% $Revision: 1.3 $  $Date: 2010/12/10 10:47:38 $

m  = size(x,1);
n  = size(x,2);

fid = fopen(filename,'r+b'); % Open binary file for reading and writing.
if fid == -1 
  error(sprintf('error opening binary file %s',filename));
end
%fseek(fileID, offset, origin) sets the file position indicator offset bytes from origin in the specified file.
if fseek(fid,4,'bof') == -1 % bof = beginning of file
  fclose(fid);
  error('error seeking file');
end

mrows   = fread(fid,1,'integer*4');
mcols   = fread(fid,1,'integer*4');
imagf   = fread(fid,1,'integer*4');
namelen = fread(fid,1,'integer*4');

if mrows > 0 & mrows ~= m
  error('x should have same number of rows');
end

% goto begining of x
if fseek(fid,namelen,'cof') == -1  %cof = current position in file
  fclose(fid);
  error('error seeking file');
end

% if overwrite == 0
if fseek(fid,0,'eof') == -1  % eof = end of file
  fclose(fid);
  error('error seeking eof');
end
% end

% write the new data to file
%%% Mihaela
if overwrite == 1
fseek(fid,20+namelen,'bof'); % move the pointer back to overwrite the matrix (after 'name', in 'real')
end                          % header: 20 bytes + name: namelen bytes
%%%
fwrite(fid,x,'real*8');

% fix mrows
if mrows == 0
  if fseek(fid,4,'bof') == -1
    fclose(fid);
    error('error seeking file');
  end
  fwrite(fid,m,'integer*4');
end

% write the new column size
if fseek(fid,8,'bof') == -1
  fclose(fid);
  error('error seeking file');
end

if overwrite == 0
    fwrite(fid,mcols+n,'integer*4');
else
    fwrite(fid,n,'integer*4');
end

fclose(fid);

if nargout > 0
  status = 1;
end
